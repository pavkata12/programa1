# 🖥️ Sim Racing Academy Server - Инсталационно Ръководство

## 📋 Преди Инсталацията

### Системни Изисквания:
- ✅ **Windows 10/11** (64-bit) или **Linux**
- ✅ **Python 3.8+** 
- ✅ **Administrator права** (задължително!)
- ✅ **Интернет връзка** за download на dependencies
- ✅ **Минимум 4GB RAM**
- ✅ **Минимум 1GB свободно място**

---

## 🚀 АВТОМАТИЧНА ИНСТАЛАЦИЯ (ПРЕПОРЪЧИТЕЛНО)

### Windows:
```bash
# 1. Копирайте server папката на сървъра
# 2. Отворете Command Prompt като Administrator
# 3. Навигирайте до server папката
cd C:\SimRacingAcademy\server\

# 4. Стартирайте автоматичния инсталатор
INSTALL_SERVER.bat
```

### Linux:
```bash
# 1. Копирайте server папката на сървъра
# 2. Отворете Terminal
cd /opt/simracingacademy/server/

# 3. Направете скрипта executable
chmod +x install_server.sh

# 4. Стартирайте инсталатора
sudo ./install_server.sh
```

---

## 🔧 РЪЧНА ИНСТАЛАЦИЯ

### Стъпка 1: Инсталиране на Python

#### Windows:
```bash
# Изтеглете Python от официалния сайт:
https://www.python.org/downloads/

# При инсталацията ЗАДЪЛЖИТЕЛНО отметнете:
☑️ "Add Python to PATH"
☑️ "Install for all users"
```

#### Linux (Ubuntu/Debian):
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
```

#### Linux (CentOS/RHEL):
```bash
sudo yum install python3 python3-pip
# или за по-нови версии:
sudo dnf install python3 python3-pip
```

### Стъпка 2: Подготовка на Server Файловете

```bash
# Копирайте server папката на целевата машина:
C:\SimRacingAcademy\server\     # Windows
/opt/simracingacademy/server/   # Linux

# Структурата трябва да изглежда така:
server/
├── server.py
├── database.py
├── server_api.py
├── admin_gui.py
├── requirements.txt
├── INSTALL_SERVER.bat
└── README.md
```

### Стъпка 3: Инсталиране на Dependencies

#### Windows:
```bash
# Отворете Command Prompt като Administrator:
cd C:\SimRacingAcademy\server\

# Инсталирайте dependencies:
pip install -r requirements.txt
```

#### Linux:
```bash
cd /opt/simracingacademy/server/

# Създайте virtual environment (препоръчително):
python3 -m venv venv
source venv/bin/activate

# Инсталирайте dependencies:
pip install -r requirements.txt
```

### Стъпка 4: Инициализиране на Database

```bash
# Тест на database модула:
python -c "from database import NetCafeDatabase; db = NetCafeDatabase(); print('Database OK')"

# Ако има грешка, проверете:
python -c "import sqlite3; print('SQLite version:', sqlite3.version)"
```

### Стъпка 5: Конфигуриране на Firewall

#### Windows:
```bash
# Отворете Windows Firewall с Advanced Security
# Или използвайте командния ред:
netsh advfirewall firewall add rule name="Sim Racing Academy Server" dir=in action=allow protocol=TCP localport=8080
```

#### Linux:
```bash
# Ubuntu/Debian (ufw):
sudo ufw allow 8080/tcp
sudo ufw reload

# CentOS/RHEL (firewalld):
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```

---

## 🧪 ТЕСТВАНЕ НА ИНСТАЛАЦИЯТА

### Стъпка 1: Стартиране на сървъра
```bash
# Windows:
cd C:\SimRacingAcademy\server\
python server.py

# Linux:
cd /opt/simracingacademy/server/
python3 server.py
```

### Стъпка 2: Проверка на статуса
```bash
# В друг терминал или браузър:
curl http://localhost:8080/api/status

# Или отворете в браузър:
http://localhost:8080/api/status
```

### Стъпка 3: Тест на Admin Panel
```bash
# Отворете в браузър:
http://localhost:8080/admin

# Default login:
Username: admin
Password: admin123
```

---

## 🔄 АВТОМАТИЧНО СТАРТИРАНЕ

### Windows (Task Scheduler):
```bash
# Автоматичният инсталатор ще създаде task, или ръчно:
# 1. Отворете Task Scheduler
# 2. Create Basic Task
# 3. Trigger: "When the computer starts"
# 4. Action: "Start a program"
# 5. Program: python
# 6. Arguments: server.py
# 7. Start in: C:\SimRacingAcademy\server\
```

### Linux (systemd):
```bash
# Създайте service файл:
sudo nano /etc/systemd/system/simracing-server.service

# Съдържание:
[Unit]
Description=Sim Racing Academy Server
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/simracingacademy/server
Environment=PATH=/opt/simracingacademy/server/venv/bin
ExecStart=/opt/simracingacademy/server/venv/bin/python server.py
Restart=always

[Install]
WantedBy=multi-user.target

# Активирайте service:
sudo systemctl daemon-reload
sudo systemctl enable simracing-server
sudo systemctl start simracing-server
```

---

## 🌐 МРЕЖОВА КОНФИГУРАЦИЯ

### Намиране на Server IP:

#### Windows:
```bash
ipconfig | findstr "IPv4"
```

#### Linux:
```bash
ip addr show | grep "inet "
# или
hostname -I
```

### Конфигуриране на Clients:
```json
// В client/config.json на всяка машина:
{
    "server": {
        "host": "192.168.1.100",  // IP на сървъра
        "port": 8080
    }
}
```

---

## 🔐 СИГУРНОСТ

### Смяна на Admin Паролата:
1. Отворете Admin Panel: `http://SERVER_IP:8080/admin`
2. Login с `admin/admin123`
3. Идете на Users → Edit Admin User
4. Сменете паролата
5. **ВАЖНО:** Запишете новата парола на сигурно място!

### Backup на Database:
```bash
# Копирайте netcafe.db файла:
cp netcafe.db netcafe_backup_$(date +%Y%m%d).db
```

---

## 🔧 TROUBLESHOOTING

### Проблем: "Port already in use"
```bash
# Намерете процеса използващ port 8080:
netstat -ano | findstr :8080    # Windows
lsof -i :8080                   # Linux

# Убийте процеса:
taskkill /PID <PID> /F          # Windows
kill -9 <PID>                   # Linux
```

### Проблем: "Module not found"
```bash
# Проверете Python версията:
python --version

# Преинсталирайте dependencies:
pip install --upgrade -r requirements.txt
```

### Проблем: Database грешки
```bash
# Проверете permissions на .db файла:
ls -la netcafe.db               # Linux
icacls netcafe.db               # Windows

# Презаредете database:
python -c "from database import NetCafeDatabase; NetCafeDatabase().init_db()"
```

### Проблем: Firewall блокира връзките
```bash
# Временно изключете firewall за тест:
sudo ufw disable               # Linux
# Windows: Control Panel → Windows Defender Firewall → Turn off

# Ако работи, добавете правилото за port 8080
```

---

## 📊 МОНИТОРИНГ

### Логове:
```bash
# Преглед на server логове:
tail -f server.log             # Linux
type server.log                # Windows

# Преглед на production bridge логове:
tail -f production_bridge.log
```

### Статистики:
- Admin Panel: `http://SERVER_IP:8080/admin`
- API Status: `http://SERVER_IP:8080/api/status`
- Database статистики в Admin Panel

---

## 🎉 ГОТОВО!

След успешна инсталация сървърът ще бъде достъпен на:
- **Admin Panel:** `http://SERVER_IP:8080/admin`
- **API:** `http://SERVER_IP:8080/api/`
- **WebSocket:** `ws://SERVER_IP:8080/ws`

### Следващи стъпки:
1. ✅ Сменете admin паролата
2. ✅ Конфигурирайте client машините
3. ✅ Създайте потребители и компютри
4. ✅ Тествайте цялата система

**Успешна инсталация!** 🚀
