# 🏎️ Sim Racing Academy Server - Installation Guide

## 📋 Преди Инсталацията

### Системни Изисквания:
- ✅ **Windows 10/11** или **Linux Ubuntu 20.04+**
- ✅ **Node.js 18+** 
- ✅ **NPM 8+**
- ✅ **SQLite3** (включено в Node.js)
- ✅ **Минимум 4GB RAM**
- ✅ **SSD диск** (препоръчително)
- ✅ **Статичен IP адрес** в мрежата

---

## 🚀 Стъпка 1: Инсталиране на Node.js

### Windows:
```bash
# Изтеглете Node.js от официалния сайт:
https://nodejs.org/en/download/

# Изберете LTS версия (18.x или 20.x)
# При инсталацията отметнете:
☑️ "Add to PATH"
☑️ "Automatically install necessary tools"
```

### Linux (Ubuntu/Debian):
```bash
# Обновете системата:
sudo apt update && sudo apt upgrade -y

# Инсталирайте Node.js 20.x:
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Проверете версиите:
node --version  # Трябва да е v18+ или v20+
npm --version   # Трябва да е 8+
```

### Проверка на инсталацията:
```bash
node --version
npm --version
```

---

## 🔧 Стъпка 2: Подготовка на Server Файловете

### 1. Копирайте server папката на сървъра:
```
/opt/simracing-academy/server/  (Linux)
C:\SimRacingAcademy\server\     (Windows)

├── server.js
├── server_api.py
├── database.py
├── package.json
├── package-lock.json
├── schema.sql
├── netcafe.db (ще се създаде)
├── server.log (ще се създаде)
└── node_modules/ (ще се създаде)
```

### 2. Настройте правилните permissions (Linux):
```bash
sudo mkdir -p /opt/simracing-academy
sudo cp -r server/ /opt/simracing-academy/
sudo chown -R $USER:$USER /opt/simracing-academy/
chmod +x /opt/simracing-academy/server/*.js
```

---

## 📦 Стъпка 3: Инсталиране на Dependencies

### Навигирайте до server папката:
```bash
# Linux:
cd /opt/simracing-academy/server/

# Windows:
cd C:\SimRacingAcademy\server\
```

### Инсталирайте Node.js dependencies:
```bash
npm install
```

**Очакван резултат:**
```
✅ aiohttp@3.9.1
✅ sqlite3@5.1.6
✅ express@4.18.2
✅ ws@8.14.2
✅ jsonwebtoken@9.0.2
✅ cors@2.8.5
...
✅ Dependencies installed successfully
```

---

## 🛠️ Стъпка 4: Database Инициализация

### 1. Създайте базата данни:
```bash
node -e "
const db = require('./database');
console.log('✅ Database initialized successfully');
console.log('✅ Default admin user created: admin/admin123');
"
```

### 2. Проверете базата данни:
```bash
# Инсталирайте sqlite3 CLI (ако няма):
# Linux: sudo apt install sqlite3
# Windows: Download from https://sqlite.org/download.html

sqlite3 netcafe.db ".tables"
```

**Очакван резултат:**
```
users
computers  
sessions
settings
simulator_types
leaderboard
posts
discount_codes
user_discount_usage
```

### 3. Проверете admin потребителя:
```bash
sqlite3 netcafe.db "SELECT username, is_admin FROM users WHERE is_admin = 1;"
```

**Очакван резултат:**
```
admin|1
```

---

## 🌐 Стъпка 5: Network Configuration

### 1. Определете IP адреса на сървъра:
```bash
# Linux:
ip addr show | grep "inet " | grep -v 127.0.0.1

# Windows:
ipconfig | findstr "IPv4"
```

**Пример резултат:** `192.168.1.100`

### 2. Конфигурирайте Firewall:

#### Windows Firewall:
```
Windows Security → Firewall & network protection →
Advanced settings → Inbound Rules → New Rule →
Port → TCP → 8080 → Allow → All profiles → 
Name: "Sim Racing Academy Server"
```

#### Linux UFW:
```bash
sudo ufw allow 8080/tcp
sudo ufw enable
sudo ufw status
```

### 3. Тествайте мрежовия достъп:
```bash
# От друг компютър в мрежата:
curl http://192.168.1.100:8080/api/status
```

---

## 🎯 Стъпка 6: Първоначален Тест

### 1. Стартирайте сървъра:
```bash
node server.js
```

**Очакван резултат:**
```
🏎️ Sim Racing Academy Server starting...
✅ Database initialized
✅ Server running on port 8080
✅ WebSocket server ready
✅ API endpoints loaded
🌐 Server URL: http://192.168.1.100:8080
📊 Admin Panel: http://192.168.1.100:8080/admin
```

### 2. Тествайте API endpoints:
```bash
# В нов terminal/command prompt:
curl http://localhost:8080/api/status

# Очакван отговор:
{
  "success": true,
  "status": "running",
  "active_connections": 0,
  "active_sessions": 0,
  "version": "2.0"
}
```

### 3. Тествайте admin login:
```bash
curl -X POST http://localhost:8080/api/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123",
    "computer_id": "test-server"
  }'
```

---

## 🔄 Стъпка 7: Auto-Start Configuration

### Windows - Task Scheduler:
```
1. Отворете Task Scheduler
2. Create Task → General:
   Name: "Sim Racing Academy Server"
   ☑️ Run with highest privileges
   ☑️ Run whether user is logged on or not

3. Triggers → New:
   Begin: At startup
   ☑️ Enabled

4. Actions → New:
   Action: Start a program
   Program: C:\Program Files\nodejs\node.exe
   Arguments: server.js
   Start in: C:\SimRacingAcademy\server\

5. Settings:
   ☑️ Allow task to be run on demand
   ☑️ If task fails, restart every: 1 minute
   ☑️ Attempt to restart up to: 3 times
```

### Linux - Systemd Service:
```bash
# Създайте service файл:
sudo nano /etc/systemd/system/simracing-academy.service
```

```ini
[Unit]
Description=Sim Racing Academy Server
After=network.target

[Service]
Type=simple
User=simracing
WorkingDirectory=/opt/simracing-academy/server
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
# Активирайте service-а:
sudo systemctl daemon-reload
sudo systemctl enable simracing-academy
sudo systemctl start simracing-academy

# Проверете статуса:
sudo systemctl status simracing-academy
```

---

## 🔐 Стъпка 8: Security & Production Settings

### 1. Променете default admin паролата:
```bash
# Свържете се към базата:
sqlite3 netcafe.db

# Генерирайте нова парола (example: "MySecurePass123"):
UPDATE users SET password_hash = 'sha256_hash_of_your_password' WHERE username = 'admin';

# Или използвайте admin панела
```

### 2. Конфигурирайте JWT Secret:
```bash
# Linux:
export NETCAFE_JWT_SECRET="your-super-secret-jwt-key-here"

# Windows:
set NETCAFE_JWT_SECRET=your-super-secret-jwt-key-here
```

### 3. Backup конфигурация:
```bash
# Създайте backup script за базата:
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
cp netcafe.db "backups/netcafe_backup_$DATE.db"
find backups/ -name "*.db" -mtime +7 -delete
```

---

## 🧪 Стъпка 9: Финален Тест

### 1. Рестартирайте сървъра
### 2. Проверете auto-start функционалността
### 3. Тествайте от client машина:
```bash
# На client машина, edit config.json:
{
  "server": {
    "host": "192.168.1.100",  // IP на сървъра
    "port": 8080
  }
}

# Стартирайте test_connection.py
```

### 4. Тествайте admin панела:
```
Отворете браузър: http://192.168.1.100:8080/admin
Login: admin / your_new_password
```

---

## 📊 Стъпка 10: Monitoring & Logs

### Log файлове:
```bash
# Server logs:
tail -f server.log

# System logs (Linux):
sudo journalctl -u simracing-academy -f

# Windows Event Viewer:
Applications and Services → Task Scheduler
```

### Performance monitoring:
```bash
# CPU/Memory usage:
top -p $(pgrep node)

# Database size:
ls -lh netcafe.db

# Network connections:
netstat -an | grep 8080
```

---

## ⚠️ Troubleshooting

### Проблем: "Port 8080 already in use"
**Решение:**
```bash
# Намерете процеса:
netstat -ano | findstr 8080  # Windows
lsof -i :8080               # Linux

# Убийте процеса или сменете порта в server.js
```

### Проблем: "Database locked"
**Решение:**
```bash
# Проверете за zombie процеси:
ps aux | grep node
kill -9 [process_id]

# Или рестартирайте системата
```

### Проблем: "Cannot connect from client"
**Решение:**
```bash
# Проверете firewall:
sudo ufw status  # Linux
netsh advfirewall show allprofiles  # Windows

# Проверете IP адреса:
ip addr show  # Linux
ipconfig     # Windows
```

---

## 📞 Support & Maintenance

### Daily Tasks:
- ✅ Проверете server.log за грешки
- ✅ Мониторирайте database размера
- ✅ Backup базата данни

### Weekly Tasks:
- ✅ Обновете системата (apt update)
- ✅ Проверете disk space
- ✅ Тествайте backup restore

### Monthly Tasks:
- ✅ Обновете Node.js dependencies (npm update)
- ✅ Ротирайте log файловете
- ✅ Анализирайте performance metrics

---

## 🎉 Готово!

Сървърът е инсталиран и готов за използване! 

**Server URL:** `http://your-server-ip:8080`
**Admin Panel:** `http://your-server-ip:8080/admin`
**API Status:** `http://your-server-ip:8080/api/status`

**Happy Gaming! 🏎️**
