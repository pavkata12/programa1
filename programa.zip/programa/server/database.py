import sqlite3
import hashlib
import uuid
from datetime import datetime
import logging
import time # Added for retry logic

logger = logging.getLogger(__name__)

class NetCafeDatabase:
    def __init__(self, db_path='netcafe.db'):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database with all tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                is_admin BOOLEAN DEFAULT 0,
                minutes INTEGER DEFAULT 0,
                total_spent REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # Computers table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS computers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                computer_id TEXT UNIQUE NOT NULL,
                name TEXT,
                ip_address TEXT,
                status TEXT DEFAULT 'offline',
                last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # Sessions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT UNIQUE NOT NULL,
                user_id INTEGER,
                computer_id TEXT,
                start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                end_time TIMESTAMP,
                duration_minutes INTEGER DEFAULT 0,
                amount_paid REAL DEFAULT 0.0,
                simulator_type_id INTEGER,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (simulator_type_id) REFERENCES simulator_types (id)
            )
        ''')
        
        # Transactions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                amount REAL NOT NULL,
                minutes_added INTEGER,
                transaction_type TEXT DEFAULT 'payment',
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Settings table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Simulator types table - для различни rates на XP/tokens
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS simulator_types (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                display_name TEXT NOT NULL,
                xp_per_minute INTEGER DEFAULT 2,
                tokens_per_minute INTEGER DEFAULT 2,
                color TEXT DEFAULT '#00A19C',
                icon TEXT DEFAULT '🏎️',
                description TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Simulator configurations table - mapping computers to types
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS simulator_configs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                computer_id TEXT NOT NULL,
                ip_address TEXT,
                simulator_type_id INTEGER NOT NULL,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (simulator_type_id) REFERENCES simulator_types(id),
                FOREIGN KEY (computer_id) REFERENCES computers(computer_id)
            )
        ''')
        
        # Posts table for admin-managed content
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS posts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                author_id INTEGER,
                category TEXT DEFAULT 'general',
                status TEXT DEFAULT 'published',
                featured BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (author_id) REFERENCES users (id)
            )
        ''')
        
        # Token shop items table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS shop_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                category TEXT NOT NULL,
                price INTEGER NOT NULL,
                original_price INTEGER,
                icon TEXT DEFAULT '🎁',
                popular BOOLEAN DEFAULT 0,
                premium BOOLEAN DEFAULT 0,
                limited BOOLEAN DEFAULT 0,
                discount INTEGER DEFAULT 0,
                stock INTEGER DEFAULT -1,
                features TEXT,
                stats TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # User tokens table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER UNIQUE,
                tokens INTEGER DEFAULT 0,
                total_earned INTEGER DEFAULT 0,
                total_spent INTEGER DEFAULT 0,
                minutes_played INTEGER DEFAULT 0,
                xp INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Add missing columns to existing user_tokens table if they don't exist
        cursor.execute("PRAGMA table_info(user_tokens)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'minutes_played' not in columns:
            cursor.execute('ALTER TABLE user_tokens ADD COLUMN minutes_played INTEGER DEFAULT 0')
            
        if 'xp' not in columns:
            cursor.execute('ALTER TABLE user_tokens ADD COLUMN xp INTEGER DEFAULT 0')
            
        if 'created_at' not in columns:
            cursor.execute('ALTER TABLE user_tokens ADD COLUMN created_at TIMESTAMP')
            # Update existing records with current timestamp
            cursor.execute('UPDATE user_tokens SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL')
            
        if 'updated_at' not in columns:
            cursor.execute('ALTER TABLE user_tokens ADD COLUMN updated_at TIMESTAMP')
            # Update existing records with current timestamp
            cursor.execute('UPDATE user_tokens SET updated_at = CURRENT_TIMESTAMP WHERE updated_at IS NULL')
        
        # Token transactions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS token_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                amount INTEGER NOT NULL,
                transaction_type TEXT NOT NULL,
                description TEXT,
                item_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (item_id) REFERENCES shop_items (id)
            )
        ''')
        
        # User purchases table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_purchases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                item_id INTEGER,
                tokens_spent INTEGER,
                purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'completed',
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (item_id) REFERENCES shop_items (id)
            )
        ''')
        
        # Tournaments table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tournaments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                category TEXT DEFAULT 'racing',
                status TEXT DEFAULT 'upcoming',
                start_date TIMESTAMP,
                end_date TIMESTAMP,
                max_participants INTEGER DEFAULT 50,
                entry_fee INTEGER DEFAULT 0,
                prize_pool INTEGER DEFAULT 0,
                first_prize INTEGER DEFAULT 0,
                second_prize INTEGER DEFAULT 0,
                third_prize INTEGER DEFAULT 0,
                rules TEXT,
                requirements TEXT,
                image_url TEXT,
                created_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users (id)
            )
        ''')
        
        # Tournament registrations table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tournament_registrations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tournament_id INTEGER,
                user_id INTEGER,
                registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'registered',
                notes TEXT,
                FOREIGN KEY (tournament_id) REFERENCES tournaments (id),
                FOREIGN KEY (user_id) REFERENCES users (id),
                UNIQUE(tournament_id, user_id)
            )
        ''')
        
        # Tournament results table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tournament_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tournament_id INTEGER,
                user_id INTEGER,
                position INTEGER,
                points INTEGER DEFAULT 0,
                best_time REAL,
                prize_tokens INTEGER DEFAULT 0,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (tournament_id) REFERENCES tournaments (id),
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Shopping cart table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS shopping_cart (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                item_id INTEGER,
                quantity INTEGER DEFAULT 1,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (item_id) REFERENCES shop_items (id),
                UNIQUE(user_id, item_id)
            )
        ''')
        
        # Discount codes table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS discount_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                discount_type TEXT DEFAULT 'percentage',
                discount_value REAL NOT NULL,
                min_purchase INTEGER DEFAULT 0,
                max_uses INTEGER DEFAULT -1,
                current_uses INTEGER DEFAULT 0,
                valid_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                valid_until TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # User discount usage table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_discount_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                discount_code_id INTEGER,
                used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                tokens_saved INTEGER,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (discount_code_id) REFERENCES discount_codes (id)
            )
        ''')
        
        # Create default admin user if not exists
        cursor.execute("SELECT COUNT(*) FROM users WHERE is_admin = 1")
        admin_count = cursor.fetchone()[0]
        
        if admin_count == 0:
            admin_password = self.hash_password('admin123')
            cursor.execute('''
                INSERT INTO users (username, password_hash, is_admin, minutes)
                VALUES (?, ?, 1, 999999)
            ''', ('admin', admin_password))
            logger.info("Created default admin user: admin/admin123")
        
        # Insert default settings
        default_settings = [
            ('price_per_minute', '0.10'),
            ('currency', 'BGN'),
            ('session_warning_5min', '1'),
            ('session_warning_1min', '1'),
            ('auto_logout_enabled', '1'),
            ('keyboard_blocking', '1'),
            ('cafe_name', 'NetCafe Pro 2.0')
        ]
        
        for key, value in default_settings:
            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)
            ''', (key, value))
        
        # Create default simulator types
        default_simulator_types = [
            ('premium', 'Premium Simulators', 4, 4, '#FFD700', '👑', 'Най-добрите симулатори с най-високо качество и най-високи rates'),
            ('medium', 'Standard Simulators', 3, 3, '#00A19C', '🏎️', 'Средни симулатори с добро качество и добри rates'),  
            ('normal', 'Basic Simulators', 2, 2, '#808080', '🚗', 'Основни симулатори за начинаещи с базови rates')
        ]
        
        for type_data in default_simulator_types:
            cursor.execute('''
                INSERT OR IGNORE INTO simulator_types 
                (name, display_name, xp_per_minute, tokens_per_minute, color, icon, description)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', type_data)
        
        # Check if simulator_type_id column exists in sessions table
        cursor.execute("PRAGMA table_info(sessions)")
        columns = [column[1] for column in cursor.fetchall()]
        if 'simulator_type_id' not in columns:
            cursor.execute('ALTER TABLE sessions ADD COLUMN simulator_type_id INTEGER')
            logger.info("Added simulator_type_id column to sessions table")
        
        conn.commit()
        conn.close()
        logger.info("Database initialized successfully with simulator types")
    
    def hash_password(self, password):
        """Hash password using SHA256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def verify_password(self, password, password_hash):
        """Verify password against hash"""
        return self.hash_password(password) == password_hash
    
    def create_user(self, username, password, is_admin=False, minutes=0):
        """Create new user"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            password_hash = self.hash_password(password)
            cursor.execute('''
                INSERT INTO users (username, password_hash, is_admin, minutes)
                VALUES (?, ?, ?, ?)
            ''', (username, password_hash, is_admin, minutes))
            
            user_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            logger.info(f"Created user: {username}")
            return user_id
        except sqlite3.IntegrityError:
            logger.error(f"User {username} already exists")
            return None
        except Exception as e:
            logger.error(f"Error creating user: {e}")
            return None
    
    def authenticate_user(self, username, password):
        """Authenticate user login"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT id, username, password_hash, is_admin, minutes, is_active,
                       basic_minutes, standard_minutes, premium_minutes
                FROM users WHERE username = ?
            ''', (username,))
            
            user = cursor.fetchone()
            conn.close()
            
            if not user:
                return None
            
            user_id, username, password_hash, is_admin, minutes, is_active, basic_minutes, standard_minutes, premium_minutes = user
            
            if not is_active:
                return None
            
            if self.verify_password(password, password_hash):
                # Update last login
                self.update_last_login(user_id)
                return {
                    'id': user_id,
                    'username': username,
                    'is_admin': bool(is_admin),
                    'minutes': minutes,
                    'basic_minutes': basic_minutes or 0,
                    'standard_minutes': standard_minutes or 0,
                    'premium_minutes': premium_minutes or 0
                }
            
            return None
        except Exception as e:
            logger.error(f"Authentication error: {e}")
            return None
    
    def update_last_login(self, user_id):
        """Update user's last login time"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
            ''', (user_id,))
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Error updating last login: {e}")
    
    def add_minutes(self, username, minutes, amount_paid=0.0, minute_type='basic'):
        """Add minutes to user account - supports different minute types"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # First, ensure the minute type columns exist
            self._ensure_minute_columns(cursor)
            
            # Map minute types to column names
            minute_columns = {
                'basic': 'basic_minutes',
                'normal': 'standard_minutes',  # Map normal to standard
                'standard': 'standard_minutes',
                'medium': 'standard_minutes',   # Map medium to standard
                'premium': 'premium_minutes'
            }
            
            # Default to basic if unknown type
            column_name = minute_columns.get(minute_type, 'basic_minutes')
            
            # Update the specific minute type column
            cursor.execute(f'''
                UPDATE users SET {column_name} = {column_name} + ?, total_spent = total_spent + ?
                WHERE username = ?
            ''', (minutes, amount_paid, username))
            
            # Also update the legacy 'minutes' column for backward compatibility
            cursor.execute('''
                UPDATE users SET minutes = minutes + ?
                WHERE username = ?
            ''', (minutes, username))
            
            if cursor.rowcount > 0:
                # Add transaction record
                cursor.execute('SELECT id FROM users WHERE username = ?', (username,))
                user_id = cursor.fetchone()[0]
                
                cursor.execute('''
                    INSERT INTO transactions (user_id, amount, minutes_added, description)
                    VALUES (?, ?, ?, ?)
                ''', (user_id, amount_paid, minutes, f"Added {minutes} {minute_type} minutes"))
                
                conn.commit()
                conn.close()
                logger.info(f"Added {minutes} {minute_type} minutes to {username}")
                return True
            
            conn.close()
            return False
        except Exception as e:
            logger.error(f"Error adding minutes: {e}")
            return False

    def _ensure_minute_columns(self, cursor):
        """Ensure minute type columns exist in users table"""
        try:
            # Check if columns exist and add them if they don't
            columns_to_add = [
                'basic_minutes INTEGER DEFAULT 0',
                'standard_minutes INTEGER DEFAULT 0', 
                'premium_minutes INTEGER DEFAULT 0'
            ]
            
            for column_def in columns_to_add:
                column_name = column_def.split()[0]
                try:
                    cursor.execute(f'ALTER TABLE users ADD COLUMN {column_def}')
                    logger.info(f"Added column {column_name} to users table")
                except sqlite3.OperationalError as e:
                    if 'duplicate column name' in str(e).lower():
                        # Column already exists, that's fine
                        pass
                    else:
                        raise e
                        
        except Exception as e:
            logger.error(f"Error ensuring minute columns: {e}")
    
    def create_session(self, user_id, computer_id, minutes, minute_type='basic_minutes'):
        """Create new NetCafe session - DEDUCTS MINUTES FROM SPECIFIC TYPE"""
        try:
            session_id = str(uuid.uuid4())
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get simulator type for this computer
            cursor.execute('''
                SELECT simulator_type_id FROM simulator_configs 
                WHERE computer_id = ?
            ''', (computer_id,))
            simulator_config = cursor.fetchone()
            simulator_type_id = simulator_config[0] if simulator_config else None
            
            # Store minute_type in sessions table for proper refund
            cursor.execute('''
                INSERT INTO sessions (session_id, user_id, computer_id, duration_minutes, simulator_type_id)
                VALUES (?, ?, ?, ?, ?)
            ''', (session_id, user_id, computer_id, minutes, simulator_type_id))
            
            # Store minute_type information for refund (we'll add this as a comment in the session)
            # For now, we'll track it in the active_sessions memory
            
            # Deduct minutes from specific minute type (not total minutes)
            if minute_type == 'basic_minutes':
                cursor.execute('''
                    UPDATE users SET basic_minutes = basic_minutes - ? WHERE id = ?
                ''', (minutes, user_id))
            elif minute_type == 'standard_minutes':
                cursor.execute('''
                    UPDATE users SET standard_minutes = standard_minutes - ? WHERE id = ?
                ''', (minutes, user_id))
            elif minute_type == 'premium_minutes':
                cursor.execute('''
                    UPDATE users SET premium_minutes = premium_minutes - ? WHERE id = ?
                ''', (minutes, user_id))
            else:
                # Fallback to total minutes for unknown types
                cursor.execute('''
                    UPDATE users SET minutes = minutes - ? WHERE id = ?
                ''', (minutes, user_id))
            
            conn.commit()
            conn.close()
            
            if simulator_type_id:
                logger.info(f"Created NetCafe session {session_id} for user {user_id} on simulator type {simulator_type_id} - DEDUCTED {minutes} {minute_type}")
            else:
                logger.info(f"Created NetCafe session {session_id} for user {user_id} with default rates - DEDUCTED {minutes} {minute_type}")
            return session_id
        except Exception as e:
            logger.error(f"Error creating session: {e}")
            return None

    def create_simulator_reservation(self, user_id, computer_id, reserved_minutes):
        """Create simulator reservation WITHOUT deducting minutes upfront"""
        try:
            session_id = str(uuid.uuid4())
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if user has enough minutes
            cursor.execute('SELECT minutes FROM users WHERE id = ?', (user_id,))
            user = cursor.fetchone()
            if not user or user[0] < reserved_minutes:
                conn.close()
                return None
                
            cursor.execute('''
                INSERT INTO sessions (session_id, user_id, computer_id, duration_minutes, is_active)
                VALUES (?, ?, ?, ?, 1)
            ''', (session_id, user_id, computer_id, reserved_minutes))
            
            # NO MINUTE DEDUCTION - only reservation
            logger.info(f"Created simulator reservation {session_id} for {reserved_minutes} minutes - NO DEDUCTION")
            
            conn.commit()
            conn.close()
            
            return session_id
        except Exception as e:
            logger.error(f"Error creating reservation: {e}")
            return None

    def start_simulator_session(self, session_id):
        """Start actual simulator usage - deduct reserved minutes"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT user_id, duration_minutes FROM sessions 
                WHERE session_id = ? AND is_active = 1
            ''', (session_id,))
            
            session = cursor.fetchone()
            if not session:
                conn.close()
                return False
                
            user_id, reserved_minutes = session
            
            # NOW deduct the reserved minutes
            cursor.execute('''
                UPDATE users SET minutes = minutes - ? WHERE id = ?
            ''', (reserved_minutes, user_id))
            
            # Mark session as started
            cursor.execute('''
                UPDATE sessions SET start_time = CURRENT_TIMESTAMP 
                WHERE session_id = ?
            ''', (session_id,))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Started simulator session {session_id}, deducted {reserved_minutes} minutes")
            return True
        except Exception as e:
            logger.error(f"Error starting simulator session: {e}")
            return False

    def cancel_reservation(self, session_id):
        """Cancel reservation without deducting minutes"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE sessions SET is_active = 0, end_time = CURRENT_TIMESTAMP
                WHERE session_id = ? AND start_time IS NULL
            ''', (session_id,))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Cancelled reservation {session_id} - NO MINUTES DEDUCTED")
            return True
        except Exception as e:
            logger.error(f"Error cancelling reservation: {e}")
            return False
    
    def end_session(self, session_id, minutes_used, minute_type='basic_minutes'):
        """End session and calculate refund to specific minute type"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT user_id, duration_minutes FROM sessions 
                WHERE session_id = ? AND is_active = 1
            ''', (session_id,))
            
            session = cursor.fetchone()
            if not session:
                logger.warning(f"Session {session_id} not found or already ended")
                return False
            
            user_id, total_minutes = session
            unused_minutes = max(0, total_minutes - minutes_used)
            
            # Get user's current minutes before refund
            cursor.execute('SELECT username, minutes FROM users WHERE id = ?', (user_id,))
            user_info = cursor.fetchone()
            username, current_minutes = user_info if user_info else ("Unknown", 0)
            
            logger.info(f"[SESSION END] SESSION END DETAILS:")
            logger.info(f"   User: {username} (ID: {user_id})")
            logger.info(f"   Session: {session_id[:8]}...")
            logger.info(f"   Total minutes allocated: {total_minutes}")
            logger.info(f"   Minutes used (from client): {minutes_used}")
            logger.info(f"   Minutes to refund: {unused_minutes}")
            logger.info(f"   User's current balance: {current_minutes}")
            
            # CRITICAL BUG CHECK: If minutes_used is 0 but session had time, something is wrong!
            if minutes_used == 0 and total_minutes > 0:
                logger.error(f"[BUG DETECTED] Client reported 0 minutes used for {total_minutes} minute session!")
                logger.error(f"   This will cause full refund and no actual charge!")
                logger.error(f"   User {username} should be charged but won't be!")
                
                # SERVER-SIDE PROTECTION: Charge minimum 1 minute for non-zero sessions
                logger.warning(f"[AUTO-FIX] Overriding minutes_used from 0 to 1 to prevent abuse")
                minutes_used = 1
                unused_minutes = max(0, total_minutes - minutes_used)
            
            # Update session
            cursor.execute('''
                UPDATE sessions SET 
                    end_time = CURRENT_TIMESTAMP,
                    duration_minutes = ?,
                    is_active = 0
                WHERE session_id = ?
            ''', (minutes_used, session_id))
            
            # Refund unused minutes to specific minute type
            if unused_minutes > 0:
                if minute_type == 'basic_minutes':
                    cursor.execute('''
                        UPDATE users SET basic_minutes = basic_minutes + ? WHERE id = ?
                    ''', (unused_minutes, user_id))
                elif minute_type == 'standard_minutes':
                    cursor.execute('''
                        UPDATE users SET standard_minutes = standard_minutes + ? WHERE id = ?
                    ''', (unused_minutes, user_id))
                elif minute_type == 'premium_minutes':
                    cursor.execute('''
                        UPDATE users SET premium_minutes = premium_minutes + ? WHERE id = ?
                    ''', (unused_minutes, user_id))
                else:
                    # Fallback to total minutes for unknown types
                    cursor.execute('''
                        UPDATE users SET minutes = minutes + ? WHERE id = ?
                    ''', (unused_minutes, user_id))
                
                # Get new balance for the specific minute type
                cursor.execute(f'''
                    SELECT {minute_type} FROM users WHERE id = ?
                ''', (user_id,))
                new_balance = cursor.fetchone()[0]
                
                logger.info(f"   [REFUND] Refunded {unused_minutes} minutes to {minute_type}. New balance: {new_balance}")
            else:
                logger.info(f"   [NO REFUND] No refund needed (used all {total_minutes} minutes)")
            
            conn.commit()
            conn.close()
            
            logger.info(f"[SUCCESS] Session {session_id[:8]}... ended successfully")
            return True
        except Exception as e:
            logger.error(f"Error ending session: {e}")
            return False
    
    def update_user(self, user_id, username=None, password=None, is_admin=None, minutes=None, is_active=None):
        """Update user information with robust connection handling"""
        conn = None
        max_retries = 3
        retry_delay = 0.1  # 100ms delay between retries
        
        for attempt in range(max_retries):
            try:
                # Set a timeout for the connection
                conn = sqlite3.connect(self.db_path, timeout=10.0)
                conn.execute('PRAGMA busy_timeout = 5000')  # 5 second busy timeout
                cursor = conn.cursor()
                
                # Build update query dynamically
                updates = []
                values = []
                
                if username is not None:
                    updates.append("username = ?")
                    values.append(username)
                
                if password is not None:
                    updates.append("password_hash = ?")
                    values.append(self.hash_password(password))
                
                if is_admin is not None:
                    updates.append("is_admin = ?")
                    values.append(is_admin)
                
                if minutes is not None:
                    updates.append("minutes = ?")
                    values.append(minutes)
                
                if is_active is not None:
                    updates.append("is_active = ?")
                    values.append(is_active)
                
                if not updates:
                    return False
                
                # Add user_id to values for WHERE clause
                values.append(user_id)
                
                query = f"UPDATE users SET {', '.join(updates)} WHERE id = ?"
                cursor.execute(query, values)
                
                success = cursor.rowcount > 0
                conn.commit()
                
                if success:
                    logger.info(f"Updated user {user_id}")
                else:
                    logger.warning(f"No user found with id {user_id}")
                
                return success
                
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and attempt < max_retries - 1:
                    logger.warning(f"Database locked on attempt {attempt + 1}, retrying in {retry_delay}s...")
                    if conn:
                        try:
                            conn.close()
                        except:
                            pass
                        conn = None
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                    continue
                else:
                    logger.error(f"Database operational error updating user: {e}")
                    if conn:
                        try:
                            conn.rollback()
                        except:
                            pass
                    return False
            except sqlite3.IntegrityError as e:
                logger.error(f"Integrity error updating user: {e}")
                if conn:
                    try:
                        conn.rollback()
                    except:
                        pass
                return False
            except Exception as e:
                logger.error(f"Error updating user: {e}")
                if conn:
                    try:
                        conn.rollback()
                    except:
                        pass
                return False
            finally:
                if conn:
                    try:
                        conn.close()
                    except:
                        pass
        
        # If we get here, all retries failed
        logger.error(f"Failed to update user {user_id} after {max_retries} attempts")
        return False

    def delete_user(self, user_id):
        """Delete user permanently and all related data with robust connection handling"""
        conn = None
        max_retries = 3
        retry_delay = 0.1  # 100ms delay between retries
        
        for attempt in range(max_retries):
            try:
                # Set a timeout for the connection
                conn = sqlite3.connect(self.db_path, timeout=10.0)
                conn.execute('PRAGMA busy_timeout = 5000')  # 5 second busy timeout
                cursor = conn.cursor()
                
                # Start transaction
                cursor.execute("BEGIN IMMEDIATE TRANSACTION")
                
                # Delete user sessions first (foreign key constraint)
                cursor.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
                
                # Delete user token transactions
                try:
                    cursor.execute("DELETE FROM token_transactions WHERE user_id = ?", (user_id,))
                except sqlite3.OperationalError:
                    # Table might not exist, continue
                    pass
                
                # Delete user purchases
                try:
                    cursor.execute("DELETE FROM user_purchases WHERE user_id = ?", (user_id,))
                except sqlite3.OperationalError:
                    # Table might not exist, continue
                    pass
                
                # Delete user tokens
                try:
                    cursor.execute("DELETE FROM user_tokens WHERE user_id = ?", (user_id,))
                except sqlite3.OperationalError:
                    # Table might not exist, continue
                    pass
                
                # Delete user tournament registrations
                try:
                    cursor.execute("DELETE FROM tournament_registrations WHERE user_id = ?", (user_id,))
                except sqlite3.OperationalError:
                    # Table might not exist, continue
                    pass
                
                # Delete user tournament results
                try:
                    cursor.execute("DELETE FROM tournament_results WHERE user_id = ?", (user_id,))
                except sqlite3.OperationalError:
                    # Table might not exist, continue
                    pass
                
                # Delete user shopping cart items
                try:
                    cursor.execute("DELETE FROM shopping_cart WHERE user_id = ?", (user_id,))
                except sqlite3.OperationalError:
                    # Table might not exist, continue
                    pass
                
                # Delete user discount usage
                try:
                    cursor.execute("DELETE FROM user_discount_usage WHERE user_id = ?", (user_id,))
                except sqlite3.OperationalError:
                    # Table might not exist, continue
                    pass
                
                # Delete user transactions/payments (if table exists)
                try:
                    cursor.execute("DELETE FROM transactions WHERE user_id = ?", (user_id,))
                except sqlite3.OperationalError:
                    # Table might not exist, continue
                    pass
                
                # Delete the user
                cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
                
                if cursor.rowcount == 0:
                    # User not found
                    cursor.execute("ROLLBACK")
                    logger.warning(f"No user found with id {user_id} to delete")
                    return False
                
                # Commit all deletions
                cursor.execute("COMMIT")
                
                logger.info(f"Successfully deleted user {user_id} and all related data")
                return True
                
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and attempt < max_retries - 1:
                    logger.warning(f"Database locked on attempt {attempt + 1}, retrying in {retry_delay}s...")
                    if conn:
                        try:
                            cursor.execute("ROLLBACK")
                        except:
                            pass
                        try:
                            conn.close()
                        except:
                            pass
                        conn = None
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                    continue
                else:
                    logger.error(f"Database operational error deleting user {user_id}: {e}")
                    # Rollback transaction on error
                    if conn:
                        try:
                            cursor.execute("ROLLBACK")
                        except:
                            pass
                    return False
            except Exception as e:
                logger.error(f"Error deleting user {user_id}: {e}")
                # Rollback transaction on error
                if conn:
                    try:
                        cursor.execute("ROLLBACK")
                    except:
                        pass
                return False
            finally:
                if conn:
                    try:
                        conn.close()
                    except:
                        pass
        
        # If we get here, all retries failed
        logger.error(f"Failed to delete user {user_id} after {max_retries} attempts")
        return False

    def get_all_users(self):
        """Get all users"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # This allows accessing columns by name
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT id, username, password_hash, minutes, is_admin, is_active, 
                       last_login, total_spent, created_at,
                       basic_minutes, standard_minutes, premium_minutes
                FROM users ORDER BY username
            ''')
            
            users = cursor.fetchall()
            conn.close()
            return [dict(user) for user in users]  # Convert to dictionaries
        except Exception as e:
            logger.error(f"Error getting users: {e}")
            return []
    
    def get_user_by_id(self, user_id):
        """Get user by ID"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # This allows accessing columns by name
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT id, username, password_hash, minutes, is_admin, is_active, 
                       last_login, total_spent, created_at,
                       basic_minutes, standard_minutes, premium_minutes
                FROM users WHERE id = ?
            ''', (user_id,))
            
            user = cursor.fetchone()
            conn.close()
            
            return dict(user) if user else None
        except Exception as e:
            logger.error(f"Error getting user by id {user_id}: {e}")
            return None
    
    def get_active_computers(self):
        """Get all active computers"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT computer_id, name, ip_address, status, last_seen
                FROM computers WHERE is_active = 1 ORDER BY last_seen DESC
            ''')
            
            computers = cursor.fetchall()
            conn.close()
            return computers
        except Exception as e:
            logger.error(f"Error getting computers: {e}")
            return []
    
    def get_active_sessions(self):
        """Get all active sessions"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT s.session_id, u.username, s.computer_id, s.start_time, s.duration_minutes
                FROM sessions s
                JOIN users u ON s.user_id = u.id
                WHERE s.is_active = 1
                ORDER BY s.start_time DESC
            ''')
            
            sessions = cursor.fetchall()
            conn.close()
            return sessions
        except Exception as e:
            logger.error(f"Error getting sessions: {e}")
            return []
    
    def register_computer(self, computer_id, name=None, ip_address=None):
        """Register/update computer"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO computers (computer_id, name, ip_address, status, last_seen)
                VALUES (?, ?, ?, 'online', CURRENT_TIMESTAMP)
            ''', (computer_id, name or computer_id, ip_address))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error registering computer: {e}")
            return False
    
    def delete_computer(self, computer_id):
        """Delete computer and all associated data"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Start transaction
            cursor.execute('BEGIN TRANSACTION')
            
            # Check if computer exists
            cursor.execute('SELECT id FROM computers WHERE computer_id = ?', (computer_id,))
            if not cursor.fetchone():
                conn.rollback()
                conn.close()
                logger.warning(f"Computer {computer_id} not found")
                return False
            
            # Check for active sessions
            cursor.execute('''
                SELECT COUNT(*) FROM sessions 
                WHERE computer_id = ? AND is_active = 1
            ''', (computer_id,))
            active_count = cursor.fetchone()[0]
            
            if active_count > 0:
                conn.rollback()
                conn.close()
                logger.warning(f"Cannot delete computer {computer_id} - has {active_count} active sessions")
                return False
            
            # Delete simulator configurations first (due to foreign key)
            cursor.execute('DELETE FROM simulator_configs WHERE computer_id = ?', (computer_id,))
            deleted_configs = cursor.rowcount
            
            # Update sessions to mark computer as deleted (preserve history)
            cursor.execute('''
                UPDATE sessions 
                SET computer_id = ? 
                WHERE computer_id = ?
            ''', (f"DELETED_{computer_id}", computer_id))
            updated_sessions = cursor.rowcount
            
            # Delete the computer
            cursor.execute('DELETE FROM computers WHERE computer_id = ?', (computer_id,))
            deleted_computers = cursor.rowcount
            
            # Commit transaction
            cursor.execute('COMMIT')
            conn.close()
            
            logger.info(f"Computer {computer_id} deleted successfully:")
            logger.info(f"  - Computer record: {deleted_computers}")
            logger.info(f"  - Simulator configs: {deleted_configs}")
            logger.info(f"  - Sessions updated: {updated_sessions}")
            
            return True
            
        except Exception as e:
            try:
                cursor.execute('ROLLBACK')
                conn.close()
            except:
                pass
            logger.error(f"Error deleting computer {computer_id}: {e}")
            return False
    
    def get_revenue_stats(self):
        """Get revenue statistics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Today's revenue
            cursor.execute('''
                SELECT COALESCE(SUM(amount), 0) FROM transactions
                WHERE DATE(created_at) = DATE('now')
            ''')
            today_revenue = cursor.fetchone()[0]
            
            # This month's revenue  
            cursor.execute('''
                SELECT COALESCE(SUM(amount), 0) FROM transactions
                WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')
            ''')
            month_revenue = cursor.fetchone()[0]
            
            # Total revenue
            cursor.execute('SELECT COALESCE(SUM(amount), 0) FROM transactions')
            total_revenue = cursor.fetchone()[0]
            
            # Active users count
            cursor.execute('SELECT COUNT(*) FROM users WHERE is_active = 1')
            active_users = cursor.fetchone()[0]
            
            conn.close()
            
            return {
                'today': today_revenue,
                'month': month_revenue,
                'total': total_revenue,
                'active_users': active_users
            }
        except Exception as e:
            logger.error(f"Error getting revenue stats: {e}")
            return {'today': 0, 'month': 0, 'total': 0, 'active_users': 0}
    
    def get_user_leaderboard(self, limit=10):
        """Get user leaderboard based on total playtime"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT u.username, 
                    COALESCE(SUM(s.duration_minutes), 0) as total_time_minutes,
                    COUNT(s.id) as sessions_played,
                    u.total_spent
                FROM users u
                LEFT JOIN sessions s ON u.id = s.user_id AND s.is_active = 0
                WHERE u.is_active = 1 AND u.username != 'admin'
                GROUP BY u.id, u.username, u.total_spent
                ORDER BY total_time_minutes DESC, u.total_spent DESC
                LIMIT ?
            ''', (limit,))
            
            leaderboard = cursor.fetchall()
            conn.close()
            return leaderboard
        except Exception as e:
            logger.error(f"Error getting leaderboard: {e}")
            return []

    def get_user_progress(self, user_id):
        """Get user progress data"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get user basic info
            cursor.execute('''
                SELECT username, minutes, total_spent, created_at, last_login
                FROM users WHERE id = ?
            ''', (user_id,))
            
            user_data = cursor.fetchone()
            if not user_data:
                return None
            
            username, minutes, total_spent, created_at, last_login = user_data
            
            # Get session stats
            cursor.execute('''
                SELECT COUNT(*), COALESCE(SUM(duration_minutes), 0)
                FROM sessions WHERE user_id = ? AND end_time IS NOT NULL
            ''', (user_id,))
            
            session_count, total_minutes = cursor.fetchone()
            
            # Get recent sessions
            cursor.execute('''
                SELECT start_time, duration_minutes, amount_paid
                FROM sessions 
                WHERE user_id = ? AND end_time IS NOT NULL
                ORDER BY start_time DESC LIMIT 10
            ''', (user_id,))
            
            recent_sessions = cursor.fetchall()
            
            conn.close()
            
            return {
                'username': username,
                'minutes_remaining': minutes,
                'total_spent': total_spent,
                'session_count': session_count,
                'total_minutes_played': total_minutes,
                'created_at': created_at,
                'last_login': last_login,
                'recent_sessions': [
                    {
                        'start_time': session[0],
                        'duration': session[1],
                        'amount_paid': session[2]
                    } for session in recent_sessions
                ]
            }
        except Exception as e:
            logger.error(f"Error getting user progress: {e}")
            return None

    # Posts management methods
    def create_post(self, title, content, author_id, category='general', featured=False):
        """Create a new post"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO posts (title, content, author_id, category, featured)
                VALUES (?, ?, ?, ?, ?)
            ''', (title, content, author_id, category, featured))
            
            post_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            logger.info(f"Created post: {title}")
            return post_id
        except Exception as e:
            logger.error(f"Error creating post: {e}")
            return None
    
    def get_posts(self, category=None, limit=None):
        """Get posts with optional filtering"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = '''
                SELECT p.id, p.title, p.content, p.category, p.featured, p.created_at, p.updated_at,
                       u.username as author
                FROM posts p
                LEFT JOIN users u ON p.author_id = u.id
                WHERE p.status = 'published'
            '''
            params = []
            
            if category:
                query += ' AND p.category = ?'
                params.append(category)
            
            query += ' ORDER BY p.featured DESC, p.created_at DESC'
            
            if limit:
                query += ' LIMIT ?'
                params.append(limit)
            
            cursor.execute(query, params)
            posts = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'id': post[0],
                    'title': post[1],
                    'content': post[2],
                    'category': post[3],
                    'featured': bool(post[4]),
                    'created_at': post[5],
                    'updated_at': post[6],
                    'author': post[7]
                } for post in posts
            ]
        except Exception as e:
            logger.error(f"Error getting posts: {e}")
            return []
    
    def update_post(self, post_id, title=None, content=None, category=None, featured=None):
        """Update a post"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            updates = []
            params = []
            
            if title is not None:
                updates.append('title = ?')
                params.append(title)
            if content is not None:
                updates.append('content = ?')
                params.append(content)
            if category is not None:
                updates.append('category = ?')
                params.append(category)
            if featured is not None:
                updates.append('featured = ?')
                params.append(featured)
            
            if updates:
                updates.append('updated_at = CURRENT_TIMESTAMP')
                params.append(post_id)
                
                query = f"UPDATE posts SET {', '.join(updates)} WHERE id = ?"
                cursor.execute(query, params)
                
                conn.commit()
                conn.close()
                return True
            
            conn.close()
            return False
        except Exception as e:
            logger.error(f"Error updating post: {e}")
            return False
    
    def delete_post(self, post_id):
        """Delete a post"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM posts WHERE id = ?', (post_id,))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error deleting post: {e}")
            return False

    # Token management methods
    def get_user_tokens(self, user_id):
        """Get user token balance"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT tokens, total_earned, total_spent, minutes_played, xp
                FROM user_tokens WHERE user_id = ?
            ''', (user_id,))
            
            result = cursor.fetchone()
            conn.close()
            
            if result:
                return {
                    'tokens': result[0],
                    'total_earned': result[1],
                    'total_spent': result[2],
                    'minutes_played': result[3] or 0,
                    'xp': result[4] or 0
                }
            else:
                # Create token record for new user
                self.create_user_tokens(user_id)
                return {'tokens': 0, 'total_earned': 0, 'total_spent': 0, 'minutes_played': 0, 'xp': 0}
        except Exception as e:
            logger.error(f"Error getting user tokens: {e}")
            return {'tokens': 0, 'total_earned': 0, 'total_spent': 0, 'minutes_played': 0, 'xp': 0}
    
    def create_user_tokens(self, user_id):
        """Create token record for user"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR IGNORE INTO user_tokens (user_id, tokens)
                VALUES (?, 0)
            ''', (user_id,))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error creating user tokens: {e}")
            return False
    
    def add_tokens(self, user_id, amount, description="Tokens earned"):
        """Add tokens to user account"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Ensure user has token record
            self.create_user_tokens(user_id)
            
            # Update tokens
            cursor.execute('''
                UPDATE user_tokens 
                SET tokens = tokens + ?, 
                    total_earned = total_earned + ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = ?
            ''', (amount, amount, user_id))
            
            # Record transaction
            cursor.execute('''
                INSERT INTO token_transactions (user_id, amount, transaction_type, description)
                VALUES (?, ?, 'earned', ?)
            ''', (user_id, amount, description))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error adding tokens: {e}")
            return False
    
    def spend_tokens(self, user_id, amount, description="Tokens spent", item_id=None):
        """Spend tokens from user account"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if user has enough tokens
            cursor.execute('SELECT tokens FROM user_tokens WHERE user_id = ?', (user_id,))
            result = cursor.fetchone()
            
            if not result or result[0] < amount:
                conn.close()
                return False
            
            # Update tokens
            cursor.execute('''
                UPDATE user_tokens 
                SET tokens = tokens - ?, 
                    total_spent = total_spent + ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = ?
            ''', (amount, amount, user_id))
            
            # Record transaction
            cursor.execute('''
                INSERT INTO token_transactions (user_id, amount, transaction_type, description, item_id)
                VALUES (?, ?, 'spent', ?, ?)
            ''', (user_id, -amount, description, item_id))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error spending tokens: {e}")
            return False

    # Shop items management methods
    def create_shop_item(self, title, description, category, price, **kwargs):
        """Create a new shop item"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO shop_items (title, description, category, price, original_price, 
                                      icon, popular, premium, limited, discount, stock, features, stats)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                title, description, category, price,
                kwargs.get('original_price'),
                kwargs.get('icon', '🎁'),
                kwargs.get('popular', False),
                kwargs.get('premium', False),
                kwargs.get('limited', False),
                kwargs.get('discount', 0),
                kwargs.get('stock', -1),
                kwargs.get('features'),
                kwargs.get('stats')
            ))
            
            item_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            logger.info(f"Created shop item: {title}")
            return item_id
        except Exception as e:
            logger.error(f"Error creating shop item: {e}")
            return None
    
    def get_shop_items(self, category=None, active_only=True):
        """Get shop items"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = 'SELECT * FROM shop_items'
            params = []
            
            conditions = []
            if active_only:
                conditions.append('is_active = 1')
            if category:
                conditions.append('category = ?')
                params.append(category)
            
            if conditions:
                query += ' WHERE ' + ' AND '.join(conditions)
            
            query += ' ORDER BY popular DESC, premium DESC, created_at DESC'
            
            cursor.execute(query, params)
            items = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'id': item[0],
                    'title': item[1],
                    'description': item[2],
                    'category': item[3],
                    'price': item[4],
                    'original_price': item[5],
                    'icon': item[6],
                    'popular': bool(item[7]),
                    'premium': bool(item[8]),
                    'limited': bool(item[9]),
                    'discount': item[10],
                    'stock': item[11],
                    'features': item[12],
                    'stats': item[13],
                    'is_active': bool(item[14]),
                    'created_at': item[15],
                    'updated_at': item[16]
                } for item in items
            ]
        except Exception as e:
            logger.error(f"Error getting shop items: {e}")
            return []
    
    def update_shop_item(self, item_id, **kwargs):
        """Update a shop item"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            updates = []
            params = []
            
            for field in ['title', 'description', 'category', 'price', 'original_price', 
                         'icon', 'popular', 'premium', 'limited', 'discount', 'stock', 
                         'features', 'stats', 'is_active']:
                if field in kwargs:
                    updates.append(f'{field} = ?')
                    params.append(kwargs[field])
            
            if updates:
                updates.append('updated_at = CURRENT_TIMESTAMP')
                params.append(item_id)
                
                query = f"UPDATE shop_items SET {', '.join(updates)} WHERE id = ?"
                cursor.execute(query, params)
                
                conn.commit()
                conn.close()
                return True
            
            conn.close()
            return False
        except Exception as e:
            logger.error(f"Error updating shop item: {e}")
            return False
    
    def delete_shop_item(self, item_id):
        """Delete a shop item"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM shop_items WHERE id = ?', (item_id,))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error deleting shop item: {e}")
            return False
    
    def purchase_item(self, user_id, item_id):
        """Purchase an item with tokens"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get item details
            cursor.execute('SELECT title, price, stock FROM shop_items WHERE id = ? AND is_active = 1', (item_id,))
            item = cursor.fetchone()
            
            if not item:
                conn.close()
                return False, "Item not found or inactive"
            
            title, price, stock = item
            
            # Check stock
            if stock == 0:
                conn.close()
                return False, "Item out of stock"
            
            # Check if user has enough tokens
            cursor.execute('SELECT tokens FROM user_tokens WHERE user_id = ?', (user_id,))
            user_tokens = cursor.fetchone()
            
            if not user_tokens or user_tokens[0] < price:
                conn.close()
                return False, "Insufficient tokens"
            
            # Process purchase
            cursor.execute('''
                UPDATE user_tokens 
                SET tokens = tokens - ?, 
                    total_spent = total_spent + ?,
                    last_updated = CURRENT_TIMESTAMP
                WHERE user_id = ?
            ''', (price, price, user_id))
            
            # Record purchase
            cursor.execute('''
                INSERT INTO user_purchases (user_id, item_id, tokens_spent)
                VALUES (?, ?, ?)
            ''', (user_id, item_id, price))
            
            # Record transaction
            cursor.execute('''
                INSERT INTO token_transactions (user_id, amount, transaction_type, description, item_id)
                VALUES (?, ?, 'spent', ?, ?)
            ''', (user_id, -price, f"Purchased {title}", item_id))
            
            # Update stock if limited
            if stock > 0:
                cursor.execute('UPDATE shop_items SET stock = stock - 1 WHERE id = ?', (item_id,))
            
            conn.commit()
            conn.close()
            return True, "Purchase successful"
        except Exception as e:
            logger.error(f"Error purchasing item: {e}")
            return False, "Purchase failed"
    
    def get_user_purchases(self, user_id):
        """Get user's purchase history"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT up.*, si.title, si.description, si.category, si.icon
            FROM user_purchases up
            JOIN shop_items si ON up.item_id = si.id
            WHERE up.user_id = ?
            ORDER BY up.purchase_date DESC
        ''', (user_id,))
        
        purchases = []
        for row in cursor.fetchall():
            purchases.append({
                'id': row[0],
                'user_id': row[1],
                'item_id': row[2],
                'tokens_spent': row[3],
                'purchase_date': row[4],
                'status': row[5],
                'item_title': row[6],
                'item_description': row[7],
                'item_category': row[8],
                'item_icon': row[9]
            })
        
        conn.close()
        return purchases

    # Tournament Management Methods
    
    def create_tournament(self, name, description, **kwargs):
        """Create a new tournament"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO tournaments (
                    name, description, category, status, start_date, end_date,
                    max_participants, entry_fee, prize_pool, first_prize, 
                    second_prize, third_prize, rules, requirements, 
                    image_url, created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                name, description, kwargs.get('category', 'racing'),
                kwargs.get('status', 'upcoming'), kwargs.get('start_date'),
                kwargs.get('end_date'), kwargs.get('max_participants', 50),
                kwargs.get('entry_fee', 0), kwargs.get('prize_pool', 0),
                kwargs.get('first_prize', 0), kwargs.get('second_prize', 0),
                kwargs.get('third_prize', 0), kwargs.get('rules'),
                kwargs.get('requirements'), kwargs.get('image_url'),
                kwargs.get('created_by')
            ))
            
            tournament_id = cursor.lastrowid
            conn.commit()
            logger.info(f"Tournament created with ID: {tournament_id}")
            return tournament_id
            
        except sqlite3.Error as e:
            logger.error(f"Error creating tournament: {e}")
            conn.rollback()
            return None
        finally:
            conn.close()
    
    def get_tournaments(self, status=None, limit=None):
        """Get tournaments with optional filtering"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = '''
            SELECT t.*,
                   COUNT(tr.id) as current_participants,
                   u.username as creator_name
            FROM tournaments t
            LEFT JOIN tournament_registrations tr ON t.id = tr.tournament_id AND tr.status = 'registered'
            LEFT JOIN users u ON t.created_by = u.id
        '''
        
        params = []
        if status:
            query += ' WHERE t.status = ?'
            params.append(status)
        
        query += ' GROUP BY t.id ORDER BY t.created_at DESC'
        
        if limit:
            query += ' LIMIT ?'
            params.append(limit)
        
        cursor.execute(query, params)
        
        tournaments = []
        for row in cursor.fetchall():
            tournaments.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'category': row[3],
                'status': row[4],
                'start_date': row[5],
                'end_date': row[6],
                'max_participants': row[7],
                'entry_fee': row[8],
                'prize_pool': row[9],
                'first_prize': row[10],
                'second_prize': row[11],
                'third_prize': row[12],
                'rules': row[13],
                'requirements': row[14],
                'image_url': row[15],
                'created_by': row[16],
                'created_at': row[17],
                'updated_at': row[18],
                'current_participants': row[19],
                'creator_name': row[20]
            })
        
        conn.close()
        return tournaments
    
    def register_for_tournament(self, tournament_id, user_id, notes=None):
        """Register user for tournament"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Check if tournament exists and has space
            cursor.execute('''
                SELECT t.max_participants, COUNT(tr.id) as current_participants
                FROM tournaments t
                LEFT JOIN tournament_registrations tr ON t.id = tr.tournament_id AND tr.status = 'registered'
                WHERE t.id = ? AND t.status = 'upcoming'
                GROUP BY t.id
            ''', (tournament_id,))
            
            result = cursor.fetchone()
            if not result:
                return False, "Tournament not found or not accepting registrations"
            
            max_participants, current_participants = result
            if current_participants >= max_participants:
                return False, "Tournament is full"
            
            # Check if user already registered
            cursor.execute('''
                SELECT id FROM tournament_registrations 
                WHERE tournament_id = ? AND user_id = ?
            ''', (tournament_id, user_id))
            
            if cursor.fetchone():
                return False, "Already registered for this tournament"
            
            # Register user
            cursor.execute('''
                INSERT INTO tournament_registrations (tournament_id, user_id, notes)
                VALUES (?, ?, ?)
            ''', (tournament_id, user_id, notes))
            
            conn.commit()
            return True, "Successfully registered for tournament"
            
        except sqlite3.Error as e:
            logger.error(f"Error registering for tournament: {e}")
            conn.rollback()
            return False, str(e)
        finally:
            conn.close()
    
    def get_tournament_participants(self, tournament_id):
        """Get participants for a tournament"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT tr.*, u.username, u.total_time_played
            FROM tournament_registrations tr
            JOIN users u ON tr.user_id = u.id
            WHERE tr.tournament_id = ? AND tr.status = 'registered'
            ORDER BY tr.registration_date ASC
        ''', (tournament_id,))
        
        participants = []
        for row in cursor.fetchall():
            participants.append({
                'id': row[0],
                'tournament_id': row[1],
                'user_id': row[2],
                'registration_date': row[3],
                'status': row[4],
                'notes': row[5],
                'username': row[6],
                'total_time_played': row[7]
            })
        
        conn.close()
        return participants
    
    def update_tournament_status(self, tournament_id, status):
        """Update tournament status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE tournaments SET status = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (status, tournament_id))
            
            conn.commit()
            return cursor.rowcount > 0
            
        except sqlite3.Error as e:
            logger.error(f"Error updating tournament status: {e}")
            conn.rollback()
            return False
        finally:
            conn.close()
    
    def add_tournament_results(self, tournament_id, results):
        """Add results for tournament participants"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            for result in results:
                cursor.execute('''
                    INSERT OR REPLACE INTO tournament_results 
                    (tournament_id, user_id, position, points, best_time, prize_tokens, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    tournament_id, result['user_id'], result['position'],
                    result.get('points', 0), result.get('best_time'),
                    result.get('prize_tokens', 0), result.get('notes')
                ))
                
                # Award tokens to winners
                if result.get('prize_tokens', 0) > 0:
                    self.add_tokens(result['user_id'], result['prize_tokens'], 
                                  f"Tournament prize - Position {result['position']}")
            
            conn.commit()
            return True
            
        except sqlite3.Error as e:
            logger.error(f"Error adding tournament results: {e}")
            conn.rollback()
            return False
        finally:
            conn.close()
    
    # Shopping Cart Methods
    
    def add_to_cart(self, user_id, item_id, quantity=1):
        """Add item to shopping cart"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO shopping_cart (user_id, item_id, quantity)
                VALUES (?, ?, ?)
            ''', (user_id, item_id, quantity))
            
            conn.commit()
            return True
            
        except sqlite3.Error as e:
            logger.error(f"Error adding to cart: {e}")
            conn.rollback()
            return False
        finally:
            conn.close()
    
    def get_cart_items(self, user_id):
        """Get user's cart items"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT sc.*, si.title, si.description, si.price, si.icon, si.stock
            FROM shopping_cart sc
            JOIN shop_items si ON sc.item_id = si.id
            WHERE sc.user_id = ? AND si.is_active = 1
            ORDER BY sc.added_at DESC
        ''', (user_id,))
        
        items = []
        for row in cursor.fetchall():
            items.append({
                'cart_id': row[0],
                'user_id': row[1],
                'item_id': row[2],
                'quantity': row[3],
                'added_at': row[4],
                'title': row[5],
                'description': row[6],
                'price': row[7],
                'icon': row[8],
                'stock': row[9],
                'total_price': row[7] * row[3]
            })
        
        conn.close()
        return items
    
    def remove_from_cart(self, user_id, item_id):
        """Remove item from cart"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                DELETE FROM shopping_cart 
                WHERE user_id = ? AND item_id = ?
            ''', (user_id, item_id))
            
            conn.commit()
            return cursor.rowcount > 0
            
        except sqlite3.Error as e:
            logger.error(f"Error removing from cart: {e}")
            conn.rollback()
            return False
        finally:
            conn.close()
    
    def clear_cart(self, user_id):
        """Clear user's cart"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('DELETE FROM shopping_cart WHERE user_id = ?', (user_id,))
            conn.commit()
            return True
            
        except sqlite3.Error as e:
            logger.error(f"Error clearing cart: {e}")
            conn.rollback()
            return False
        finally:
            conn.close()

    # Additional methods for website integration
    
    def get_recent_sessions(self, hours=24):
        """Get recent sessions for sync with simulator type information"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.id, s.session_id, s.user_id, s.computer_id, s.start_time, 
                   s.end_time, s.duration_minutes, s.amount_paid, s.is_active, 
                   s.simulator_type_id, u.username,
                   st.xp_per_minute, st.tokens_per_minute, st.name as simulator_type_name
            FROM sessions s
            JOIN users u ON s.user_id = u.id
            LEFT JOIN simulator_configs sc ON s.computer_id = sc.computer_id
            LEFT JOIN simulator_types st ON sc.simulator_type_id = st.id OR s.simulator_type_id = st.id
            WHERE s.start_time >= datetime('now', '-{} hours')
            ORDER BY s.start_time DESC
        '''.format(hours))
        
        sessions = []
        for row in cursor.fetchall():
            sessions.append({
                'id': row[0],
                'session_id': row[1],
                'user_id': row[2],
                'computer_id': row[3],
                'start_time': row[4],
                'end_time': row[5],
                'duration_minutes': row[6],
                'amount_paid': row[7],
                'is_active': bool(row[8]),
                'simulator_type_id': row[9],
                'username': row[10],
                'xp_per_minute': row[11] or 2,  # Default 2 if no type assigned
                'tokens_per_minute': row[12] or 2,  # Default 2 if no type assigned
                'simulator_type_name': row[13] or 'Basic'  # Default Basic if no type
            })
        
        conn.close()
        return sessions
    
    def get_user_sessions_with_rates(self, user_id):
        """Get user's sessions with simulator type rates for averaging"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.duration_minutes, 
                   COALESCE(st.xp_per_minute, 2) as xp_per_minute,
                   COALESCE(st.tokens_per_minute, 2) as tokens_per_minute,
                   st.name as simulator_type_name
            FROM sessions s
            LEFT JOIN simulator_configs sc ON s.computer_id = sc.computer_id
            LEFT JOIN simulator_types st ON sc.simulator_type_id = st.id OR s.simulator_type_id = st.id
            WHERE s.user_id = ? AND s.end_time IS NOT NULL AND s.duration_minutes > 0
            ORDER BY s.start_time DESC
        ''', (user_id,))
        
        sessions = []
        for row in cursor.fetchall():
            sessions.append({
                'duration_minutes': row[0],
                'xp_per_minute': row[1],
                'tokens_per_minute': row[2],
                'simulator_type_name': row[3] or 'Basic'
            })
        
        conn.close()
        return sessions
    
    def get_leaderboard(self, limit=100):
        """Get leaderboard data for sync"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT u.id, u.username, u.minutes, u.total_spent,
                   COALESCE(ut.tokens, 0) as tokens,
                   COALESCE(ut.xp, 0) as xp,
                   COUNT(s.id) as total_sessions
            FROM users u
            LEFT JOIN user_tokens ut ON u.id = ut.user_id
            LEFT JOIN sessions s ON u.id = s.user_id
            WHERE u.is_active = 1
            GROUP BY u.id
            ORDER BY u.minutes DESC, u.total_spent DESC
            LIMIT ?
        ''', (limit,))
        
        leaderboard = []
        for row in cursor.fetchall():
            leaderboard.append({
                'user_id': row[0],
                'username': row[1],
                'minutes': row[2],
                'total_spent': row[3],
                'tokens': row[4],
                'xp': row[5],
                'total_sessions': row[6]
            })
        
        conn.close()
        return leaderboard
    
    def update_user_tokens(self, user_id, tokens=None, xp=None, minutes_played=None):
        """Update user tokens and XP for website integration"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Ensure user_tokens record exists
            cursor.execute('SELECT id FROM user_tokens WHERE user_id = ?', (user_id,))
            if not cursor.fetchone():
                cursor.execute('''
                    INSERT INTO user_tokens (user_id, tokens, xp, minutes_played)
                    VALUES (?, 0, 0, 0)
                ''', (user_id,))
            
            # Update values
            updates = []
            values = []
            
            if tokens is not None:
                updates.append('tokens = ?')
                values.append(tokens)
                
            if xp is not None:
                updates.append('xp = ?')
                values.append(xp)
                
            if minutes_played is not None:
                updates.append('minutes_played = ?')
                values.append(minutes_played)
            
            if updates:
                updates.append('updated_at = CURRENT_TIMESTAMP')
                values.append(user_id)
                
                cursor.execute(f'''
                    UPDATE user_tokens SET {', '.join(updates)}
                    WHERE user_id = ?
                ''', values)
            
            conn.commit()
            return True
            
        except sqlite3.Error as e:
            logger.error(f"Error updating user tokens: {e}")
            conn.rollback()
            return False
        finally:
            conn.close()
    
    def sync_user_from_website(self, user_data):
        """Sync user data from website"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Check if user exists
            cursor.execute('SELECT id FROM users WHERE username = ?', (user_data['username'],))
            existing_user = cursor.fetchone()
            
            if existing_user:
                # Update existing user
                cursor.execute('''
                    UPDATE users SET 
                        minutes = ?, total_spent = ?, last_login = ?, is_active = ?
                    WHERE username = ?
                ''', (
                    user_data.get('minutes', 0),
                    user_data.get('total_spent', 0.0),
                    user_data.get('last_login'),
                    user_data.get('is_active', True),
                    user_data['username']
                ))
                user_id = existing_user[0]
            else:
                # Create new user
                cursor.execute('''
                    INSERT INTO users (username, password_hash, is_admin, minutes, total_spent, is_active)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    user_data['username'],
                    user_data.get('password_hash', self.hash_password('default123')),
                    user_data.get('is_admin', False),
                    user_data.get('minutes', 0),
                    user_data.get('total_spent', 0.0),
                    user_data.get('is_active', True)
                ))
                user_id = cursor.lastrowid
            
            # Update tokens and XP if provided
            if 'tokens' in user_data or 'xp' in user_data or 'minutes_played' in user_data:
                self.update_user_tokens(
                    user_id,
                    tokens=user_data.get('tokens'),
                    xp=user_data.get('xp'),
                    minutes_played=user_data.get('minutes_played')
                )
            
            conn.commit()
            return user_id
            
        except sqlite3.Error as e:
            logger.error(f"Error syncing user from website: {e}")
            conn.rollback()
            return None
        finally:
            conn.close()
    
    # ===== SIMULATOR MANAGEMENT METHODS =====
    
    def get_simulator_types(self):
        """Get all simulator types"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT id, name, display_name, xp_per_minute, tokens_per_minute, 
                       color, icon, description, is_active, created_at
                FROM simulator_types 
                WHERE is_active = 1
                ORDER BY xp_per_minute DESC
            ''')
            
            types = []
            for row in cursor.fetchall():
                types.append({
                    'id': row[0],
                    'name': row[1],
                    'display_name': row[2],
                    'xp_per_minute': row[3],
                    'tokens_per_minute': row[4],
                    'color': row[5],
                    'icon': row[6],
                    'description': row[7],
                    'is_active': bool(row[8]),
                    'created_at': row[9]
                })
            
            return types
            
        except sqlite3.Error as e:
            logger.error(f"Error getting simulator types: {e}")
            return []
        finally:
            conn.close()
    
    def get_simulator_configs(self):
        """Get all simulator configurations with type info"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT sc.id, sc.computer_id, sc.ip_address, sc.last_updated,
                       st.id as type_id, st.name as type_name, st.display_name, 
                       st.xp_per_minute, st.tokens_per_minute, st.color, st.icon,
                       c.name as computer_name, c.status
                FROM simulator_configs sc
                JOIN simulator_types st ON sc.simulator_type_id = st.id
                LEFT JOIN computers c ON sc.computer_id = c.computer_id
                ORDER BY sc.computer_id
            ''')
            
            configs = []
            for row in cursor.fetchall():
                configs.append({
                    'id': row[0],
                    'computer_id': row[1],
                    'ip_address': row[2],
                    'last_updated': row[3],
                    'type_id': row[4],
                    'type_name': row[5],
                    'type_display_name': row[6],
                    'xp_per_minute': row[7],
                    'tokens_per_minute': row[8],
                    'color': row[9],
                    'icon': row[10],
                    'computer_name': row[11],
                    'computer_status': row[12]
                })
            
            return configs
            
        except sqlite3.Error as e:
            logger.error(f"Error getting simulator configs: {e}")
            return []
        finally:
            conn.close()
    
    def assign_simulator_type(self, computer_id, simulator_type_id, ip_address=None):
        """Assign a simulator type to a computer"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Check if config already exists
            cursor.execute('''
                SELECT id FROM simulator_configs WHERE computer_id = ?
            ''', (computer_id,))
            
            existing = cursor.fetchone()
            
            if existing:
                # Update existing config
                cursor.execute('''
                    UPDATE simulator_configs 
                    SET simulator_type_id = ?, ip_address = ?, last_updated = CURRENT_TIMESTAMP
                    WHERE computer_id = ?
                ''', (simulator_type_id, ip_address, computer_id))
                logger.info(f"Updated simulator config for {computer_id} to type {simulator_type_id}")
            else:
                # Create new config
                cursor.execute('''
                    INSERT INTO simulator_configs (computer_id, simulator_type_id, ip_address)
                    VALUES (?, ?, ?)
                ''', (computer_id, simulator_type_id, ip_address))
                logger.info(f"Created simulator config for {computer_id} with type {simulator_type_id}")
            
            conn.commit()
            return True
            
        except sqlite3.Error as e:
            logger.error(f"Error assigning simulator type: {e}")
            conn.rollback()
            return False
        finally:
            conn.close()
    
    def get_simulator_type_by_computer(self, computer_id):
        """Get simulator type info for a specific computer"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT st.id, st.name, st.xp_per_minute, st.tokens_per_minute, 
                       st.color, st.icon
                FROM simulator_configs sc
                JOIN simulator_types st ON sc.simulator_type_id = st.id
                WHERE sc.computer_id = ? AND st.is_active = 1
            ''', (computer_id,))
            
            result = cursor.fetchone()
            if result:
                return {
                    'id': result[0],
                    'name': result[1],
                    'xp_per_minute': result[2],
                    'tokens_per_minute': result[3],
                    'color': result[4],
                    'icon': result[5]
                }
            else:
                # Return default "normal" type if no config found
                return {
                    'id': None,
                    'name': 'normal',
                    'xp_per_minute': 2,
                    'tokens_per_minute': 2,
                    'color': '#808080',
                    'icon': '🚗'
                }
                
        except sqlite3.Error as e:
            logger.error(f"Error getting simulator type by computer: {e}")
            return None
        finally:
            conn.close()
    
    def update_simulator_type_rates(self, type_id, xp_per_minute=None, tokens_per_minute=None):
        """Update XP and token rates for a simulator type"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            updates = []
            values = []
            
            if xp_per_minute is not None:
                updates.append('xp_per_minute = ?')
                values.append(xp_per_minute)
                
            if tokens_per_minute is not None:
                updates.append('tokens_per_minute = ?')
                values.append(tokens_per_minute)
            
            if updates:
                values.append(type_id)
                cursor.execute(f'''
                    UPDATE simulator_types SET {', '.join(updates)}
                    WHERE id = ?
                ''', values)
                
                conn.commit()
                logger.info(f"Updated simulator type {type_id} rates")
                return True
            
            return False
            
        except sqlite3.Error as e:
            logger.error(f"Error updating simulator type rates: {e}")
            conn.rollback()
            return False
        finally:
            conn.close()
    
    def check_user_has_minutes_for_simulator(self, user_id, simulator_type_name, required_minutes=1):
        """Check if user has enough minutes for specific simulator type"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # First, ensure the minute type columns exist
            self._ensure_minute_columns(cursor)
            
            # Map simulator type names to column names
            type_column_map = {
                'basic': 'basic_minutes',
                'normal': 'basic_minutes',  # Fixed: normal should map to basic_minutes
                'standard': 'standard_minutes',
                'medium': 'standard_minutes',
                'premium': 'premium_minutes'
            }
            
            column_name = type_column_map.get(simulator_type_name.lower(), 'basic_minutes')
            
            cursor.execute(f'''
                SELECT {column_name}, minutes FROM users WHERE id = ?
            ''', (user_id,))
            
            result = cursor.fetchone()
            conn.close()
            
            if result:
                specific_minutes = result[0] or 0
                total_minutes = result[1] or 0
                
                # Check if user has enough minutes of the specific type first
                if specific_minutes >= required_minutes:
                    return True
                
                # If no specific minutes, check total minutes as fallback (for backward compatibility)
                if specific_minutes == 0 and total_minutes >= required_minutes:
                    return True
                
                return False
            
            return False
            
        except Exception as e:
            logger.error(f"Error checking user minutes for simulator: {e}")
            return False
    
    def get_user_minutes_by_type(self, user_id):
        """Get user's minutes breakdown by type"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # First, ensure the minute type columns exist
            self._ensure_minute_columns(cursor)
            
            cursor.execute('''
                SELECT minutes, basic_minutes, standard_minutes, premium_minutes
                FROM users WHERE id = ?
            ''', (user_id,))
            
            result = cursor.fetchone()
            conn.close()
            
            if result:
                return {
                    'total_minutes': result[0] or 0,
                    'basic_minutes': result[1] or 0,
                    'standard_minutes': result[2] or 0,
                    'premium_minutes': result[3] or 0
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting user minutes by type: {e}")
            return None 