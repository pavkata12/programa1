#!/usr/bin/env python3
"""
Production Bridge - Syncs local NetCafe data with hosted website
"""

import asyncio
import aiohttp
import json
import time
import logging
from datetime import datetime
from database import NetCafeDatabase
import os
import hmac
import hashlib

# Configuration
WEBSITE_API_URL = os.environ.get("WEBSITE_API_URL", "https://simracingacademy.eu/api")
API_KEY = os.environ.get("EXTERNAL_API_KEY", "netcafe-bridge-2025-9f3b7e2a1c64f0d8")
SYNC_HMAC_SECRET = os.environ.get("SYNC_HMAC_SECRET", "p6mA5Q517oV8rN2c4bQ2yVrJ6k1k8CwU2kB3ZQy0mH8vF1+eKspmOw==")
SYNC_INTERVAL = 60  # PERFORMANCE OPTIMIZATION: Changed from 30 to 60 seconds for 500+ users
MAX_RETRIES = 3

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('production_bridge.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ProductionBridge:
    def __init__(self):
        self.db = NetCafeDatabase()
        self.session = None
        self.running = False
        self.last_sync = {}
        
    async def start(self):
        """Start the production bridge"""
        logger.info("Starting Production Bridge...")
        self.running = True
        
        # Create HTTP session
        timeout = aiohttp.ClientTimeout(total=30)
        # Add SSL verification bypass for development/testing
        connector = aiohttp.TCPConnector(ssl=False)
        self.session = aiohttp.ClientSession(
            timeout=timeout,
            connector=connector,
            headers={
                'x-api-key': API_KEY,  # Use consistent header name
                'Content-Type': 'application/json',
                'User-Agent': 'NetCafe-ProductionBridge/1.0'
            }
        )
        
        # Test connection
        if await self.test_connection():
            logger.info("Connection to website established")
            
            # Start sync loop
            while self.running:
                try:
                    await self.sync_all_data()
                    await asyncio.sleep(SYNC_INTERVAL)
                except Exception as e:
                    logger.error(f"Sync error: {e}")
                    await asyncio.sleep(5)  # Wait before retry
        else:
            logger.error("Cannot connect to website API")
            
    async def stop(self):
        """Stop the bridge"""
        logger.info("Stopping Production Bridge...")
        self.running = False
        if self.session:
            await self.session.close()
            
    async def test_connection(self):
        """Test connection to website"""
        try:
            async with self.session.get(f"{WEBSITE_API_URL}/health") as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"Website status: {data.get('message', 'OK')}")
                    return True
                else:
                    logger.error(f"Website returned status: {response.status}")
                    return False
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False
            
    async def sync_all_data(self):
        """Sync all data types"""
        try:
            # Sync users (most important)
            await self.sync_users()
            
            # Sync sessions
            await self.sync_sessions()
            
            # Sync leaderboard
            await self.sync_leaderboard()
            
            # Sync simulator types
            await self.sync_simulator_types()
            
            logger.info("All data synced successfully")
            
        except Exception as e:
            logger.error(f"Sync failed: {e}")
            
    async def sync_users(self):
        """Sync user data with total playtime from sessions"""
        try:
            # Get all users from local database
            users = self.db.get_all_users()
            
            # Prepare sync data
            sync_data = {
                'users': [],
                'timestamp': datetime.now().isoformat()
            }
            
            for user in users:
                # Calculate total playtime from completed sessions
                user_progress = self.db.get_user_progress(user['id'])
                total_playtime_minutes = user_progress['total_minutes_played'] if user_progress else 0
                
                # Calculate average XP/Token rates for this user based on their sessions
                user_sessions = self.db.get_user_sessions_with_rates(user['id'])
                avg_xp_rate = 2  # Default Basic rate
                avg_token_rate = 2  # Default Basic rate
                
                if user_sessions:
                    total_minutes = sum(s.get('duration_minutes', 0) for s in user_sessions if s.get('duration_minutes'))
                    if total_minutes > 0:
                        weighted_xp = sum((s.get('duration_minutes', 0) * s.get('xp_per_minute', 2)) for s in user_sessions)
                        weighted_tokens = sum((s.get('duration_minutes', 0) * s.get('tokens_per_minute', 2)) for s in user_sessions)
                        avg_xp_rate = round(weighted_xp / total_minutes, 1)
                        avg_token_rate = round(weighted_tokens / total_minutes, 1)
                
                # Debug log for pavka
                if user['username'] == 'pavka':
                    logger.info(f"DEBUG: pavka - remaining: {user['minutes']}, total_played: {total_playtime_minutes}, avg_rates: {avg_xp_rate}XP/{avg_token_rate}T")
                
                sync_data['users'].append({
                    'id': user['id'],
                    'username': user['username'],
                    'password_hash': user['password_hash'],
                    'is_admin': bool(user['is_admin']),
                    'minutes': total_playtime_minutes,  # Use total playtime instead of remaining minutes
                    'remaining_minutes': user['minutes'],  # Keep original for reference
                    'basic_minutes': user.get('basic_minutes', 0),
                    'standard_minutes': user.get('standard_minutes', 0),
                    'premium_minutes': user.get('premium_minutes', 0),
                    'total_spent': user['total_spent'],
                    'created_at': user['created_at'],
                    'last_login': user['last_login'],
                    'is_active': bool(user['is_active']),
                    'xp_per_minute': avg_xp_rate,  # Average XP rate from user's sessions
                    'tokens_per_minute': avg_token_rate  # Average token rate from user's sessions
                })
            
            # Send to website
            headers = {
                'x-api-key': API_KEY,
                'Content-Type': 'application/json'
            }
            if SYNC_HMAC_SECRET:
                ts = str(int(time.time() * 1000))
                body = json.dumps(sync_data, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
                sig = hmac.new(SYNC_HMAC_SECRET.encode('utf-8'), (ts + '.').encode('utf-8') + body, hashlib.sha256).hexdigest()
                headers.update({'x-timestamp': ts, 'x-signature': sig})

            async with self.session.post(
                f"{WEBSITE_API_URL}/sync/users",
                json=sync_data,
                headers=headers
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    logger.info(f"Users synced: {len(sync_data['users'])}")
                else:
                    logger.error(f"User sync failed: {response.status}")
                    
        except Exception as e:
            logger.error(f"User sync error: {e}")
            
    async def sync_sessions(self):
        """Sync session data"""
        try:
            # Get recent sessions (last 24 hours)
            sessions = self.db.get_recent_sessions(24)
            
            if not sessions:
                return
                
            sync_data = {
                'sessions': sessions,
                'timestamp': datetime.now().isoformat()
            }
            
            headers = {
                'x-api-key': API_KEY,
                'Content-Type': 'application/json'
            }
            if SYNC_HMAC_SECRET:
                ts = str(int(time.time() * 1000))
                body = json.dumps(sync_data, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
                sig = hmac.new(SYNC_HMAC_SECRET.encode('utf-8'), (ts + '.').encode('utf-8') + body, hashlib.sha256).hexdigest()
                headers.update({'x-timestamp': ts, 'x-signature': sig})

            async with self.session.post(
                f"{WEBSITE_API_URL}/sync/sessions",
                json=sync_data,
                headers=headers
            ) as response:
                if response.status == 200:
                    logger.info(f"Sessions synced: {len(sessions)}")
                else:
                    logger.error(f"Session sync failed: {response.status}")
                    
        except Exception as e:
            logger.error(f"Session sync error: {e}")
            
    async def sync_leaderboard(self):
        """Sync leaderboard data"""
        try:
            # Get leaderboard data
            leaderboard = self.db.get_leaderboard(100)
            
            sync_data = {
                'leaderboard': leaderboard,
                'timestamp': datetime.now().isoformat()
            }
            
            headers = {
                'x-api-key': API_KEY,
                'Content-Type': 'application/json'
            }
            if SYNC_HMAC_SECRET:
                ts = str(int(time.time() * 1000))
                body = json.dumps(sync_data, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
                sig = hmac.new(SYNC_HMAC_SECRET.encode('utf-8'), (ts + '.').encode('utf-8') + body, hashlib.sha256).hexdigest()
                headers.update({'x-timestamp': ts, 'x-signature': sig})

            async with self.session.post(
                f"{WEBSITE_API_URL}/sync/leaderboard",
                json=sync_data,
                headers=headers
            ) as response:
                if response.status == 200:
                    logger.info(f"Leaderboard synced: {len(leaderboard)} entries")
                else:
                    logger.error(f"Leaderboard sync failed: {response.status}")
                    
        except Exception as e:
            logger.error(f"Leaderboard sync error: {e}")
            
    async def sync_simulator_types(self):
        """Sync simulator types and configurations"""
        try:
            # Get simulator types and configurations
            simulator_types = self.db.get_simulator_types()
            simulator_configs = self.db.get_simulator_configs()
            
            sync_data = {
                'simulator_types': simulator_types,
                'simulator_configs': simulator_configs,
                'timestamp': datetime.now().isoformat()
            }
            
            headers = {
                'x-api-key': API_KEY,
                'Content-Type': 'application/json'
            }
            if SYNC_HMAC_SECRET:
                ts = str(int(time.time() * 1000))
                body = json.dumps(sync_data, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
                sig = hmac.new(SYNC_HMAC_SECRET.encode('utf-8'), (ts + '.').encode('utf-8') + body, hashlib.sha256).hexdigest()
                headers.update({'x-timestamp': ts, 'x-signature': sig})

            async with self.session.post(
                f"{WEBSITE_API_URL}/sync/simulator-types",
                json=sync_data,
                headers=headers
            ) as response:
                if response.status == 200:
                    logger.info(f"Simulator types synced: {len(simulator_types)} types, {len(simulator_configs)} configs")
                else:
                    logger.error(f"Simulator types sync failed: {response.status}")
                    
        except Exception as e:
            logger.error(f"Simulator types sync error: {e}")

# Main execution
async def main():
    bridge = ProductionBridge()
    
    try:
        await bridge.start()
    except KeyboardInterrupt:
        logger.info("🛑 Shutting down...")
    finally:
        await bridge.stop()

if __name__ == "__main__":
    print("🚀 NetCafe Production Bridge")
    print("=" * 50)
    print(f"Website API: {WEBSITE_API_URL}")
    print(f"Sync Interval: {SYNC_INTERVAL}s")
    print("=" * 50)
    
    asyncio.run(main()) 