# 🚀 NetCafe Server - Setup Guide for New PC

## Prerequisites
1. **Python 3.8+** installed
2. **Internet connection**
3. **Administrator privileges** (for environment variables)

## Step 1: Install Python Dependencies

```bash
# Navigate to server directory
cd "C:\path\to\your\programa\server"

# Install required packages
pip install aiohttp>=3.8.0 aiohttp-cors>=0.7.0 PyJWT>=2.8.0
```

## Step 2: Set Environment Variables

**Open Command Prompt as Administrator** and run:

```cmd
setx EXTERNAL_API_KEY "netcafe-bridge-2025-9f3b7e2a1c64f0d8"
setx SYNC_HMAC_SECRET "p6mA5Q517oV8rN2c4bQ2yVrJ6k1k8CwU2kB3ZQy0mH8vF1+eKspmOw=="
setx WEBSITE_API_URL "https://simracingacademy.eu/api"
```

**⚠️ IMPORTANT:** After setting environment variables, you MUST:
- Close ALL command prompt/PowerShell windows
- Restart your terminal
- Or reboot the computer

## Step 3: Verify Environment Variables

```powershell
echo $env:EXTERNAL_API_KEY
echo $env:SYNC_HMAC_SECRET
echo $env:WEBSITE_API_URL
```

## Step 4: Test Connection

Create a test file `test_api.py`:

```python
import os
import asyncio
import aiohttp

async def test():
    API_KEY = os.environ.get("EXTERNAL_API_KEY")
    URL = os.environ.get("WEBSITE_API_URL", "https://simracingacademy.eu/api")
    
    print(f"API Key: {API_KEY}")
    print(f"URL: {URL}")
    
    connector = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=connector) as session:
        async with session.get(f"{URL}/health", headers={'x-api-key': API_KEY}) as resp:
            print(f"Status: {resp.status}")
            data = await resp.json()
            print(f"Response: {data}")

asyncio.run(test())
```

Run: `python test_api.py`

## Step 5: Run Production Bridge

```bash
python production_bridge.py
```

## Common Issues & Solutions

### Issue 1: "can't open file"
- Make sure you're in the correct directory: `cd programa\server`
- Check if `production_bridge.py` exists: `dir production_bridge.py`

### Issue 2: Environment variables not working
- **RESTART YOUR TERMINAL** after setting env vars
- Verify with: `echo $env:EXTERNAL_API_KEY`

### Issue 3: SSL Certificate errors
- The code now bypasses SSL verification for development
- If still issues, check firewall/antivirus

### Issue 4: 401 Unauthorized
- Check API key is correct
- Verify environment variables are set
- Make sure you restarted terminal after setting env vars

## File Structure Should Look Like:
```
programa/
├── server/
│   ├── production_bridge.py  ← This file must exist
│   ├── database.py
│   ├── server_api.py
│   ├── requirements.txt
│   └── netcafe.db
└── client/
    └── ...
```
