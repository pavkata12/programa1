import sqlite3
from database import NetCafeDatabase
import json

def get_leaderboard_data():
    """Get formatted leaderboard data for the website"""
    db = NetCafeDatabase()
    conn = sqlite3.connect('netcafe.db')
    cursor = conn.cursor()
    
    # Get user leaderboard with racing stats
    cursor.execute('''
        SELECT u.username, u.minutes, u.total_spent, u.last_login,
               COUNT(DISTINCT s.id) as session_count,
               COALESCE(SUM(s.duration_minutes), 0) as total_play_time,
               u.created_at
        FROM users u
        LEFT JOIN sessions s ON u.id = s.user_id
        WHERE u.username != 'admin' AND u.is_active = 1
        GROUP BY u.id, u.username
        ORDER BY total_play_time DESC, u.total_spent DESC
    ''')
    
    users = cursor.fetchall()
    leaderboard = []
    
    for i, user in enumerate(users):
        username = user[0]
        minutes_available = user[1]
        total_spent = user[2]
        last_login = user[3]
        session_count = user[4]
        total_play_time = user[5]
        created_at = user[6]
        
        # Calculate hours played
        hours_played = total_play_time / 60
        
        # Calculate XP and tokens based on simulator types and session data
        cursor.execute('''
            SELECT s.duration_minutes, st.xp_per_minute, st.tokens_per_minute
            FROM sessions s
            LEFT JOIN simulator_configs sc ON s.computer_id = sc.computer_id  
            LEFT JOIN simulator_types st ON sc.simulator_type_id = st.id
            WHERE s.user_id = (SELECT id FROM users WHERE username = ?) 
            AND s.end_time IS NOT NULL
        ''', (username,))
        
        user_sessions = cursor.fetchall()
        total_xp = 0
        total_base_tokens = 0
        
        for session in user_sessions:
            duration = session[0] or 0
            xp_rate = session[1] or 2  # Default 2 XP/min if no type assigned
            token_rate = session[2] or 2  # Default 2 tokens/min if no type assigned
            
            total_xp += duration * xp_rate
            total_base_tokens += duration * token_rate
        
        xp = int(total_xp)
        
        # Determine level based on XP with updated thresholds
        if xp >= 19200:
            level = "Unreal"
            level_multiplier = 2.0
        elif xp >= 12000:
            level = "Elite"
            level_multiplier = 1.8
        elif xp >= 5400:
            level = "Pro"
            level_multiplier = 1.6
        elif xp >= 1800:
            level = "Intermediate"
            level_multiplier = 1.4
        elif xp >= 600:
            level = "Novice"
            level_multiplier = 1.2
        else:
            level = "Beginner"
            level_multiplier = 1.0
        
        # Apply tier multiplier to tokens
        tokens = int(total_base_tokens * level_multiplier)
        
        leaderboard.append({
            "rank": i + 1,
            "username": username,
            "xp": xp,
            "level": level,
            "tokens": tokens,
            "total_play_time": total_play_time,
            "total_sessions": session_count,
            "total_spent": total_spent,
            "last_login": last_login,
            "member_since": created_at,
            "hours_played": round(total_play_time / 60, 1)
        })
    
    conn.close()
    return leaderboard

def get_recent_sessions():
    """Get recent racing sessions for activity feed"""
    conn = sqlite3.connect('netcafe.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT u.username, s.start_time, s.end_time, s.duration_minutes, s.computer_id
        FROM sessions s
        JOIN users u ON s.user_id = u.id
        WHERE u.username != 'admin' AND s.duration_minutes > 0
        ORDER BY s.start_time DESC
        LIMIT 50
    ''')
    
    sessions = cursor.fetchall()
    recent_activity = []
    
    for session in sessions:
        username = session[0]
        start_time = session[1]
        end_time = session[2]
        duration = session[3]
        computer = session[4]
        
        recent_activity.append({
            "username": username,
            "start_time": start_time,
            "end_time": end_time,
            "duration_minutes": duration,
            "computer_id": computer,
            "activity_type": "racing_session"
        })
    
    conn.close()
    return recent_activity

if __name__ == "__main__":
    print("=== RED ZONE VR RACING LEADERBOARD ===")
    leaderboard = get_leaderboard_data()
    
    print(f"Top {len(leaderboard)} Racers:\n")
    
    for player in leaderboard:
        print(f"#{player['rank']} {player['username']}")
        print(f"   🏆 Level: {player['level']} ({player['xp']} XP)")
        print(f"   🪙 Tokens: {player['tokens']}")
        print(f"   🏁 {player['hours_played']} hours racing")
        print(f"   🎮 {player['total_sessions']} sessions")
        print(f"   💰 {player['total_spent']} BGN spent")
        print()
    
    print("\n=== RECENT RACING ACTIVITY ===")
    recent = get_recent_sessions()
    
    for activity in recent[:10]:
        print(f"🏎️  {activity['username']} raced for {activity['duration_minutes']} minutes")
        print(f"   {activity['start_time']}")
        print()
    
    # Export to JSON for website integration
    export_data = {
        "leaderboard": leaderboard,
        "recent_activity": recent,
        "stats": {
            "total_racers": len(leaderboard),
            "total_sessions": sum(p['total_sessions'] for p in leaderboard),
            "total_hours": sum(p['hours_played'] for p in leaderboard)
        }
    }
    
    with open('leaderboard_export.json', 'w', encoding='utf-8') as f:
        json.dump(export_data, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Exported leaderboard data to leaderboard_export.json")
    print(f"📊 Total racers: {export_data['stats']['total_racers']}")
    print(f"🎮 Total sessions: {export_data['stats']['total_sessions']}")
    print(f"⏱️ Total racing hours: {export_data['stats']['total_hours']}") 