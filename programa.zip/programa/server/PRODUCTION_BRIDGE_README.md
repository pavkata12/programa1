# 🌐 Production Bridge - NetCafe to Website Sync

## 📋 Overview

The Production Bridge is a new feature in the NetCafe Pro Admin Panel that allows real-time synchronization between your local NetCafe system and a hosted website.

## 🚀 Features

### 📊 **Admin Panel Integration**
- **New Tab**: "🌐 Production Bridge" in Admin Panel
- **Status Monitoring**: Real-time bridge status indicator
- **Sync Statistics**: Users, sessions, and leaderboard sync counts
- **Log Viewer**: Production bridge logs in admin interface
- **Controls**: Start/Stop bridge directly from admin panel

### 🔄 **Real-time Sync**
- **Users**: Sync user profiles and playtime
- **Sessions**: Active and completed sessions
- **Leaderboard**: XP rankings and statistics
- **Interval**: 30 seconds automatic sync

### 📱 **Status Bar Indicator**
- **🟢 Bridge: On** - Bridge is running and syncing
- **🔴 Bridge: Off** - Bridge is not running
- **🟡 Bridge: Starting...** - Bridge is starting up

## 🛠️ Usage

### **Starting the Bridge**
1. Open Admin Panel → "🌐 Production Bridge" tab
2. Click "▶️ Start Bridge" button
3. Bridge will start with a visible console window showing sync activity
4. Status will change to "🟢 Running"

### **Stopping the Bridge**
1. Go to "🌐 Production Bridge" tab
2. Click "⏹️ Stop Bridge" button
3. Bridge process will be terminated
4. Status will change to "🔴 Not Running"

### **Monitoring**
- **Status**: Check if bridge is running
- **Last Sync**: When was the last successful sync
- **Statistics**: How many users/sessions/leaderboard entries synced
- **Logs**: View bridge activity logs

## 📁 Files

- `production_bridge.py` - Main bridge script
- `production_bridge.log` - Bridge activity logs
- `START_PRODUCTION_BRIDGE.bat` - Manual bridge launcher
- `START_PRODUCTION_BRIDGE_HIDDEN.bat` - Hidden bridge launcher
- `test_bridge_hidden.py` - Test script for hidden startup
- `admin_gui.py` - Updated with bridge monitoring

## ⚙️ Configuration

Edit `production_bridge.py` to configure:
```python
WEBSITE_API_URL = "https://simracingacademy.eu/api"
API_KEY = "netcafe-bridge-2024-secure-key"
SYNC_INTERVAL = 30  # seconds
```

## 🎯 Manual Startup Options

### **Option 1: Admin Panel (Recommended)**
- Start from Admin Panel → Production Bridge tab
- Automatic hidden startup
- Real-time monitoring

### **Option 2: Hidden Batch File**
```bash
START_PRODUCTION_BRIDGE_HIDDEN.bat
```

### **Option 3: Test Hidden Startup**
```bash
cd server
python test_bridge_hidden.py
```

## 🔧 Technical Details

### **Process Management**
- Bridge runs as separate Python process
- Admin panel monitors bridge process via psutil
- Automatic process detection and termination
- **Visible console**: Bridge starts with console window showing sync activity

### **Logging**
- Comprehensive logging to `production_bridge.log`
- Admin panel displays last 50 log lines
- Log clearing functionality

### **Error Handling**
- Connection retry logic
- Graceful error handling
- Status updates on connection issues

## 🚨 Troubleshooting

### **Bridge Won't Start**
1. Check if `production_bridge.py` exists
2. Verify Python environment
3. Check admin panel logs

### **Sync Issues**
1. Verify website URL is correct
2. Check API key configuration
3. Ensure internet connection
4. Review bridge logs for errors

### **Status Not Updating**
1. Refresh bridge status manually
2. Check if bridge process is running
3. Review admin panel logs

## 📊 Requirements

Additional requirement added to `server/requirements.txt`:
```
psutil>=5.9.0
```

## 🎯 Benefits

- **Real-time Sync**: Website always shows current NetCafe data
- **Easy Management**: Control bridge from admin panel
- **Monitoring**: Full visibility into sync process
- **Reliable**: Automatic error handling and retry logic
- **Visible Operation**: Bridge runs with console window showing real-time sync activity
- **Live Monitoring**: See sync progress in real-time

---

**🌐 Production Bridge - Connecting your NetCafe to the world!** 