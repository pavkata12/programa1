# 📦 Server Dependencies Guide

## 🎯 Quick Reference

### Minimal Server (Core Functionality):
```bash
pip install aiohttp>=3.8.0 aiohttp-cors>=0.7.0 PyJWT>=2.8.0
```
**Enables:** server.py, server_api.py, database.py, leaderboard_api.py, production_bridge.py

### Admin GUI (Optional):
```bash
pip install PySide6>=6.5.0 qasync>=0.24.0
```
**Enables:** admin_gui.py (desktop interface)

---

## 📋 File-by-File Dependencies

| File | Built-in Modules | External Dependencies | Notes |
|------|------------------|----------------------|-------|
| `server.py` | asyncio, logging | server_api (local) | Main entry point |
| `server_api.py` | asyncio, json, logging, datetime, uuid, os | aiohttp, aiohttp-cors, jwt | Core API server |
| `database.py` | sqlite3, hashlib, uuid, datetime, logging, time | None | Database layer |
| `leaderboard_api.py` | sqlite3, json | None | Leaderboard functionality |
| `production_bridge.py` | asyncio, json, time, logging, datetime, os, hmac, hashlib | aiohttp | Website sync |
| `admin_gui.py` | sys, asyncio, json, logging, datetime, threading, time, os | aiohttp, PySide6, qasync | Desktop GUI |

---

## 🚀 Installation Strategies

### Strategy 1: Start Minimal
```bash
# Install only core server
pip install -r requirements-minimal.txt
python server.py  # Test if it works

# Add GUI later if needed
pip install -r requirements-gui.txt
python admin_gui.py  # Test GUI
```

### Strategy 2: Full Installation
```bash
# Install everything at once
pip install -r requirements.txt
```

### Strategy 3: Manual Installation
```bash
# Core dependencies one by one
pip install aiohttp>=3.8.0
pip install aiohttp-cors>=0.7.0
pip install PyJWT>=2.8.0

# GUI dependencies (optional)
pip install PySide6>=6.5.0
pip install qasync>=0.24.0
```

---

## 🔧 Troubleshooting

### Problem: "ModuleNotFoundError: No module named 'aiohttp'"
```bash
# Solution:
pip install aiohttp>=3.8.0
```

### Problem: "ModuleNotFoundError: No module named 'jwt'"
```bash
# Solution (note: it's PyJWT, not jwt):
pip install PyJWT>=2.8.0
```

### Problem: "ModuleNotFoundError: No module named 'PySide6'"
```bash
# Solution (only needed for admin_gui.py):
pip install PySide6>=6.5.0
```

### Problem: Server starts but admin_gui.py fails
```bash
# This is normal if you only installed minimal requirements
# Install GUI dependencies:
pip install -r requirements-gui.txt
```

### Problem: Import errors on Windows
```bash
# Upgrade pip first:
python -m pip install --upgrade pip

# Then install dependencies:
pip install -r requirements-minimal.txt
```

### Problem: Import errors on Linux
```bash
# Make sure you're in virtual environment:
python3 -m venv venv
source venv/bin/activate

# Then install:
pip install -r requirements-minimal.txt
```

---

## ✅ Testing Dependencies

### Test Core Server:
```bash
python -c "import aiohttp, jwt; from aiohttp_cors import setup; print('✅ Core OK')"
python -c "from database import NetCafeDatabase; print('✅ Database OK')"
```

### Test Admin GUI:
```bash
python -c "from PySide6.QtWidgets import QApplication; import qasync; print('✅ GUI OK')"
```

### Test Full System:
```bash
# Start server in background
python server.py &

# Test API endpoint
curl http://localhost:8080/api/status

# Stop server
pkill -f server.py
```

---

## 🎯 What Each Component Does

### Core Server (`requirements-minimal.txt`):
- **API Server:** Handles client connections, authentication, sessions
- **Database:** Stores users, sessions, computers, simulator configurations
- **WebSocket:** Real-time communication with clients
- **Leaderboard:** Generates ranking data
- **Production Bridge:** Syncs data with external website

### Admin GUI (`requirements-gui.txt`):
- **Desktop Interface:** Visual admin panel for managing users/sessions
- **Real-time Stats:** Live dashboard with system statistics
- **User Management:** Create/edit users, manage minutes, view sessions
- **System Monitoring:** View logs, system status, connected clients

---

## 📝 Notes

1. **SQLite is built-in** - No external database server needed
2. **admin_gui.py is optional** - Server works fine without GUI
3. **production_bridge.py is optional** - Only needed for website sync
4. **All files use standard library** except for the external dependencies listed above
5. **Virtual environment recommended** for clean installations
