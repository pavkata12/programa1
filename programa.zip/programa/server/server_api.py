import asyncio
import json
import logging
from datetime import datetime
from aiohttp import web, WSMsgType
from aiohttp_cors import setup as cors_setup, ResourceOptions
from database import NetCafeDatabase
import jwt
import uuid

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('netcafe_server')

# Initialize database
db = NetCafeDatabase()

# JWT Secret key (configure via environment in production)
import os
JWT_SECRET = os.environ.get('NETCAFE_JWT_SECRET', 'netcafe_pro_2024_secret_key')

# Store active WebSocket connections
active_connections = {}
active_sessions = {}

class NetCafeServer:
    def __init__(self):
        self.app = web.Application()
        self.setup_routes()
        self.setup_cors()
        self._rate_buckets = {}
        
        # Cleanup orphaned sessions on server startup
        self._cleanup_orphaned_sessions_on_startup()

    def _cleanup_orphaned_sessions_on_startup(self):
        """Clean up orphaned sessions when server starts"""
        try:
            # Get all active sessions from database
            db_sessions = db.get_active_sessions()
            cleaned_count = 0
            
            # All sessions are orphaned on startup since active_sessions is empty
            for session_id, username, computer_id, start_time, duration_minutes in db_sessions:
                # End orphaned session with 0 minutes used (full refund)
                if db.end_session(session_id, 0):
                    cleaned_count += 1
                    logger.info(f"Startup cleanup: Ended orphaned session {session_id} for user {username}")
            
            if cleaned_count > 0:
                logger.info(f"🧹 Startup cleanup completed: {cleaned_count} orphaned sessions cleaned")
            else:
                logger.info("🧹 Startup cleanup: No orphaned sessions found")
                
        except Exception as e:
            logger.error(f"Startup session cleanup error: {e}")

    def rate_limit(self, max_per_window: int, window_seconds: int):
        async def middleware(request, handler):
            try:
                key = f"{request.remote}:{request.path}"
                now = int(datetime.now().timestamp())
                window_start = now - window_seconds
                bucket = self._rate_buckets.get(key, [])
                bucket = [ts for ts in bucket if ts >= window_start]
                if len(bucket) >= max_per_window:
                    return web.json_response({
                        'success': False,
                        'message': 'Rate limit exceeded'
                    }, status=429)
                bucket.append(now)
                self._rate_buckets[key] = bucket
                return await handler(request)
            except Exception:
                return await handler(request)
        return middleware
        
    def setup_routes(self):
        """Setup all API routes"""
        # Public routes (no auth required)
        self.app.router.add_get('/api/status', self.handle_status)
        self.app.router.add_get('/api/health', self.handle_status)  # Health check endpoint
        self.app.router.add_post('/api/login', self.handle_login)
        self.app.router.add_post('/api/web/auth', self.handle_web_auth)
        self.app.router.add_post('/api/logout', self.handle_logout)
        self.app.router.add_get('/api/leaderboard', self.handle_public_leaderboard)
        self.app.router.add_get('/api/recent_activity', self.handle_recent_activity)
        self.app.router.add_get('/ws', self.handle_websocket)
        
        # User routes (require authentication)
        self.app.router.add_get('/api/user/progress', self.handle_get_user_progress)
        self.app.router.add_get('/api/user/{user_id}/minutes', self.handle_get_user_minutes)
        
        # Admin routes  
        self.app.router.add_post('/api/admin/create_user', self.handle_create_user)
        self.app.router.add_put('/api/admin/update_user', self.handle_update_user)
        self.app.router.add_delete('/api/admin/delete_user', self.handle_delete_user)
        self.app.router.add_post('/api/admin/add_time', self.handle_add_time)
        self.app.router.add_get('/api/admin/users', self.handle_get_users)
        self.app.router.add_get('/api/admin/computers', self.handle_get_computers)
        self.app.router.add_delete('/api/admin/delete_computer', self.handle_delete_computer)
        self.app.router.add_get('/api/admin/sessions', self.handle_get_sessions)
        self.app.router.add_get('/api/admin/stats', self.handle_get_stats)
        self.app.router.add_post('/api/admin/end_session', self.handle_admin_end_session)
        self.app.router.add_post('/api/admin/cleanup_sessions', self.handle_cleanup_sessions)
        self.app.router.add_get('/api/admin/leaderboard', self.handle_get_leaderboard)
        
        # Posts management routes
        self.app.router.add_get('/api/posts', self.handle_get_posts)
        self.app.router.add_post('/api/admin/posts', self.handle_create_post)
        self.app.router.add_put('/api/admin/posts/{post_id}', self.handle_update_post)
        self.app.router.add_delete('/api/admin/posts/{post_id}', self.handle_delete_post)
        
        # Token management routes
        self.app.router.add_get('/api/user/tokens', self.handle_get_user_tokens)
        self.app.router.add_post('/api/admin/tokens/add', self.handle_add_tokens)
        
        # Shop management routes
        self.app.router.add_get('/api/shop/items', self.handle_get_shop_items)
        self.app.router.add_post('/api/shop/purchase', self.handle_purchase_item)
        self.app.router.add_post('/api/admin/shop/items', self.handle_create_shop_item)
        self.app.router.add_put('/api/admin/shop/items/{item_id}', self.handle_update_shop_item)
        self.app.router.add_delete('/api/admin/shop/items/{item_id}', self.handle_delete_shop_item)
        self.app.router.add_get('/api/user/purchases', self.handle_get_user_purchases)
        
        # Simulator reservation routes (SAFE BILLING)
        self.app.router.add_post('/api/simulator/reserve', self.handle_reserve_simulator)
        self.app.router.add_post('/api/simulator/start', self.handle_start_simulator)
        self.app.router.add_post('/api/simulator/cancel', self.handle_cancel_reservation)
        
    def setup_cors(self):
        """Setup CORS properly"""
        try:
            # Setup CORS with aiohttp-cors
            allowed_origins = os.environ.get('ALLOWED_ORIGINS', '')
            default_origin = '*'
            cors_defaults = {}
            if allowed_origins:
                for origin in [o.strip() for o in allowed_origins.split(',') if o.strip()]:
                    cors_defaults[origin] = ResourceOptions(
                        allow_credentials=True,
                        expose_headers='*',
                        allow_headers='*',
                        allow_methods='*'
                    )
            else:
                # Dev fallback
                cors_defaults[default_origin] = ResourceOptions(
                    allow_credentials=True,
                    expose_headers='*',
                    allow_headers='*',
                    allow_methods='*'
                )
            cors = cors_setup(self.app, defaults=cors_defaults)
            
            # Add CORS to all routes
            for route in list(self.app.router.routes()):
                cors.add(route)
                
            logger.info("CORS setup complete with aiohttp-cors")
                
        except ImportError:
            # Fallback: Add CORS headers manually to responses
            logger.warning("aiohttp-cors not available, using manual CORS headers")
            
            @web.middleware
            async def cors_middleware(request, handler):
                try:
                    if request.method == 'OPTIONS':
                        # Handle preflight
                        response = web.Response()
                    else:
                        response = await handler(request)
                    
                    # Ensure response is a Response object
                    if not isinstance(response, web.Response):
                        response = web.Response(text=str(response))
                    
                    response.headers['Access-Control-Allow-Origin'] = '*'
                    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
                    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
                    response.headers['Access-Control-Allow-Credentials'] = 'true'
                    return response
                except Exception as e:
                    logger.error(f"CORS middleware error: {e}")
                    return web.Response(status=500, text='Internal server error')
            
            self.app.middlewares.append(cors_middleware)
        except Exception as e:
            logger.error(f"CORS setup error: {e}")
            # Continue without CORS as fallback
            logger.warning("Continuing without CORS support")
    
    def create_jwt_token(self, user_data):
        """Create JWT token for user"""
        payload = {
            'user_id': user_data['id'],
            'username': user_data['username'],
            'is_admin': user_data['is_admin'],
            'exp': datetime.now().timestamp() + 86400  # 24 hours
        }
        return jwt.encode(payload, JWT_SECRET, algorithm='HS256')
    
    def verify_jwt_token(self, token):
        """Verify JWT token"""
        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    async def handle_status(self, request):
        """Handle status check"""
        return web.json_response({
            'success': True,
            'status': 'running',
            'timestamp': datetime.now().isoformat(),
            'active_connections': len(active_connections),
            'active_sessions': len(active_sessions),
            'version': '2.0'
        })
    
    async def handle_login(self, request):
        """Handle user login"""
        try:
            data = await request.json()
            username = data.get('username')
            password = data.get('password')
            computer_id = data.get('computer_id')
            
            logger.info(f"Login attempt: {username} on {computer_id}")
            
            if not all([username, password, computer_id]):
                return web.json_response({
                    'success': False,
                    'message': 'Missing required fields'
                }, status=400)
            
            # Authenticate user
            user = db.authenticate_user(username, password)
            if not user:
                logger.warning(f"Authentication failed for {username}")
                return web.json_response({
                    'success': False,
                    'message': 'Invalid username or password'
                }, status=401)
            
            # Check if user has minutes (skip for admin users)
            if not user['is_admin'] and user['minutes'] <= 0:
                return web.json_response({
                    'success': False,
                    'message': 'No time available. Please contact administrator.'
                }, status=403)
            
            # Get simulator type for this computer
            simulator_type_info = db.get_simulator_type_by_computer(computer_id)
            simulator_type_name = simulator_type_info['name'] if simulator_type_info else 'normal'
            
            # Check if user has minutes for this specific simulator type (skip for admin users)
            if not user['is_admin'] and not db.check_user_has_minutes_for_simulator(user['id'], simulator_type_name, 1):
                # Get user's minute breakdown for better error message
                minutes_data = db.get_user_minutes_by_type(user['id'])
                if minutes_data:
                    type_display_names = {
                        'basic_minutes': 'Basic',
                        'standard_minutes': 'Standard', 
                        'premium_minutes': 'Premium'
                    }
                    
                    # Find which simulator type this computer is
                    simulator_display_name = 'Basic'
                    if simulator_type_name in ['medium', 'standard']:
                        simulator_display_name = 'Standard'
                    elif simulator_type_name == 'premium':
                        simulator_display_name = 'Premium'
                    
                    # Build message showing available minutes
                    available_types = []
                    if minutes_data['basic_minutes'] > 0:
                        available_types.append(f"Basic: {minutes_data['basic_minutes']} min")
                    if minutes_data['standard_minutes'] > 0:
                        available_types.append(f"Standard: {minutes_data['standard_minutes']} min")
                    if minutes_data['premium_minutes'] > 0:
                        available_types.append(f"Premium: {minutes_data['premium_minutes']} min")
                    
                    available_text = ", ".join(available_types) if available_types else "No minutes"
                    
                    return web.json_response({
                        'success': False,
                        'message': f'No {simulator_display_name} simulator minutes available. This computer requires {simulator_display_name} minutes. You have: {available_text}'
                    }, status=403)
                else:
                    return web.json_response({
                        'success': False,
                        'message': 'No time available for this simulator type. Please contact administrator.'
                    }, status=403)
            
            # Register computer
            db.register_computer(computer_id, ip_address=request.remote)
            
            # Get user's minute breakdown to determine how many minutes to use for this session
            if user['is_admin']:
                # Admin gets unlimited time (999999 minutes for client shutdown)
                available_minutes_for_type = 999999
            else:
                minutes_data = db.get_user_minutes_by_type(user['id'])
                
                # Map simulator types to minute types
                type_mapping = {
                    'normal': 'basic_minutes',
                    'basic': 'basic_minutes',
                    'medium': 'standard_minutes', 
                    'standard': 'standard_minutes',
                    'premium': 'premium_minutes'
                }
                
                minute_type = type_mapping.get(simulator_type_name, 'basic_minutes')
                available_minutes_for_type = minutes_data.get(minute_type, 0)
            
            # Create session with the available minutes for this simulator type
            session_id = db.create_session(user['id'], computer_id, available_minutes_for_type)
            if not session_id:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to create session. Please contact administrator.'
                }, status=500)
            
            # Store active session
            active_sessions[session_id] = {
                'user_id': user['id'],
                'username': username,
                'computer_id': computer_id,
                'start_time': datetime.now(),
                'initial_minutes': available_minutes_for_type,  # Track initial minutes for proper refund calculation
                'minutes': available_minutes_for_type,  # Use minutes for this specific simulator type
                'remaining_time': available_minutes_for_type * 60,  # Track remaining time in seconds
                'simulator_type': simulator_type_name  # Track simulator type for this session
            }
            
            # Create JWT token
            token = self.create_jwt_token(user)
            
            # Broadcast session start
            await self.broadcast_update('session_started', {
                'session_id': session_id,
                'username': username,
                'computer_id': computer_id,
                'minutes': available_minutes_for_type,
                'simulator_type': simulator_type_name
            })
            
            logger.info(f"Login successful: {username}, session: {session_id}")
            
            return web.json_response({
                'success': True,
                'token': token,
                'session_id': session_id,
                'minutes': available_minutes_for_type,
                'simulator_type': simulator_type_name,
                'user': {
                    'id': user['id'],
                    'username': user['username'],
                    'is_admin': user['is_admin']
                }
            })
            
        except Exception as e:
            logger.error(f"Login error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_web_auth(self, request):
        """Handle web authentication - ONLY authenticate, NO session creation"""
        try:
            data = await request.json()
            username = data.get('username')
            password = data.get('password')
            
            logger.info(f"Web auth attempt: {username}")
            
            if not all([username, password]):
                return web.json_response({
                    'success': False,
                    'message': 'Missing username or password'
                }, status=400)
            
            # Authenticate user (same as login)
            user = db.authenticate_user(username, password)
            if not user:
                logger.warning(f"Web authentication failed for {username}")
                return web.json_response({
                    'success': False,
                    'message': 'Invalid username or password'
                }, status=401)
            
            # Create JWT token (but NO session creation!)
            token = self.create_jwt_token(user)
            
            logger.info(f"Web auth successful: {username} (NO SESSION CREATED)")
            
            # Return user data WITHOUT creating NetCafe session
            return web.json_response({
                'success': True,
                'token': token,
                'user': {
                    'id': user['id'],
                    'username': user['username'],
                    'is_admin': user['is_admin']
                },
                'minutes': user['minutes'],  # Show available minutes for info only
                'message': 'Authentication successful - no session created'
            })
            
        except Exception as e:
            logger.error(f"Web auth error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)

    async def handle_get_user_progress(self, request):
        """Get user progress data from database"""
        try:
            # Get token from Authorization header
            auth_header = request.headers.get('Authorization', '')
            if not auth_header.startswith('Bearer '):
                return web.json_response({
                    'success': False,
                    'message': 'Missing or invalid authorization header'
                }, status=401)
            
            token = auth_header[7:]  # Remove 'Bearer ' prefix
            user_data = self.verify_jwt_token(token)
            
            if not user_data:
                return web.json_response({
                    'success': False,
                    'message': 'Invalid or expired token'
                }, status=401)
            
            user_id = user_data['user_id']
            progress = db.get_user_progress(user_id)
            
            if progress:
                logger.info(f"Progress data retrieved for user {user_id}: {progress['totalPlayedMinutes']} minutes played")
                return web.json_response(progress)
            else:
                # Return default progress if none found
                return web.json_response({
                    'username': user_data['username'],
                    'totalPlayedMinutes': 0,
                    'totalSessions': 0,
                    'totalSpent': 0.0,
                    'experience': 0,
                    'level': 'Новак',
                    'skillProgress': {
                        'braking': 0,
                        'cornering': 0,
                        'acceleration': 0,
                        'strategy': 0,
                        'consistency': 0,
                        'overtaking': 0
                    },
                    'hoursPlayed': 0.0,
                    'averageSessionLength': 0.0
                })
                
        except Exception as e:
            logger.error(f"Get user progress error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_logout(self, request):
        """Handle user logout"""
        try:
            data = await request.json()
            session_id = data.get('session_id')
            minutes_used = data.get('minutes_used', 0)
            
            logger.info(f"Logout request: {session_id}, used: {minutes_used}")
            
            if not session_id:
                return web.json_response({
                    'success': False,
                    'message': 'Missing session ID'
                }, status=400)
            
            # End session in database
            if db.end_session(session_id, minutes_used):
                # Remove from active sessions
                if session_id in active_sessions:
                    del active_sessions[session_id]
                
                # Broadcast session end
                await self.broadcast_update('session_ended', {
                    'session_id': session_id,
                    'minutes_used': minutes_used
                })
                
                logger.info(f"Logout successful: {session_id}")
                return web.json_response({'success': True})
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to end session'
                }, status=500)
                
        except Exception as e:
            logger.error(f"Logout error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_websocket(self, request):
        """Handle WebSocket connections"""
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        
        computer_id = request.query.get('computer_id')
        if not computer_id:
            await ws.close()
            return ws
        
        logger.info(f"WebSocket connected: {computer_id}")
        active_connections[computer_id] = ws
        
        try:
            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    try:
                        data = json.loads(msg.data)
                        await self.handle_ws_message(computer_id, data, ws)
                    except json.JSONDecodeError:
                        logger.error(f"Invalid JSON from {computer_id}")
                elif msg.type == WSMsgType.ERROR:
                    logger.error(f"WebSocket error: {ws.exception()}")
                    break
                    
        except Exception as e:
            logger.error(f"WebSocket handler error: {e}")
        finally:
            if computer_id in active_connections:
                del active_connections[computer_id]
            logger.info(f"WebSocket disconnected: {computer_id}")
            
        return ws
    
    async def handle_ws_message(self, computer_id, data, ws):
        """Handle WebSocket messages from clients"""
        msg_type = data.get('type')
        
        if msg_type == 'heartbeat':
            await ws.send_str(json.dumps({
                'type': 'heartbeat_response',
                'timestamp': datetime.now().isoformat()
            }))
            
        elif msg_type == 'session_update':
            session_id = data.get('session_id')
            remaining_time = data.get('remaining_time', 0)
            
            if session_id in active_sessions:
                active_sessions[session_id]['remaining_time'] = remaining_time
                
        elif msg_type == 'request_time_update':
            # Send current time for active session on this computer
            for session_id, session in active_sessions.items():
                if session['computer_id'] == computer_id:
                    await ws.send_str(json.dumps({
                        'type': 'time_update',
                        'session_id': session_id,
                        'minutes': session.get('remaining_time', session['minutes'])
                    }))
                    break
    
    async def broadcast_update(self, update_type, data):
        """Broadcast updates to all connected clients"""
        message = {
            'type': update_type,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        disconnected = []
        for computer_id, ws in active_connections.items():
            try:
                await ws.send_str(json.dumps(message))
            except Exception as e:
                logger.error(f"Error broadcasting to {computer_id}: {e}")
                disconnected.append(computer_id)
        
        # Clean up disconnected clients
        for computer_id in disconnected:
            if computer_id in active_connections:
                del active_connections[computer_id]
    
    # Admin endpoints
    async def handle_create_user(self, request):
        """Create new user (admin only)"""
        try:
            data = await request.json()
            username = data.get('username')
            password = data.get('password')
            minutes = data.get('minutes', 0)
            is_admin = data.get('is_admin', False)
            
            if not all([username, password]):
                return web.json_response({
                    'success': False,
                    'message': 'Username and password required'
                }, status=400)
            
            user_id = db.create_user(username, password, is_admin, minutes)
            if user_id:
                logger.info(f"User created: {username}")
                return web.json_response({'success': True, 'user_id': user_id})
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to create user'
                }, status=500)
                
        except Exception as e:
            logger.error(f"Create user error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_update_user(self, request):
        """Update user information (admin only)"""
        try:
            data = await request.json()
            user_id = data.get('user_id')
            username = data.get('username')
            password = data.get('password')
            is_admin = data.get('is_admin')
            minutes = data.get('minutes')
            is_active = data.get('is_active')
            
            if not user_id:
                return web.json_response({
                    'success': False,
                    'message': 'User ID required'
                }, status=400)
            
            # Only include fields that are provided
            update_data = {}
            if username is not None:
                update_data['username'] = username
            if password is not None and password.strip():
                update_data['password'] = password
            if is_admin is not None:
                update_data['is_admin'] = is_admin
            if minutes is not None:
                update_data['minutes'] = minutes
            if is_active is not None:
                update_data['is_active'] = is_active
            
            if db.update_user(user_id, **update_data):
                logger.info(f"User updated: {user_id}")
                return web.json_response({'success': True})
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to update user'
                }, status=500)
                
        except Exception as e:
            logger.error(f"Update user error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_delete_user(self, request):
        """Delete user permanently (admin only)"""
        try:
            data = await request.json()
            user_id = data.get('user_id')
            username = data.get('username')  # For logging purposes
            
            if not user_id:
                return web.json_response({
                    'success': False,
                    'message': 'User ID required'
                }, status=400)
            
            # Check if user exists before deletion
            user = db.get_user_by_id(user_id)
            if not user:
                return web.json_response({
                    'success': False,
                    'message': 'User not found'
                }, status=404)
            
            # Delete user and all related data
            if db.delete_user(user_id):
                logger.info(f"User deleted permanently: {username} (ID: {user_id})")
                return web.json_response({
                    'success': True,
                    'message': f'User "{username}" deleted successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to delete user'
                }, status=500)
                
        except Exception as e:
            logger.error(f"Delete user error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_add_time(self, request):
        """Add time to user account (admin only) - supports different minute types"""
        try:
            data = await request.json()
            username = data.get('username')
            minutes = data.get('minutes')
            amount = data.get('amount', 0.0)
            minute_type = data.get('minute_type', 'basic')  # Default to basic
            
            if not all([username, minutes]):
                return web.json_response({
                    'success': False,
                    'message': 'Username and minutes required'
                }, status=400)
            
            # Validate minute type
            valid_types = ['basic', 'normal', 'standard', 'medium', 'premium']
            if minute_type not in valid_types:
                return web.json_response({
                    'success': False,
                    'message': f'Invalid minute type. Must be one of: {", ".join(valid_types)}'
                }, status=400)
            
            if db.add_minutes(username, minutes, amount, minute_type):
                logger.info(f"Added {minutes} {minute_type} minutes to {username}")
                return web.json_response({
                    'success': True,
                    'message': f'Added {minutes} {minute_type} minutes to {username}'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to add minutes'
                }, status=500)
                
        except Exception as e:
            logger.error(f"Add time error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)

    async def handle_get_user_minutes(self, request):
        """Get user minutes breakdown by type"""
        try:
            user_id = request.match_info['user_id']
            
            # Get token from Authorization header
            auth_header = request.headers.get('Authorization', '')
            if not auth_header.startswith('Bearer '):
                return web.json_response({
                    'success': False,
                    'message': 'Authentication required'
                }, status=401)
            
            token = auth_header[7:]
            user_data = self.verify_jwt_token(token)
            
            if not user_data:
                return web.json_response({
                    'success': False,
                    'message': 'Invalid or expired token'
                }, status=401)
            
            # Users can only see their own minutes, admins can see all
            if not user_data['is_admin'] and str(user_data['user_id']) != user_id:
                return web.json_response({
                    'success': False,
                    'message': 'Access denied'
                }, status=403)
            
            minutes_data = db.get_user_minutes_by_type(int(user_id))
            if not minutes_data:
                return web.json_response({
                    'success': False,
                    'message': 'User not found'
                }, status=404)
            
            return web.json_response({
                'success': True,
                'minutes': minutes_data
            })
            
        except Exception as e:
            logger.error(f"Get user minutes error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_get_users(self, request):
        """Get all users (admin only)"""
        try:
            users = db.get_all_users()
            return web.json_response({
                'success': True,
                'users': [
                    {
                        'id': user['id'],  # Include user ID for editing
                        'username': user['username'],
                        'minutes': user['minutes'],
                        'basic_minutes': user.get('basic_minutes', 0),
                        'standard_minutes': user.get('standard_minutes', 0),
                        'premium_minutes': user.get('premium_minutes', 0),
                        'is_admin': bool(user['is_admin']),
                        'is_active': bool(user['is_active']),
                        'last_login': str(user['last_login']) if user['last_login'] else None,
                        'total_spent': user['total_spent'],
                        'created_at': str(user['created_at']) if user['created_at'] else None
                    }
                    for user in users
                ]
            })
        except Exception as e:
            logger.error(f"Get users error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_get_computers(self, request):
        """Get all computers (admin only)"""
        try:
            computers = db.get_active_computers()
            return web.json_response({
                'success': True,
                'computers': [
                    {
                        'computer_id': computer_id,
                        'name': name,
                        'ip_address': ip_address,
                        'status': status,
                        'last_seen': str(last_seen),
                        'has_active_session': any(
                            session['computer_id'] == computer_id 
                            for session in active_sessions.values()
                        )
                    }
                    for computer_id, name, ip_address, status, last_seen in computers
                ]
            })
        except Exception as e:
            logger.error(f"Get computers error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_delete_computer(self, request):
        """Delete computer (admin only)"""
        try:
            data = await request.json()
            computer_id = data.get('computer_id')
            
            if not computer_id:
                return web.json_response({
                    'success': False,
                    'message': 'Computer ID is required'
                }, status=400)
            
            # Check if computer has active sessions
            for session in active_sessions.values():
                if session['computer_id'] == computer_id:
                    return web.json_response({
                        'success': False,
                        'message': 'Cannot delete computer with active sessions'
                    }, status=400)
            
            # Delete computer from database
            if db.delete_computer(computer_id):
                logger.info(f"Computer deleted: {computer_id}")
                
                # Broadcast update
                await self.broadcast_update('computer_deleted', {
                    'computer_id': computer_id
                })
                
                return web.json_response({
                    'success': True,
                    'message': 'Computer deleted successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to delete computer'
                }, status=500)
                
        except Exception as e:
            logger.error(f"Delete computer error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_get_sessions(self, request):
        """Get active sessions (admin only)"""
        try:
            sessions = db.get_active_sessions()
            return web.json_response({
                'success': True,
                'sessions': [
                    {
                        'session_id': session_id,
                        'username': username,
                        'computer_id': computer_id,
                        'start_time': str(start_time),
                        'duration_minutes': duration_minutes,
                        'remaining_time': active_sessions.get(session_id, {}).get('remaining_time', duration_minutes)
                    }
                    for session_id, username, computer_id, start_time, duration_minutes in sessions
                ]
            })
        except Exception as e:
            logger.error(f"Get sessions error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_get_stats(self, request):
        """Get server statistics (admin only)"""
        try:
            stats = db.get_revenue_stats()
            
            # Calculate computers online more intelligently
            # Count computers with active sessions OR recent WebSocket connections
            computers_with_sessions = set()
            for session in active_sessions.values():
                computers_with_sessions.add(session.get('computer_id'))
            
            computers_with_connections = set(active_connections.keys())
            online_computers = computers_with_sessions.union(computers_with_connections)
            
            # Add real-time stats
            stats.update({
                'active_connections': len(active_connections),
                'active_sessions': len(active_sessions),
                'computers_online': len(online_computers),
                'total_computers': len(db.get_active_computers())
            })
            
            return web.json_response({
                'success': True,
                'stats': stats
            })
        except Exception as e:
            logger.error(f"Get stats error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_admin_end_session(self, request):
        """Force end session (admin only)"""
        try:
            data = await request.json()
            session_id = data.get('session_id')
            
            if not session_id:
                return web.json_response({
                    'success': False,
                    'message': 'Session ID required'
                }, status=400)
            
            # Get session info
            if session_id not in active_sessions:
                return web.json_response({
                    'success': False,
                    'message': 'Session not found'
                }, status=404)
            
            session = active_sessions[session_id]
            computer_id = session['computer_id']
            
            # Calculate actual minutes used based on remaining time
            initial_minutes = session.get('initial_minutes', 0)
            remaining_seconds = session.get('remaining_time', 0)
            remaining_minutes = remaining_seconds // 60
            minutes_used = max(0, initial_minutes - remaining_minutes)
            
            logger.info(f"Admin ending session {session_id}: Initial={initial_minutes}, Remaining={remaining_minutes}, Used={minutes_used}")
            
            # End session in database with actual time used
            if db.end_session(session_id, minutes_used):
                # Remove from active sessions
                del active_sessions[session_id]
                
                # Send force logout to client
                if computer_id in active_connections:
                    await active_connections[computer_id].send_str(json.dumps({
                        'type': 'force_logout',
                        'session_id': session_id,
                        'message': 'Session ended by administrator'
                    }))
                
                # Broadcast update
                await self.broadcast_update('session_force_ended', {
                    'session_id': session_id,
                    'computer_id': computer_id,
                    'minutes_used': minutes_used,
                    'minutes_refunded': max(0, initial_minutes - minutes_used)
                })
                
                logger.info(f"Admin force ended session: {session_id}, used {minutes_used} minutes")
                return web.json_response({
                    'success': True, 
                    'minutes_used': minutes_used,
                    'minutes_refunded': max(0, initial_minutes - minutes_used)
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to end session'
                }, status=500)
                
        except Exception as e:
            logger.error(f"Admin end session error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_cleanup_sessions(self, request):
        """Clean up old/orphaned sessions (admin only)"""
        try:
            # Get all active sessions from database
            db_sessions = db.get_active_sessions()
            cleaned_count = 0
            
            # Check which sessions are truly orphaned (not in active_sessions memory)
            for session_id, username, computer_id, start_time, duration_minutes in db_sessions:
                if session_id not in active_sessions:
                    # This session is orphaned - mark it as ended
                    if db.end_session(session_id, 0):  # End with 0 minutes used (full refund)
                        cleaned_count += 1
                        logger.info(f"Cleaned orphaned session {session_id} for user {username}")
            
            logger.info(f"Session cleanup completed: {cleaned_count} sessions cleaned")
            return web.json_response({
                'success': True,
                'cleaned_sessions': cleaned_count,
                'message': f'Successfully cleaned {cleaned_count} orphaned sessions'
            })
            
        except Exception as e:
            logger.error(f"Session cleanup error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_get_leaderboard(self, request):
        """Get user leaderboard by total playtime (admin only)"""
        try:
            leaderboard = db.get_user_leaderboard()
            
            return web.json_response({
                'success': True,
                'leaderboard': [
                    {
                        'username': username,
                        'total_time_minutes': total_time_minutes,
                        'sessions_played': sessions_played,
                        'total_spent': total_spent
                    }
                    for username, total_time_minutes, sessions_played, total_spent in leaderboard
                ]
            })
        except Exception as e:
            logger.error(f"Get leaderboard error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)

    async def handle_public_leaderboard(self, request):
        """Get public leaderboard with XP/tokens system"""
        try:
            from leaderboard_api import get_leaderboard_data
            leaderboard = get_leaderboard_data()
            
            return web.json_response({
                'success': True,
                'leaderboard': leaderboard
            })
        except Exception as e:
            logger.error(f"Public leaderboard error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)

    async def handle_recent_activity(self, request):
        """Handle recent activity request"""
        try:
            # Get recent sessions from database
            recent_sessions = db.get_recent_activity(limit=10)
            
            return web.json_response({
                'success': True,
                'activities': recent_sessions
            })
        except Exception as e:
            logger.error(f"Error getting recent activity: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    # Posts management handlers
    async def handle_get_posts(self, request):
        """Get posts"""
        try:
            category = request.query.get('category')
            limit = request.query.get('limit')
            if limit:
                limit = int(limit)
            
            posts = db.get_posts(category=category, limit=limit)
            
            return web.json_response({
                'success': True,
                'posts': posts
            })
        except Exception as e:
            logger.error(f"Error getting posts: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_create_post(self, request):
        """Create a new post"""
        try:
            data = await request.json()
            title = data.get('title')
            content = data.get('content')
            category = data.get('category', 'general')
            featured = data.get('featured', False)
            
            # Get admin user ID (assuming admin is creating the post)
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload or not payload.get('is_admin'):
                return web.json_response({
                    'success': False,
                    'message': 'Admin access required'
                }, status=403)
            
            post_id = db.create_post(title, content, payload['user_id'], category, featured)
            
            if post_id:
                return web.json_response({
                    'success': True,
                    'post_id': post_id,
                    'message': 'Post created successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to create post'
                }, status=500)
        except Exception as e:
            logger.error(f"Error creating post: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_update_post(self, request):
        """Update a post"""
        try:
            post_id = int(request.match_info['post_id'])
            data = await request.json()
            
            # Check admin authorization
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload or not payload.get('is_admin'):
                return web.json_response({
                    'success': False,
                    'message': 'Admin access required'
                }, status=403)
            
            success = db.update_post(
                post_id,
                title=data.get('title'),
                content=data.get('content'),
                category=data.get('category'),
                featured=data.get('featured')
            )
            
            if success:
                return web.json_response({
                    'success': True,
                    'message': 'Post updated successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to update post'
                }, status=500)
        except Exception as e:
            logger.error(f"Error updating post: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_delete_post(self, request):
        """Delete a post"""
        try:
            post_id = int(request.match_info['post_id'])
            
            # Check admin authorization
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload or not payload.get('is_admin'):
                return web.json_response({
                    'success': False,
                    'message': 'Admin access required'
                }, status=403)
            
            success = db.delete_post(post_id)
            
            if success:
                return web.json_response({
                    'success': True,
                    'message': 'Post deleted successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to delete post'
                }, status=500)
        except Exception as e:
            logger.error(f"Error deleting post: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    # Token management handlers
    async def handle_get_user_tokens(self, request):
        """Get user token balance"""
        try:
            # Get user from token
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload:
                return web.json_response({
                    'success': False,
                    'message': 'Invalid token'
                }, status=401)
            
            tokens = db.get_user_tokens(payload['user_id'])
            
            return web.json_response({
                'success': True,
                'tokens': tokens
            })
        except Exception as e:
            logger.error(f"Error getting user tokens: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_add_tokens(self, request):
        """Add tokens to user account (admin only)"""
        try:
            data = await request.json()
            user_id = data.get('user_id')
            amount = data.get('amount')
            description = data.get('description', 'Admin added tokens')
            
            # Check admin authorization
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload or not payload.get('is_admin'):
                return web.json_response({
                    'success': False,
                    'message': 'Admin access required'
                }, status=403)
            
            success = db.add_tokens(user_id, amount, description)
            
            if success:
                return web.json_response({
                    'success': True,
                    'message': f'Added {amount} tokens successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to add tokens'
                }, status=500)
        except Exception as e:
            logger.error(f"Error adding tokens: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    # Shop management handlers
    async def handle_get_shop_items(self, request):
        """Get shop items"""
        try:
            category = request.query.get('category')
            items = db.get_shop_items(category=category)
            
            return web.json_response({
                'success': True,
                'items': items
            })
        except Exception as e:
            logger.error(f"Error getting shop items: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_purchase_item(self, request):
        """Purchase an item with tokens"""
        try:
            data = await request.json()
            item_id = data.get('item_id')
            
            # Get user from token
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload:
                return web.json_response({
                    'success': False,
                    'message': 'Invalid token'
                }, status=401)
            
            success, message = db.purchase_item(payload['user_id'], item_id)
            
            if success:
                return web.json_response({
                    'success': True,
                    'message': message
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': message
                }, status=400)
        except Exception as e:
            logger.error(f"Error purchasing item: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_create_shop_item(self, request):
        """Create a new shop item (admin only)"""
        try:
            data = await request.json()
            
            # Check admin authorization
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload or not payload.get('is_admin'):
                return web.json_response({
                    'success': False,
                    'message': 'Admin access required'
                }, status=403)
            
            item_id = db.create_shop_item(
                title=data.get('title'),
                description=data.get('description'),
                category=data.get('category'),
                price=data.get('price'),
                **{k: v for k, v in data.items() if k not in ['title', 'description', 'category', 'price']}
            )
            
            if item_id:
                return web.json_response({
                    'success': True,
                    'item_id': item_id,
                    'message': 'Shop item created successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to create shop item'
                }, status=500)
        except Exception as e:
            logger.error(f"Error creating shop item: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_update_shop_item(self, request):
        """Update a shop item (admin only)"""
        try:
            item_id = int(request.match_info['item_id'])
            data = await request.json()
            
            # Check admin authorization
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload or not payload.get('is_admin'):
                return web.json_response({
                    'success': False,
                    'message': 'Admin access required'
                }, status=403)
            
            success = db.update_shop_item(item_id, **data)
            
            if success:
                return web.json_response({
                    'success': True,
                    'message': 'Shop item updated successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to update shop item'
                }, status=500)
        except Exception as e:
            logger.error(f"Error updating shop item: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_delete_shop_item(self, request):
        """Delete a shop item (admin only)"""
        try:
            item_id = int(request.match_info['item_id'])
            
            # Check admin authorization
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return web.json_response({
                    'success': False,
                    'message': 'Authorization required'
                }, status=401)
            
            token = auth_header.replace('Bearer ', '')
            payload = self.verify_jwt_token(token)
            if not payload or not payload.get('is_admin'):
                return web.json_response({
                    'success': False,
                    'message': 'Admin access required'
                }, status=403)
            
            success = db.delete_shop_item(item_id)
            
            if success:
                return web.json_response({
                    'success': True,
                    'message': 'Shop item deleted successfully'
                })
            else:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to delete shop item'
                }, status=500)
        except Exception as e:
            logger.error(f"Error deleting shop item: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    async def handle_get_user_purchases(self, request):
        """Get user purchases"""
        try:
            # Get token from Authorization header
            auth_header = request.headers.get('Authorization', '')
            if not auth_header.startswith('Bearer '):
                return web.json_response({
                    'success': False,
                    'message': 'Missing or invalid authorization header'
                }, status=401)
            
            token = auth_header[7:]  # Remove 'Bearer ' prefix
            user_data = self.verify_jwt_token(token)
            
            if not user_data:
                return web.json_response({
                    'success': False,
                    'message': 'Invalid or expired token'
                }, status=401)
            
            user_id = user_data['user_id']
            purchases = db.get_user_purchases(user_id)
            
            return web.json_response({
                'success': True,
                'purchases': purchases
            })
            
        except Exception as e:
            logger.error(f"Get user purchases error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)

    # === SAFE BILLING - SIMULATOR RESERVATION SYSTEM ===
    async def handle_reserve_simulator(self, request):
        """Reserve simulator time - NO IMMEDIATE MINUTE DEDUCTION"""
        try:
            # Get token from Authorization header
            auth_header = request.headers.get('Authorization', '')
            if not auth_header.startswith('Bearer '):
                return web.json_response({
                    'success': False,
                    'message': 'Authentication required'
                }, status=401)
            
            token = auth_header[7:]
            user_data = self.verify_jwt_token(token)
            
            if not user_data:
                return web.json_response({
                    'success': False,
                    'message': 'Invalid or expired token'
                }, status=401)
            
            data = await request.json()
            simulator_id = data.get('simulator_id')
            minutes = data.get('minutes', 30)  # Default 30 minutes
            
            if not simulator_id:
                return web.json_response({
                    'success': False,
                    'message': 'Simulator ID required'
                }, status=400)
            
            user_id = user_data['user_id']
            
            # Create reservation WITHOUT deducting minutes
            reservation_id = db.create_simulator_reservation(user_id, simulator_id, minutes)
            
            if not reservation_id:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to create reservation - insufficient minutes or simulator unavailable'
                }, status=400)
            
            logger.info(f"🎯 SAFE RESERVATION: User {user_data['username']} reserved {minutes} minutes on {simulator_id} - NO DEDUCTION YET")
            
            return web.json_response({
                'success': True,
                'reservation_id': reservation_id,
                'message': f'Simulator reserved for {minutes} minutes - minutes will be deducted when you start playing',
                'simulator_id': simulator_id,
                'reserved_minutes': minutes
            })
            
        except Exception as e:
            logger.error(f"Reserve simulator error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)

    async def handle_start_simulator(self, request):
        """Start simulator session - DEDUCT RESERVED MINUTES NOW"""
        try:
            data = await request.json()
            reservation_id = data.get('reservation_id')
            
            if not reservation_id:
                return web.json_response({
                    'success': False,
                    'message': 'Reservation ID required'
                }, status=400)
            
            # Start the session and deduct minutes
            success = db.start_simulator_session(reservation_id)
            
            if not success:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to start simulator session - reservation may have expired'
                }, status=400)
            
            logger.info(f"💸 MINUTES DEDUCTED: Simulator session {reservation_id} started - user is now playing")
            
            return web.json_response({
                'success': True,
                'session_id': reservation_id,
                'message': 'Simulator session started - minutes deducted. Enjoy your race!'
            })
            
        except Exception as e:
            logger.error(f"Start simulator error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)

    async def handle_cancel_reservation(self, request):
        """Cancel reservation - NO MINUTES DEDUCTED"""
        try:
            data = await request.json()
            reservation_id = data.get('reservation_id')
            
            if not reservation_id:
                return web.json_response({
                    'success': False,
                    'message': 'Reservation ID required'
                }, status=400)
            
            # Cancel reservation without deducting minutes
            success = db.cancel_reservation(reservation_id)
            
            if not success:
                return web.json_response({
                    'success': False,
                    'message': 'Failed to cancel reservation'
                }, status=400)
            
            logger.info(f"❌ RESERVATION CANCELLED: {reservation_id} - NO MINUTES DEDUCTED")
            
            return web.json_response({
                'success': True,
                'message': 'Reservation cancelled successfully - no minutes were deducted'
            })
            
        except Exception as e:
            logger.error(f"Cancel reservation error: {e}")
            return web.json_response({
                'success': False,
                'message': 'Internal server error'
            }, status=500)
    
    def run(self, host='0.0.0.0', port=8080):
        """Run the server"""
        logger.info(f"Starting NetCafe Pro 2.0 Server on {host}:{port}")
        web.run_app(self.app, host=host, port=port)

def main():
    server = NetCafeServer()
    server.run()

if __name__ == '__main__':
    main() 