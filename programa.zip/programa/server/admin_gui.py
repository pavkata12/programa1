import sys
import asyncio
import json
import logging
from datetime import datetime
import aiohttp
import threading
import time
import os

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QTabWidget,
    QLineEdit, QSpinBox, QCheckBox, QMessageBox, QGroupBox,
    QGridLayout, QTextEdit, QComboBox, QProgressBar, QFrame,
    QScrollArea, QSplitter, QHeaderView, QDialog, QFormLayout, QMenu
)
from PySide6.QtCore import Qt, QTimer, Signal, QThread, QSize
from PySide6.QtGui import QFont, QPixmap, QPainter, QIcon, QAction, QTextCursor, QColor
import qasync

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StatsCard(QFrame):
    def __init__(self, title, value, subtitle="", color="#00A19C"):
        super().__init__()
        self.setFrameStyle(QFrame.Box)
        self.setMinimumSize(200, 120)
        self.setMaximumSize(300, 150)
        
        # Sim Racing Academy card styling
        self.setStyleSheet(f'''
            QFrame {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 rgba(0,0,0,0.95), stop:1 rgba(0,26,26,0.95));
                border: 2px solid rgba(0,161,156,0.3);
                border-radius: 12px;
                padding: 10px;
            }}
            QFrame:hover {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 rgba(0,0,0,0.98), stop:1 rgba(0,26,26,0.98));
                border: 2px solid {color};
            }}
        ''')
        
        layout = QVBoxLayout(self)
        
        # Title
        title_label = QLabel(title)
        title_label.setStyleSheet(f'''
            color: {color}; 
            font-size: 14px; 
            font-weight: bold;
            background: transparent;
            border: none;
            padding: 3px;
        ''')
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)
        
        # Value
        self.value_label = QLabel(str(value))
        self.value_label.setStyleSheet(f'''
            color: {color}; 
            font-size: 28px; 
            font-weight: bold;
            background: transparent;
            border: none;
            padding: 8px;
            min-height: 40px;
        ''')
        self.value_label.setAlignment(Qt.AlignCenter)
        self.value_label.setWordWrap(True)
        layout.addWidget(self.value_label)
        
        # Subtitle
        if subtitle:
            subtitle_label = QLabel(subtitle)
            subtitle_label.setStyleSheet('''
                color: #aaa; 
                font-size: 12px;
                background: transparent;
                border: none;
                padding: 2px;
            ''')
            subtitle_label.setAlignment(Qt.AlignCenter)
            layout.addWidget(subtitle_label)
    
    def update_value(self, value):
        """Update the value displayed on the card"""
        try:
            # Update the text
            self.value_label.setText(str(value))
            
            # Force immediate visual updates
            self.value_label.update()
            self.update()
            
            # Process events to ensure GUI updates
            QApplication.processEvents()
            
            logger.info(f"StatsCard updated with value: {value} - Label text: {self.value_label.text()}")
        except Exception as e:
            logger.error(f"Error updating StatsCard value: {e}")
            self.value_label.setText("ERROR")

class LeaderboardCard(QFrame):
    def __init__(self, title="🏆 Top Racers", color="#00C4B4"):
        super().__init__()
        self.setFrameStyle(QFrame.Box)
        self.setMinimumSize(600, 100)  # Wider and shorter
        self.setMaximumSize(800, 100)  # Allow it to expand width-wise
        
        # Sim Racing Academy card styling
        self.setStyleSheet(f'''
            QFrame {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 rgba(0,0,0,0.95), stop:1 rgba(0,26,26,0.95));
                border: 2px solid rgba(0,196,180,0.3);
                border-radius: 12px;
                padding: 10px;
            }}
            QFrame:hover {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 rgba(0,0,0,0.98), stop:1 rgba(0,26,26,0.98));
                border: 2px solid {color};
            }}
        ''')
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)  # Minimal margins
        
        # Skip title to eliminate empty bar
        # Only add title if it's not empty
        if title.strip():
            title_label = QLabel(title)
            title_label.setStyleSheet(f'color: {color}; font-size: 16px; font-weight: bold;')
            title_label.setAlignment(Qt.AlignCenter)
            layout.addWidget(title_label)
        
        # Leaderboard list
        self.leaderboard_list = QTextEdit()
        self.leaderboard_list.setReadOnly(True)
        self.leaderboard_list.setStyleSheet('''
            QTextEdit {
                background: transparent;
                border: none;
                color: white;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 13px;
                line-height: 1.2;
                padding: 3px;
            }
        ''')
        layout.addWidget(self.leaderboard_list)
    
    def update_leaderboard(self, leaderboard_data):
        """Update leaderboard with user playtime data"""
        if not leaderboard_data:
            self.leaderboard_list.setPlainText("No player data available")
            return
        
        leaderboard_text = ""
        # Limit to top 5 players to keep it compact
        for i, player in enumerate(leaderboard_data[:5], 1):
            username = player['username']
            total_time = player['total_time_minutes']
            
            # Convert minutes to hours and minutes
            hours = total_time // 60
            minutes = total_time % 60
            
            # Rank emoji
            if i == 1:
                rank_emoji = "🥇"
            elif i == 2:
                rank_emoji = "🥈"
            elif i == 3:
                rank_emoji = "🥉"
            else:
                rank_emoji = f"{i:2d}."
            
            # Format time display
            if hours > 0:
                time_str = f"{hours}h {minutes}m"
            else:
                time_str = f"{minutes}m"
            
            # Wider formatting to use the extra space
            leaderboard_text += f"{rank_emoji}  {username:<20}  {time_str:>8}\n"
        
        self.leaderboard_list.setPlainText(leaderboard_text)

class CreateUserDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('🆕 Create New User')
        self.setFixedSize(400, 300)
        
        # Modern dialog styling
        self.setStyleSheet('''
            QDialog {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #1a1a2e, stop:1 #16213e);
                color: white;
            }
            QLabel { color: white; font-size: 14px; }
            QLineEdit, QSpinBox {
                background: rgba(255,255,255,0.1);
                border: 2px solid rgba(0, 161, 156,0.3);
                border-radius: 8px;
                padding: 8px;
                color: white;
                font-size: 14px;
            }
            QLineEdit:focus, QSpinBox:focus {
                border: 2px solid #00A19C;
            }
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00A19C, stop:1 #008F8A);
                color: black;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #008F8A, stop:1 #00A19C);
            }
            QCheckBox {
                color: white;
                font-size: 14px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
            QCheckBox::indicator:unchecked {
                border: 2px solid #00A19C;
                background: transparent;
                border-radius: 3px;
            }
            QCheckBox::indicator:checked {
                border: 2px solid #00A19C;
                background: #00A19C;
                border-radius: 3px;
            }
        ''')
        
        layout = QFormLayout(self)
        
        # Form fields
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText('Enter username')
        layout.addRow('👤 Username:', self.username_input)
        
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Enter password')
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addRow('🔒 Password:', self.password_input)
        
        self.is_admin_checkbox = QCheckBox('Grant admin privileges')
        layout.addRow('🛡️ Admin:', self.is_admin_checkbox)
        
        # Buttons
        buttons_layout = QHBoxLayout()
        
        cancel_btn = QPushButton('❌ Cancel')
        cancel_btn.clicked.connect(self.reject)
        cancel_btn.setStyleSheet('''
            QPushButton {
                background: rgba(255,68,68,0.8);
                color: white;
            }
            QPushButton:hover {
                background: rgba(255,68,68,1.0);
            }
        ''')
        
        create_btn = QPushButton('🆕 Create User')
        create_btn.clicked.connect(self.accept)
        create_btn.setDefault(True)
        
        buttons_layout.addWidget(cancel_btn)
        buttons_layout.addWidget(create_btn)
        layout.addRow(buttons_layout)
    
    def get_user_data(self):
        return {
            'username': self.username_input.text().strip(),
            'password': self.password_input.text(),
            'is_admin': self.is_admin_checkbox.isChecked()
        }

class AddTimeDialog(QDialog):
    def __init__(self, users, parent=None):
        super().__init__(parent)
        self.setWindowTitle('💰 Add Time to User')
        self.setFixedSize(400, 250)
        
        # Modern dialog styling (same as CreateUserDialog)
        self.setStyleSheet('''
            QDialog {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #1a1a2e, stop:1 #16213e);
                color: white;
            }
            QLabel { color: white; font-size: 14px; }
            QComboBox, QSpinBox, QLineEdit {
                background: rgba(255,255,255,0.1);
                border: 2px solid rgba(0, 161, 156,0.3);
                border-radius: 8px;
                padding: 8px;
                color: white;
                font-size: 14px;
            }
            QComboBox:focus, QSpinBox:focus, QLineEdit:focus {
                border: 2px solid #00A19C;
            }
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00A19C, stop:1 #008F8A);
                color: black;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #008F8A, stop:1 #00A19C);
            }
        ''')
        
        layout = QFormLayout(self)
        
        # User selection
        self.user_combo = QComboBox()
        self.user_combo.addItems([user['username'] for user in users])
        layout.addRow('👤 Select User:', self.user_combo)
        
        # Minute type selection
        self.minute_type_combo = QComboBox()
        self.minute_type_combo.addItems(['Basic Simulator', 'Standard Simulator', 'Premium Simulator'])
        self.minute_type_combo.setCurrentIndex(0)  # Default to Basic
        layout.addRow('🎮 Simulator Type:', self.minute_type_combo)
        
        # Minutes
        self.minutes_input = QSpinBox()
        self.minutes_input.setRange(1, 9999)
        self.minutes_input.setValue(60)
        self.minutes_input.setSuffix(' minutes')
        layout.addRow('⏰ Minutes to Add:', self.minutes_input)
        
        # Amount paid
        self.amount_input = QLineEdit()
        self.amount_input.setPlaceholderText('0.00')
        layout.addRow('💰 Amount Paid (BGN):', self.amount_input)
        
        # Buttons
        buttons_layout = QHBoxLayout()
        
        cancel_btn = QPushButton('❌ Cancel')
        cancel_btn.clicked.connect(self.reject)
        cancel_btn.setStyleSheet('''
            QPushButton {
                background: rgba(255,68,68,0.8);
                color: white;
            }
            QPushButton:hover {
                background: rgba(255,68,68,1.0);
            }
        ''')
        
        add_btn = QPushButton('💰 Add Time')
        add_btn.clicked.connect(self.accept)
        add_btn.setDefault(True)
        
        buttons_layout.addWidget(cancel_btn)
        buttons_layout.addWidget(add_btn)
        layout.addRow(buttons_layout)
    
    def get_data(self):
        # Map display names to API values
        minute_type_mapping = {
            'Basic Simulator': 'basic',
            'Standard Simulator': 'standard', 
            'Premium Simulator': 'premium'
        }
        
        selected_type = self.minute_type_combo.currentText()
        minute_type = minute_type_mapping.get(selected_type, 'basic')
        
        return {
            'username': self.user_combo.currentText(),
            'minutes': self.minutes_input.value(),
            'amount': float(self.amount_input.text() or '0'),
            'minute_type': minute_type
        }

class EditUserDialog(QDialog):
    def __init__(self, user_data, parent=None):
        super().__init__(parent)
        self.user_data = user_data
        self.setWindowTitle(f'✏️ Edit User: {user_data["username"]}')
        self.setFixedSize(450, 350)
        
        # Modern dialog styling
        self.setStyleSheet('''
            QDialog {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #1a1a2e, stop:1 #16213e);
                color: white;
            }
            QLabel { color: white; font-size: 14px; }
            QLineEdit, QSpinBox {
                background: rgba(255,255,255,0.1);
                border: 2px solid rgba(0, 161, 156,0.3);
                border-radius: 8px;
                padding: 8px;
                color: white;
                font-size: 14px;
            }
            QLineEdit:focus, QSpinBox:focus {
                border: 2px solid #00A19C;
            }
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00A19C, stop:1 #008F8A);
                color: black;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #008F8A, stop:1 #00A19C);
            }
            QCheckBox {
                color: white;
                font-size: 14px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
            QCheckBox::indicator:unchecked {
                border: 2px solid #00A19C;
                background: transparent;
                border-radius: 3px;
            }
            QCheckBox::indicator:checked {
                border: 2px solid #00A19C;
                background: #00A19C;
                border-radius: 3px;
            }
        ''')
        
        layout = QFormLayout(self)
        
        # User info header
        user_info_label = QLabel(f'User ID: {user_data["id"]} | Created: {user_data.get("created_at", "N/A")[:10]}')
        user_info_label.setStyleSheet('color: #00A19C; font-size: 12px; font-weight: bold;')
        layout.addRow(user_info_label)
        
        # Form fields
        self.username_input = QLineEdit()
        self.username_input.setText(user_data['username'])
        self.username_input.setPlaceholderText('Enter username')
        layout.addRow('👤 Username:', self.username_input)
        
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Enter new password (leave empty to keep current)')
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addRow('🔒 New Password:', self.password_input)
        
        self.minutes_input = QSpinBox()
        self.minutes_input.setRange(0, 99999)
        self.minutes_input.setValue(user_data['minutes'])
        self.minutes_input.setSuffix(' minutes')
        layout.addRow('⏰ Available Time:', self.minutes_input)
        
        self.is_admin_checkbox = QCheckBox('Grant admin privileges')
        self.is_admin_checkbox.setChecked(user_data['is_admin'])
        layout.addRow('🛡️ Admin:', self.is_admin_checkbox)
        
        self.is_active_checkbox = QCheckBox('Account is active')
        self.is_active_checkbox.setChecked(user_data['is_active'])
        layout.addRow('✅ Active:', self.is_active_checkbox)
        
        # User stats (read-only)
        stats_label = QLabel(f'Total Spent: {user_data["total_spent"]:.2f} BGN | Last Login: {user_data.get("last_login", "Never")[:16] if user_data.get("last_login") else "Never"}')
        stats_label.setStyleSheet('color: #888; font-size: 11px;')
        layout.addRow('📊 Stats:', stats_label)
        
        # Buttons
        buttons_layout = QHBoxLayout()
        
        # Delete button (dangerous action)
        delete_btn = QPushButton('🗑️ Delete User')
        delete_btn.clicked.connect(self.delete_user)
        delete_btn.setStyleSheet('''
            QPushButton {
                background: rgba(220, 20, 60, 0.8);
                color: white;
                font-weight: bold;
            }
            QPushButton:hover {
                background: rgba(220, 20, 60, 1.0);
            }
        ''')
        
        cancel_btn = QPushButton('❌ Cancel')
        cancel_btn.clicked.connect(self.cancel_action)
        cancel_btn.setStyleSheet('''
            QPushButton {
                background: rgba(255,68,68,0.8);
                color: white;
            }
            QPushButton:hover {
                background: rgba(255,68,68,1.0);
            }
        ''')
        
        save_btn = QPushButton('💾 Save Changes')
        save_btn.clicked.connect(self.save_user)
        save_btn.setDefault(True)
        
        buttons_layout.addWidget(delete_btn)
        buttons_layout.addWidget(cancel_btn)
        buttons_layout.addWidget(save_btn)
        layout.addRow(buttons_layout)
        
        # Store action type
        self.action_type = 'save'  # 'save', 'delete', or 'cancel'
    
    def get_user_data(self):
        return {
            'user_id': self.user_data['id'],
            'username': self.username_input.text().strip(),
            'password': self.password_input.text() if self.password_input.text().strip() else None,
            'minutes': self.minutes_input.value(),
            'is_admin': self.is_admin_checkbox.isChecked(),
            'is_active': self.is_active_checkbox.isChecked()
        }
    
    def delete_user(self):
        """Handle user deletion with confirmation"""
        username = self.user_data['username']
        reply = QMessageBox.question(
            self,
            '🗑️ Delete User',
            f'Are you sure you want to permanently delete user "{username}"?\n\n'
            f'This action cannot be undone and will remove:\n'
            f'• All user data and sessions\n'
            f'• Transaction history\n'
            f'• Account settings\n\n'
            f'Type the username "{username}" below to confirm:',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            # Ask for username confirmation
            from PySide6.QtWidgets import QInputDialog
            confirmation, ok = QInputDialog.getText(
                self, 
                'Confirm Deletion', 
                f'Type "{username}" to confirm deletion:',
                echo=QLineEdit.Normal
            )
            
            if ok and confirmation.strip() == username:
                self.action_type = 'delete'
                self.accept()  # Close dialog with accepted status
            elif ok:
                QMessageBox.warning(self, 'Invalid Confirmation', 'Username did not match. Deletion cancelled.')
            # else: user cancelled the input dialog
    
    def save_user(self):
        """Handle save user action"""
        self.action_type = 'save'
        self.accept()
    
    def cancel_action(self):
        """Handle cancel action"""
        self.action_type = 'cancel'
        self.reject()
    
    def get_action_type(self):
        """Get the action type (save or delete)"""
        return self.action_type

class SimRacingAcademyAdminGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.server_url = 'http://localhost:8080'
        self.session = None
        
        self.setWindowTitle('🏎️ Sim Racing Academy - Administration Panel')
        self.setMinimumSize(1200, 800)
        
        # Modern dark theme
        self.setStyleSheet('''
            QMainWindow {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #0f0f23, stop:1 #1a1a2e);
                color: white;
            }
            QTabWidget::pane {
                border: 2px solid rgba(0, 161, 156,0.3);
                border-radius: 8px;
                background: rgba(255,255,255,0.05);
            }
            QTabBar::tab {
                background: rgba(255,255,255,0.1);
                color: white;
                padding: 12px 20px;
                margin-right: 2px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                font-size: 14px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background: #00A19C;
                color: black;
            }
            QTabBar::tab:hover {
                background: rgba(0, 161, 156,0.3);
            }
            QTableWidget {
                background: rgba(255,255,255,0.05);
                border: 1px solid rgba(255,255,255,0.2);
                border-radius: 8px;
                gridline-color: rgba(255,255,255,0.1);
                color: white;
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
            }
            QTableWidget::item:selected {
                background: rgba(0, 161, 156,0.3);
            }
            QHeaderView::section {
                background: rgba(0, 161, 156,0.2);
                color: white;
                padding: 8px;
                border: none;
                font-weight: bold;
            }
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00A19C, stop:1 #008F8A);
                color: black;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
                font-size: 14px;
                font-weight: bold;
                min-width: 120px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #008F8A, stop:1 #00A19C);
                transform: translateY(-2px);
            }
            QPushButton:pressed {
                background: #007D78;
            }
            QLineEdit {
                background: rgba(255,255,255,0.1);
                border: 2px solid rgba(0, 161, 156,0.3);
                border-radius: 8px;
                padding: 8px;
                color: white;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 2px solid #00A19C;
            }
            QTextEdit {
                background: rgba(255,255,255,0.05);
                border: 1px solid rgba(255,255,255,0.2);
                border-radius: 8px;
                color: white;
                font-family: 'Consolas', monospace;
            }
            QLabel {
                color: white;
                font-size: 14px;
            }
            QGroupBox {
                color: white;
                font-size: 16px;
                font-weight: bold;
                border: 2px solid rgba(0, 161, 156,0.3);
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 10px 0 10px;
                background: rgba(0, 161, 156,0.2);
                border-radius: 4px;
            }
        ''')
        
        # Add async lock to prevent concurrent operations
        self._async_lock = asyncio.Lock()
        
        self.init_ui()
        self.init_timers()
        
        # Bridge process reference
        self.bridge_process = None
        
        # Pagination state for users
        self.users_current_page = 1
        self.users_per_page = 10
        self.users_search_query = ""
        self.all_users_data = []  # Store all users data
        
        # Async updates will be started after event loop is established
    
    def init_ui(self):
        """Initialize the user interface"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout(central_widget)
        
        # Header
        header = self.create_header()
        layout.addWidget(header)
        
        # Main tabs
        self.tabs = QTabWidget()
        
        # Dashboard tab
        self.tabs.addTab(self.create_dashboard_tab(), '📊 Dashboard')
        
        # Users tab
        self.tabs.addTab(self.create_users_tab(), '👥 Users')
        
        # Computers tab
        self.tabs.addTab(self.create_computers_tab(), '💻 Computers')
        
        # Simulators tab
        self.tabs.addTab(self.create_simulators_tab(), '🏎️ Simulators')
        
        # Sessions tab
        self.tabs.addTab(self.create_sessions_tab(), '⏰ Active Sessions')
        
        # Logs tab
        self.tabs.addTab(self.create_logs_tab(), '📝 System Logs')
        
        # Production Bridge tab
        self.tabs.addTab(self.create_production_bridge_tab(), '🌐 Production Bridge')
        
        layout.addWidget(self.tabs)
        
        # Status bar
        self.create_status_bar()
    
    def create_header(self):
        """Create header with logo and controls"""
        header = QFrame()
        header.setFixedHeight(80)
        header.setStyleSheet('''
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 rgba(0, 161, 156,0.2), stop:1 rgba(0, 143, 138,0.2));
                border-radius: 12px;
                margin-bottom: 10px;
            }
        ''')
        
        layout = QHBoxLayout(header)
        
        # Logo and title
        logo_label = QLabel('🏎️ Sim Racing Academy')
        logo_label.setStyleSheet('font-size: 28px; font-weight: bold; color: #00A19C;')
        layout.addWidget(logo_label)
        
        layout.addStretch()
        
        # Server status
        self.server_status_label = QLabel('🔴 Disconnected')
        self.server_status_label.setStyleSheet('font-size: 16px; color: #FF4444;')
        layout.addWidget(self.server_status_label)
        
        # Refresh button
        refresh_btn = QPushButton('🔄 Refresh')
        refresh_btn.clicked.connect(self.refresh_all_data)
        layout.addWidget(refresh_btn)
        
        return header
    
    def create_dashboard_tab(self):
        """Create dashboard with statistics"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Stats cards
        stats_layout = QHBoxLayout()
        
        self.revenue_today_card = StatsCard('💰 Today\'s Revenue', '0.00 BGN', 'Real-time earnings')
        self.active_users_card = StatsCard('👥 Active Users', '0', 'Currently online')
        self.online_computers_card = StatsCard('💻 Online PCs', '0', 'Connected computers')
        self.monthly_revenue_card = StatsCard('📈 Monthly Revenue', '0.00 BGN', 'This month\'s total')
        
        logger.info(f"Stats cards created: Revenue={self.revenue_today_card}, Active={self.active_users_card}, Online={self.online_computers_card}, Monthly={self.monthly_revenue_card}")
        
        stats_layout.addWidget(self.revenue_today_card)
        stats_layout.addWidget(self.active_users_card)
        stats_layout.addWidget(self.online_computers_card)
        stats_layout.addWidget(self.monthly_revenue_card)
        
        layout.addLayout(stats_layout)
        
        # Leaderboard section - give it more space
        leaderboard_layout = QVBoxLayout()
        
        # Leaderboard header with refresh button
        leaderboard_header = QHBoxLayout()
        leaderboard_title = QLabel('🏆 Top Players by Playtime')
        leaderboard_title.setStyleSheet('color: #FFD700; font-size: 16px; font-weight: bold; margin: 5px 0;')
        
        refresh_leaderboard_btn = QPushButton('🔄')
        refresh_leaderboard_btn.setFixedSize(30, 30)
        refresh_leaderboard_btn.setStyleSheet('''
            QPushButton {
                background: #FFD700;
                color: black;
                border: none;
                border-radius: 15px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background: #FFC700;
            }
        ''')
        refresh_leaderboard_btn.setToolTip('Refresh leaderboard immediately')
        refresh_leaderboard_btn.clicked.connect(self.manual_refresh_leaderboard)
        
        leaderboard_header.addWidget(leaderboard_title)
        leaderboard_header.addStretch()
        leaderboard_header.addWidget(refresh_leaderboard_btn)
        
        self.leaderboard_card = LeaderboardCard('', '#FFD700')  # Empty title since we have header
        
        leaderboard_layout.addLayout(leaderboard_header)
        leaderboard_layout.addWidget(self.leaderboard_card)
        
        layout.addLayout(leaderboard_layout)
        
        # Add some spacing between sections
        layout.addSpacing(10)
        
        # Quick actions
        actions_group = QGroupBox('🚀 Quick Actions')
        actions_layout = QHBoxLayout(actions_group)
        
        create_user_btn = QPushButton('🆕 Create User')
        create_user_btn.clicked.connect(self.show_create_user_dialog)
        
        add_time_btn = QPushButton('💰 Add Time')
        add_time_btn.clicked.connect(self.show_add_time_dialog)
        
        refresh_btn = QPushButton('🔄 Refresh Data')
        refresh_btn.clicked.connect(self.refresh_all_data)
        
        actions_layout.addWidget(create_user_btn)
        actions_layout.addWidget(add_time_btn)
        actions_layout.addWidget(refresh_btn)
        actions_layout.addStretch()
        
        layout.addWidget(actions_group)
        
        # Add some spacing between sections
        layout.addSpacing(10)
        
        # Recent activity
        activity_group = QGroupBox('📋 Recent Activity')
        activity_layout = QVBoxLayout(activity_group)
        
        self.activity_text = QTextEdit()
        self.activity_text.setMaximumHeight(200)
        self.activity_text.setReadOnly(True)
        activity_layout.addWidget(self.activity_text)
        
        layout.addWidget(activity_group)
        
        layout.addStretch()
        return widget
    
    def create_users_tab(self):
        """Create users management tab with pagination and search"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Search bar
        search_layout = QHBoxLayout()
        
        search_label = QLabel('🔍 Search:')
        self.users_search_input = QLineEdit()
        self.users_search_input.setPlaceholderText('Search by username...')
        self.users_search_input.textChanged.connect(self.on_users_search_changed)
        
        clear_search_btn = QPushButton('❌ Clear')
        clear_search_btn.clicked.connect(self.clear_users_search)
        clear_search_btn.setMaximumWidth(80)
        
        search_layout.addWidget(search_label)
        search_layout.addWidget(self.users_search_input)
        search_layout.addWidget(clear_search_btn)
        search_layout.addStretch()
        
        layout.addLayout(search_layout)
        
        # Controls
        controls_layout = QHBoxLayout()
        
        create_btn = QPushButton('🆕 Create User')
        create_btn.clicked.connect(self.show_create_user_dialog)
        
        edit_btn = QPushButton('✏️ Edit User')
        edit_btn.clicked.connect(self.show_edit_user_dialog)
        
        add_time_btn = QPushButton('💰 Add Time')
        add_time_btn.clicked.connect(self.show_add_time_dialog)
        
        refresh_btn = QPushButton('🔄 Refresh')
        refresh_btn.clicked.connect(lambda: asyncio.create_task(self.load_users()))
        
        controls_layout.addWidget(create_btn)
        controls_layout.addWidget(edit_btn)
        controls_layout.addWidget(add_time_btn)
        controls_layout.addWidget(refresh_btn)
        controls_layout.addStretch()
        
        layout.addLayout(controls_layout)
        
        # Users table
        self.users_table = QTableWidget()
        self.users_table.setColumnCount(9)
        self.users_table.setHorizontalHeaderLabels([
            'Username', 'Basic Min', 'Standard Min', 'Premium Min', 'Admin', 'Active', 'Last Login', 'Total Spent', 'Created'
        ])
        
        # Auto-resize columns
        header = self.users_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        
        # Enable row selection
        self.users_table.setSelectionBehavior(QTableWidget.SelectRows)
        
        # Add context menu
        self.users_table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.users_table.customContextMenuRequested.connect(self.show_user_context_menu)
        
        layout.addWidget(self.users_table)
        
        # Pagination controls
        pagination_layout = QHBoxLayout()
        
        # Items per page selector
        items_per_page_label = QLabel('Items per page:')
        self.users_per_page_combo = QComboBox()
        self.users_per_page_combo.addItems(['5', '10', '20', '50', '100'])
        self.users_per_page_combo.setCurrentText('10')
        self.users_per_page_combo.currentTextChanged.connect(self.on_users_per_page_changed)
        
        pagination_layout.addWidget(items_per_page_label)
        pagination_layout.addWidget(self.users_per_page_combo)
        pagination_layout.addStretch()
        
        # Page navigation
        self.users_prev_btn = QPushButton('⬅️ Previous')
        self.users_prev_btn.clicked.connect(self.users_previous_page)
        self.users_prev_btn.setEnabled(False)
        
        self.users_page_label = QLabel('Page 1 of 1')
        self.users_page_label.setStyleSheet('color: #00A19C; font-weight: bold; margin: 0 10px;')
        
        self.users_next_btn = QPushButton('Next ➡️')
        self.users_next_btn.clicked.connect(self.users_next_page)
        self.users_next_btn.setEnabled(False)
        
        # Quick page navigation
        self.users_goto_page_input = QLineEdit()
        self.users_goto_page_input.setPlaceholderText('Page #')
        self.users_goto_page_input.setMaximumWidth(70)
        self.users_goto_page_input.returnPressed.connect(self.users_goto_page)
        
        goto_btn = QPushButton('Go')
        goto_btn.clicked.connect(self.users_goto_page)
        goto_btn.setMaximumWidth(50)
        
        pagination_layout.addWidget(self.users_prev_btn)
        pagination_layout.addWidget(self.users_page_label)
        pagination_layout.addWidget(self.users_next_btn)
        pagination_layout.addWidget(QLabel('| Go to:'))
        pagination_layout.addWidget(self.users_goto_page_input)
        pagination_layout.addWidget(goto_btn)
        
        # Results info
        self.users_results_label = QLabel('Showing 0 users')
        self.users_results_label.setStyleSheet('color: #AAA; font-size: 12px;')
        pagination_layout.addStretch()
        pagination_layout.addWidget(self.users_results_label)
        
        layout.addLayout(pagination_layout)
        
        return widget
    
    def create_computers_tab(self):
        """Create computers management tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Controls
        controls_layout = QHBoxLayout()
        
        refresh_btn = QPushButton('🔄 Refresh')
        refresh_btn.clicked.connect(self.load_computers)
        
        controls_layout.addWidget(refresh_btn)
        controls_layout.addStretch()
        
        layout.addLayout(controls_layout)
        
        # Computers table
        self.computers_table = QTableWidget()
        self.computers_table.setColumnCount(5)
        self.computers_table.setHorizontalHeaderLabels([
            'Computer ID', 'Name', 'IP Address', 'Status', 'Last Seen'
        ])
        
        header = self.computers_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        
        # Enable row selection
        self.computers_table.setSelectionBehavior(QTableWidget.SelectRows)
        
        # Add context menu
        self.computers_table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.computers_table.customContextMenuRequested.connect(self.show_computer_context_menu)
        
        layout.addWidget(self.computers_table)
        
        return widget
    
    def create_sessions_tab(self):
        """Create active sessions tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Controls
        controls_layout = QHBoxLayout()
        
        refresh_btn = QPushButton('🔄 Refresh')
        refresh_btn.clicked.connect(self.load_sessions)
        
        end_session_btn = QPushButton('🛑 End Selected Session')
        end_session_btn.clicked.connect(self.end_selected_session)
        end_session_btn.setStyleSheet('''
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #FF4444, stop:1 #CC3333);
                color: white;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #FF6666, stop:1 #FF4444);
            }
        ''')
        
        cleanup_sessions_btn = QPushButton('🧹 Clean Old Sessions')
        cleanup_sessions_btn.clicked.connect(self.cleanup_old_sessions)
        cleanup_sessions_btn.setStyleSheet('''
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #FFA502, stop:1 #FF9100);
                color: white;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #FFB732, stop:1 #FFA502);
            }
        ''')
        
        controls_layout.addWidget(refresh_btn)
        controls_layout.addWidget(end_session_btn)
        controls_layout.addWidget(cleanup_sessions_btn)
        controls_layout.addStretch()
        
        layout.addLayout(controls_layout)
        
        # Sessions table
        self.sessions_table = QTableWidget()
        self.sessions_table.setColumnCount(5)
        self.sessions_table.setHorizontalHeaderLabels([
            'Session ID', 'Username', 'Computer', 'Start Time', 'Remaining Time'
        ])
        
        header = self.sessions_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        
        layout.addWidget(self.sessions_table)
        
        return widget
    
    def create_logs_tab(self):
        """Create logs viewing tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Controls
        controls_layout = QHBoxLayout()
        
        refresh_btn = QPushButton('🔄 Refresh Logs')
        refresh_btn.clicked.connect(self.load_logs)
        
        clear_btn = QPushButton('🗑️ Clear Logs')
        clear_btn.clicked.connect(self.clear_logs)
        
        controls_layout.addWidget(refresh_btn)
        controls_layout.addWidget(clear_btn)
        controls_layout.addStretch()
        
        layout.addLayout(controls_layout)
        
        # Logs display
        self.logs_text = QTextEdit()
        self.logs_text.setReadOnly(True)
        layout.addWidget(self.logs_text)
        
        return widget
    
    def create_production_bridge_tab(self):
        """Create production bridge monitoring tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Bridge status section
        status_group = QGroupBox("🌐 Production Bridge Status")
        status_layout = QGridLayout(status_group)
        
        # Status indicators
        self.bridge_status_label = QLabel('🔴 Not Connected')
        self.bridge_status_label.setStyleSheet('font-size: 16px; color: #FF4444;')
        status_layout.addWidget(QLabel('Status:'), 0, 0)
        status_layout.addWidget(self.bridge_status_label, 0, 1)
        
        self.bridge_last_sync_label = QLabel('Never')
        status_layout.addWidget(QLabel('Last Sync:'), 1, 0)
        status_layout.addWidget(self.bridge_last_sync_label, 1, 1)
        
        self.bridge_sync_count_label = QLabel('0')
        status_layout.addWidget(QLabel('Sync Count:'), 2, 0)
        status_layout.addWidget(self.bridge_sync_count_label, 2, 1)
        
        self.bridge_website_url_label = QLabel('https://simracingacademy.eu')
        status_layout.addWidget(QLabel('Website:'), 3, 0)
        status_layout.addWidget(self.bridge_website_url_label, 3, 1)
        
        layout.addWidget(status_group)
        
        # Sync statistics
        stats_group = QGroupBox("📊 Sync Statistics")
        stats_layout = QGridLayout(stats_group)
        
        self.bridge_users_synced_label = QLabel('0')
        stats_layout.addWidget(QLabel('Users Synced:'), 0, 0)
        stats_layout.addWidget(self.bridge_users_synced_label, 0, 1)
        
        self.bridge_sessions_synced_label = QLabel('0')
        stats_layout.addWidget(QLabel('Sessions Synced:'), 1, 0)
        stats_layout.addWidget(self.bridge_sessions_synced_label, 1, 1)
        
        self.bridge_leaderboard_synced_label = QLabel('0')
        stats_layout.addWidget(QLabel('Leaderboard Synced:'), 2, 0)
        stats_layout.addWidget(self.bridge_leaderboard_synced_label, 2, 1)
        
        layout.addWidget(stats_group)
        
        # Controls
        controls_layout = QHBoxLayout()
        
        self.bridge_start_btn = QPushButton('▶️ Start Bridge')
        self.bridge_start_btn.clicked.connect(self.start_production_bridge)
        
        self.bridge_stop_btn = QPushButton('⏹️ Stop Bridge')
        self.bridge_stop_btn.clicked.connect(self.stop_production_bridge)
        
        refresh_bridge_btn = QPushButton('🔄 Refresh Status')
        refresh_bridge_btn.clicked.connect(self.refresh_bridge_status)
        
        clear_bridge_logs_btn = QPushButton('🗑️ Clear Bridge Logs')
        clear_bridge_logs_btn.clicked.connect(self.clear_bridge_logs)
        
        controls_layout.addWidget(self.bridge_start_btn)
        controls_layout.addWidget(self.bridge_stop_btn)
        controls_layout.addWidget(refresh_bridge_btn)
        controls_layout.addWidget(clear_bridge_logs_btn)
        controls_layout.addStretch()
        
        layout.addLayout(controls_layout)
        
        # Bridge logs display
        bridge_logs_group = QGroupBox("📝 Production Bridge Logs")
        bridge_logs_layout = QVBoxLayout(bridge_logs_group)
        
        self.bridge_logs_text = QTextEdit()
        self.bridge_logs_text.setReadOnly(True)
        self.bridge_logs_text.setMaximumHeight(200)
        bridge_logs_layout.addWidget(self.bridge_logs_text)
        
        layout.addWidget(bridge_logs_group)
        
        return widget
    
    def create_status_bar(self):
        """Create status bar"""
        status_bar = self.statusBar()
        
        # Connection status
        self.connection_label = QLabel('🔴 Not Connected')
        status_bar.addWidget(self.connection_label)
        
        # Bridge status indicator
        self.bridge_status_indicator = QLabel('🔴 Bridge: Off')
        self.bridge_status_indicator.setStyleSheet('color: #FF4444; margin-left: 20px;')
        status_bar.addWidget(self.bridge_status_indicator)
        
        # Last update
        self.last_update_label = QLabel('Last Update: Never')
        status_bar.addPermanentWidget(self.last_update_label)
    
    def init_timers(self):
        """Initialize update timers"""
        # Update data every 10 seconds (slower to avoid conflicts)
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.trigger_refresh)  # Use sync wrapper
        self.update_timer.start(10000)  # 10 seconds
        
        # Update timestamp every second
        self.timestamp_timer = QTimer()
        self.timestamp_timer.timeout.connect(self.update_timestamp)
        self.timestamp_timer.start(1000)  # 1 second
    
    def trigger_refresh(self):
        """Sync wrapper to trigger async refresh from QTimer"""
        try:
            # Create task in the current event loop
            asyncio.create_task(self.refresh_all_data())
        except RuntimeError:
            # If no event loop is running, skip this update
            logger.debug("No event loop for refresh, skipping update")
    
    def update_timestamp(self):
        """Update timestamp in status bar"""
        now = datetime.now().strftime('%H:%M:%S')
        self.last_update_label.setText(f'Last Update: {now}')
    
    async def start_updates(self):
        """Start async data updates"""
        # Initial load
        await self.check_server_connection()
        await self.refresh_all_data()
        
        # Set up periodic refresh task
        asyncio.create_task(self.periodic_refresh())
    
    async def periodic_refresh(self):
        """Periodic refresh task running in background"""
        while True:
            try:
                await asyncio.sleep(3)  # Wait 3 seconds (faster refresh)
                await self.refresh_all_data()
            except Exception as e:
                logger.error(f"Periodic refresh error: {e}")
                await asyncio.sleep(10)  # Wait longer on error
    
    async def check_server_connection(self):
        """Check server connection status"""
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            async with self.session.get(f'{self.server_url}/api/status') as response:
                if response.status == 200:
                    self.server_status_label.setText('🟢 Connected')
                    self.server_status_label.setStyleSheet('font-size: 16px; color: #00FF88;')
                    self.connection_label.setText('🟢 Server Online')
                    return True
                else:
                    raise Exception(f"Status: {response.status}")
                    
        except Exception as e:
            self.server_status_label.setText('🔴 Disconnected')
            self.server_status_label.setStyleSheet('font-size: 16px; color: #FF4444;')
            self.connection_label.setText(f'🔴 Server Offline: {str(e)}')
            return False
    
    async def refresh_all_data(self):
        """Refresh all data from server"""
        try:
            if await self.check_server_connection():
                logger.info("Server connected, refreshing all data...")
                # Load data sequentially to avoid asyncio task conflicts
                await self.load_stats()
                await self.load_users()
                await self.load_computers()
                await self.load_sessions()
                await self.load_logs()
                await self.load_leaderboard()
                await self.load_bridge_logs()
                self.refresh_bridge_status()
                logger.info("All data refresh completed")
        except Exception as e:
            logger.error(f"Error refreshing all data: {e}")
            import traceback
            logger.error(f"Refresh error traceback: {traceback.format_exc()}")
    
    async def load_stats(self):
        """Load statistics from server"""
        try:
            logger.info(f"Loading stats from: {self.server_url}/api/admin/stats")
            async with self.session.get(f'{self.server_url}/api/admin/stats') as response:
                if response.status == 200:
                    data = await response.json()
                    stats = data.get('stats', {})
                    
                    logger.info(f"Stats API response: {stats}")
                    
                    # Update stats cards with better error handling
                    today_revenue = f"{stats.get('today', 0):.2f} BGN"
                    active_sessions = str(stats.get('active_sessions', 0))
                    computers_online = str(stats.get('computers_online', 0))
                    monthly_revenue = f"{stats.get('month', 0):.2f} BGN"
                    
                    logger.info(f"Updating cards: Today={today_revenue}, Active={active_sessions}, Online={computers_online}, Monthly={monthly_revenue}")
                    
                    # Update each card with better error handling
                    try:
                        self.revenue_today_card.update_value(today_revenue)
                        logger.info(f"Revenue card updated: {self.revenue_today_card.value_label.text()}")
                    except Exception as e:
                        logger.error(f"Error updating revenue card: {e}")
                    
                    try:
                        self.active_users_card.update_value(active_sessions)
                        logger.info(f"Active users card updated: {self.active_users_card.value_label.text()}")
                    except Exception as e:
                        logger.error(f"Error updating active users card: {e}")
                    
                    try:
                        self.online_computers_card.update_value(computers_online)
                        logger.info(f"Online computers card updated: {self.online_computers_card.value_label.text()}")
                    except Exception as e:
                        logger.error(f"Error updating online computers card: {e}")
                    
                    try:
                        self.monthly_revenue_card.update_value(monthly_revenue)
                        logger.info(f"Monthly revenue card updated: {self.monthly_revenue_card.value_label.text()}")
                    except Exception as e:
                        logger.error(f"Error updating monthly revenue card: {e}")
                    
                    logger.info("Stats cards updated successfully")
                else:
                    logger.error(f"Failed to load stats: HTTP {response.status}")
                    # Set default values if API fails
                    self.revenue_today_card.update_value("0.00 BGN")
                    self.active_users_card.update_value("0")
                    self.online_computers_card.update_value("0")
                    self.monthly_revenue_card.update_value("0.00 BGN")
                    
        except Exception as e:
            logger.error(f"Error loading stats: {e}")
            import traceback
            logger.error(f"Stats error traceback: {traceback.format_exc()}")
            # Set error indicators
            self.revenue_today_card.update_value("ERROR")
            self.active_users_card.update_value("ERROR")
            self.online_computers_card.update_value("ERROR")
            self.monthly_revenue_card.update_value("ERROR")
    
    async def load_users(self):
        """Load users from server with pagination support"""
        try:
            logger.info(f"Loading users from: {self.server_url}/api/admin/users")
            async with self.session.get(f'{self.server_url}/api/admin/users') as response:
                logger.info(f"Users API response status: {response.status}")
                if response.status == 200:
                    data = await response.json()
                    users = data.get('users', [])
                    
                    logger.info(f"Users API response: Found {len(users)} users")
                    
                    # Store all users data for pagination
                    self.all_users_data = users
                    
                    # Update the paginated display
                    self.update_users_display()
                    
                    logger.info(f"Users loaded and paginated display updated")
                    
                else:
                    logger.error(f"Failed to load users: HTTP {response.status}")
                    response_text = await response.text()
                    logger.error(f"Response: {response_text}")
                    
                    # Clear data on error
                    self.all_users_data = []
                    self.update_users_display()
                    
        except Exception as e:
            logger.error(f"Error loading users: {e}")
            import traceback
            logger.error(f"Users error traceback: {traceback.format_exc()}")
            
            # Clear data on error
            self.all_users_data = []
            self.update_users_display()
    
    async def load_computers(self):
        """Load computers from server"""
        try:
            async with self.session.get(f'{self.server_url}/api/admin/computers') as response:
                if response.status == 200:
                    data = await response.json()
                    computers = data.get('computers', [])
                    
                    self.computers_table.setRowCount(len(computers))
                    
                    for row, computer in enumerate(computers):
                        self.computers_table.setItem(row, 0, QTableWidgetItem(computer['computer_id']))
                        self.computers_table.setItem(row, 1, QTableWidgetItem(computer['name']))
                        self.computers_table.setItem(row, 2, QTableWidgetItem(computer['ip_address'] or 'Unknown'))
                        
                        status = '🟢 Online' if computer.get('has_active_session') else '🔴 Offline'
                        self.computers_table.setItem(row, 3, QTableWidgetItem(status))
                        self.computers_table.setItem(row, 4, QTableWidgetItem(computer['last_seen']))
                    
        except Exception as e:
            logger.error(f"Error loading computers: {e}")
    
    async def load_sessions(self):
        """Load active sessions from server"""
        try:
            async with self.session.get(f'{self.server_url}/api/admin/sessions') as response:
                if response.status == 200:
                    data = await response.json()
                    sessions = data.get('sessions', [])
                    
                    self.sessions_table.setRowCount(len(sessions))
                    
                    for row, session in enumerate(sessions):
                        self.sessions_table.setItem(row, 0, QTableWidgetItem(session['session_id'][:8] + '...'))
                        self.sessions_table.setItem(row, 1, QTableWidgetItem(session['username']))
                        self.sessions_table.setItem(row, 2, QTableWidgetItem(session['computer_id']))
                        self.sessions_table.setItem(row, 3, QTableWidgetItem(session['start_time']))
                        
                        remaining = session.get('remaining_time', session['duration_minutes'])
                        self.sessions_table.setItem(row, 4, QTableWidgetItem(f"{remaining} min"))
                        
                        # Store full session_id in item data
                        self.sessions_table.item(row, 0).setData(Qt.UserRole, session['session_id'])
                    
        except Exception as e:
            logger.error(f"Error loading sessions: {e}")
    
    async def load_logs(self):
        """Load system logs"""
        try:
            # Read server log file
            log_file = 'server.log'
            if not os.path.exists(log_file):
                self.logs_text.setPlainText("No log file found. Server logs will appear here once the server starts logging.")
                return
                
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                logs = f.read()
                # Get last 100 lines
                lines = logs.split('\n')[-100:]
                self.logs_text.setPlainText('\n'.join(lines))
                
                # Auto-scroll to bottom - Fix the QTextCursor.End attribute error
                cursor = self.logs_text.textCursor()
                cursor.movePosition(QTextCursor.End)  # Fixed: Use QTextCursor.End instead of cursor.End
                self.logs_text.setTextCursor(cursor)
                
        except Exception as e:
            self.logs_text.setPlainText(f"Error loading logs: {e}")
            logger.error(f"Error loading logs: {e}")
    
    async def load_bridge_logs(self):
        """Load production bridge logs"""
        try:
            # Read bridge log file
            log_file = 'production_bridge.log'
            if not os.path.exists(log_file):
                self.bridge_logs_text.setPlainText("No bridge log file found. Production bridge logs will appear here once the bridge starts.")
                return
                
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                logs = f.read()
                # Get last 50 lines
                lines = logs.split('\n')[-50:]
                self.bridge_logs_text.setPlainText('\n'.join(lines))
                
                # Auto-scroll to bottom
                cursor = self.bridge_logs_text.textCursor()
                cursor.movePosition(QTextCursor.End)
                self.bridge_logs_text.setTextCursor(cursor)
                
        except Exception as e:
            self.bridge_logs_text.setPlainText(f"Error loading bridge logs: {e}")
            logger.error(f"Error loading bridge logs: {e}")
    
    def start_production_bridge(self):
        """Start production bridge with visible output"""
        try:
            import subprocess
            import os
            
            # Check if bridge is already running
            if self.is_bridge_running():
                QMessageBox.warning(self, '⚠️ Warning', 'Production Bridge is already running!')
                return
            
            # Start bridge as background process with visible console
            bridge_script = os.path.join(os.path.dirname(__file__), 'production_bridge.py')
            if os.path.exists(bridge_script):
                # Start process in background with visible console window
                if os.name == 'nt':  # Windows
                    # Create new console window for bridge
                    self.bridge_process = subprocess.Popen(
                        [sys.executable, bridge_script], 
                        creationflags=subprocess.CREATE_NEW_CONSOLE,
                        cwd=os.path.dirname(__file__)
                    )
                else:  # Linux/Mac
                    self.bridge_process = subprocess.Popen(
                        [sys.executable, bridge_script],
                        cwd=os.path.dirname(__file__)
                    )
                
                self.bridge_status_label.setText('🟡 Starting...')
                self.bridge_status_label.setStyleSheet('font-size: 16px; color: #FFA500;')
                
                # Update status bar indicator
                self.bridge_status_indicator.setText('🟡 Bridge: Starting...')
                self.bridge_status_indicator.setStyleSheet('color: #FFA500; margin-left: 20px;')
                
                # Check status after 3 seconds
                QTimer.singleShot(3000, self.refresh_bridge_status)
                
                logger.info("Production Bridge started with visible console")
                QMessageBox.information(self, '✅ Success', 'Production Bridge started successfully!\nConsole window will show sync activity.')
            else:
                QMessageBox.critical(self, '❌ Error', 'production_bridge.py not found!')
                
        except Exception as e:
            logger.error(f"Error starting bridge: {e}")
            QMessageBox.critical(self, '❌ Error', f'Failed to start bridge: {e}')
    
    def stop_production_bridge(self):
        """Stop production bridge"""
        try:
            killed = False
            
            # First try to terminate the known process
            if self.bridge_process and self.bridge_process.poll() is None:
                try:
                    self.bridge_process.terminate()
                    self.bridge_process.wait(timeout=5)
                    killed = True
                    logger.info(f"Terminated bridge process: {self.bridge_process.pid}")
                except subprocess.TimeoutExpired:
                    # Force kill if terminate doesn't work
                    self.bridge_process.kill()
                    self.bridge_process.wait()
                    killed = True
                    logger.info(f"Force killed bridge process: {self.bridge_process.pid}")
                except Exception as e:
                    logger.error(f"Error terminating known process: {e}")
            
            # Fallback: Find and kill all bridge processes
            if not killed:
                import psutil
                for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                    try:
                        if proc.info['name'] == 'python.exe' or proc.info['name'] == 'python':
                            cmdline = proc.info['cmdline']
                            if cmdline and any('production_bridge.py' in arg for arg in cmdline):
                                proc.terminate()
                                killed = True
                                logger.info(f"Killed production bridge process: {proc.info['pid']}")
                                break
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
            
            if killed:
                self.bridge_process = None
                self.bridge_status_label.setText('🔴 Stopped')
                self.bridge_status_label.setStyleSheet('font-size: 16px; color: #FF4444;')
                
                # Update status bar indicator
                self.bridge_status_indicator.setText('🔴 Bridge: Off')
                self.bridge_status_indicator.setStyleSheet('color: #FF4444; margin-left: 20px;')
                
                QMessageBox.information(self, '✅ Success', 'Production Bridge stopped successfully!')
            else:
                QMessageBox.warning(self, '⚠️ Warning', 'No running Production Bridge process found!')
                
        except Exception as e:
            logger.error(f"Error stopping bridge: {e}")
            QMessageBox.critical(self, '❌ Error', f'Failed to stop bridge: {e}')
    
    def is_bridge_running(self):
        """Check if production bridge is running"""
        try:
            # First check the known process
            if self.bridge_process and self.bridge_process.poll() is None:
                return True
            
            # Fallback: Check all processes
            import psutil
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] == 'python.exe' or proc.info['name'] == 'python':
                        cmdline = proc.info['cmdline']
                        if cmdline and any('production_bridge.py' in arg for arg in cmdline):
                            return True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            return False
            
        except Exception:
            return False
    
    def refresh_bridge_status(self):
        """Refresh production bridge status"""
        try:
            if self.is_bridge_running():
                self.bridge_status_label.setText('🟢 Running')
                self.bridge_status_label.setStyleSheet('font-size: 16px; color: #00FF88;')
                
                # Update status bar indicator
                self.bridge_status_indicator.setText('🟢 Bridge: On')
                self.bridge_status_indicator.setStyleSheet('color: #00FF88; margin-left: 20px;')
                
                # Load bridge logs
                asyncio.create_task(self.load_bridge_logs())
                
                # Update sync statistics from log file
                self.update_bridge_stats()
                
            else:
                self.bridge_status_label.setText('🔴 Not Running')
                self.bridge_status_label.setStyleSheet('font-size: 16px; color: #FF4444;')
                
                # Update status bar indicator
                self.bridge_status_indicator.setText('🔴 Bridge: Off')
                self.bridge_status_indicator.setStyleSheet('color: #FF4444; margin-left: 20px;')
                
        except Exception as e:
            logger.error(f"Error refreshing bridge status: {e}")
    
    def update_bridge_stats(self):
        """Update bridge statistics from log file"""
        try:
            log_file = 'production_bridge.log'
            if not os.path.exists(log_file):
                return
                
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                logs = f.read()
                
            # Count sync events
            users_synced = logs.count('Users synced:')
            sessions_synced = logs.count('Sessions synced:')
            leaderboard_synced = logs.count('Leaderboard synced:')
            
            self.bridge_users_synced_label.setText(str(users_synced))
            self.bridge_sessions_synced_label.setText(str(sessions_synced))
            self.bridge_leaderboard_synced_label.setText(str(leaderboard_synced))
            
            # Find last sync time
            import re
            sync_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})'
            matches = re.findall(sync_pattern, logs)
            if matches:
                last_sync = matches[-1]
                self.bridge_last_sync_label.setText(last_sync)
                
        except Exception as e:
            logger.error(f"Error updating bridge stats: {e}")
    
    def clear_bridge_logs(self):
        """Clear production bridge logs"""
        try:
            log_file = 'production_bridge.log'
            if os.path.exists(log_file):
                with open(log_file, 'w', encoding='utf-8') as f:
                    f.write('')
                
                self.bridge_logs_text.clear()
                QMessageBox.information(self, '✅ Success', 'Production Bridge logs cleared!')
                logger.info("Production Bridge logs cleared")
            else:
                QMessageBox.warning(self, '⚠️ Warning', 'No bridge log file found!')
                
        except Exception as e:
            logger.error(f"Error clearing bridge logs: {e}")
            QMessageBox.critical(self, '❌ Error', f'Failed to clear bridge logs: {e}')
    
    # Users pagination methods
    def on_users_search_changed(self):
        """Handle search input changes"""
        self.users_search_query = self.users_search_input.text().strip().lower()
        self.users_current_page = 1  # Reset to first page
        self.update_users_display()
    
    def clear_users_search(self):
        """Clear search input"""
        self.users_search_input.clear()
        self.users_search_query = ""
        self.users_current_page = 1
        self.update_users_display()
    
    def on_users_per_page_changed(self, value):
        """Handle items per page change"""
        self.users_per_page = int(value)
        self.users_current_page = 1  # Reset to first page
        self.update_users_display()
    
    def users_previous_page(self):
        """Go to previous page"""
        if self.users_current_page > 1:
            self.users_current_page -= 1
            self.update_users_display()
    
    def users_next_page(self):
        """Go to next page"""
        total_pages = self.get_users_total_pages()
        if self.users_current_page < total_pages:
            self.users_current_page += 1
            self.update_users_display()
    
    def users_goto_page(self):
        """Go to specific page"""
        try:
            page = int(self.users_goto_page_input.text())
            total_pages = self.get_users_total_pages()
            if 1 <= page <= total_pages:
                self.users_current_page = page
                self.update_users_display()
                self.users_goto_page_input.clear()
            else:
                QMessageBox.warning(self, '⚠️ Warning', f'Page must be between 1 and {total_pages}')
        except ValueError:
            QMessageBox.warning(self, '⚠️ Warning', 'Please enter a valid page number')
    
    def get_filtered_users(self):
        """Get users filtered by search query"""
        if not self.users_search_query:
            return self.all_users_data
        
        return [user for user in self.all_users_data 
                if self.users_search_query in user.get('username', '').lower()]
    
    def get_users_total_pages(self):
        """Calculate total pages for users"""
        filtered_users = self.get_filtered_users()
        return max(1, (len(filtered_users) + self.users_per_page - 1) // self.users_per_page)
    
    def get_paginated_users(self):
        """Get users for current page"""
        filtered_users = self.get_filtered_users()
        start_idx = (self.users_current_page - 1) * self.users_per_page
        end_idx = start_idx + self.users_per_page
        return filtered_users[start_idx:end_idx]
    
    def update_users_pagination_controls(self):
        """Update pagination control states"""
        total_pages = self.get_users_total_pages()
        filtered_count = len(self.get_filtered_users())
        total_count = len(self.all_users_data)
        
        # Update page label
        self.users_page_label.setText(f'Page {self.users_current_page} of {total_pages}')
        
        # Update button states
        self.users_prev_btn.setEnabled(self.users_current_page > 1)
        self.users_next_btn.setEnabled(self.users_current_page < total_pages)
        
        # Update results label
        if self.users_search_query:
            self.users_results_label.setText(f'Showing {filtered_count} of {total_count} users (filtered)')
        else:
            self.users_results_label.setText(f'Showing {total_count} users')
    
    def update_users_display(self):
        """Update users table display with pagination"""
        try:
            paginated_users = self.get_paginated_users()
            
            # Clear existing rows
            self.users_table.setRowCount(0)
            
            # Populate table with paginated data
            for row, user in enumerate(paginated_users):
                self.users_table.insertRow(row)
                
                # Username
                username_item = QTableWidgetItem(str(user.get('username', '')))
                username_item.setData(Qt.UserRole, user)  # Store complete user data for edit functionality
                self.users_table.setItem(row, 0, username_item)
                
                # Basic Minutes
                basic_minutes_item = QTableWidgetItem(str(user.get('basic_minutes', 0)))
                # Style basic minutes with light gray background
                basic_minutes_item.setBackground(QColor(220, 220, 220, 100))  # Light gray with transparency
                self.users_table.setItem(row, 1, basic_minutes_item)
                
                # Standard Minutes
                standard_minutes_item = QTableWidgetItem(str(user.get('standard_minutes', 0)))
                # Style standard minutes with light blue background
                standard_minutes_item.setBackground(QColor(0, 161, 156, 100))  # Teal with transparency
                self.users_table.setItem(row, 2, standard_minutes_item)
                
                # Premium Minutes
                premium_minutes_item = QTableWidgetItem(str(user.get('premium_minutes', 0)))
                # Style premium minutes with gold background
                premium_minutes_item.setBackground(QColor(255, 215, 0, 100))  # Gold with transparency
                self.users_table.setItem(row, 3, premium_minutes_item)
                
                # Admin
                admin_item = QTableWidgetItem('Yes' if user.get('is_admin') else 'No')
                self.users_table.setItem(row, 4, admin_item)
                
                # Active
                active_item = QTableWidgetItem('Yes' if user.get('is_active') else 'No')
                self.users_table.setItem(row, 5, active_item)
                
                # Last Login
                last_login = user.get('last_login') or 'Never'
                if last_login != 'Never' and 'T' in last_login:
                    try:
                        last_login = last_login.split('T')[0] + ' ' + last_login.split('T')[1][:5]
                    except:
                        pass
                last_login_item = QTableWidgetItem(last_login)
                self.users_table.setItem(row, 6, last_login_item)
                
                # Total Spent
                total_spent = f"{user.get('total_spent', 0):.2f} BGN"
                total_spent_item = QTableWidgetItem(total_spent)
                self.users_table.setItem(row, 7, total_spent_item)
                
                # Created
                created = user.get('created_at', '')
                if created and 'T' in created:
                    try:
                        created = created.split('T')[0]
                    except:
                        pass
                created_item = QTableWidgetItem(created)
                self.users_table.setItem(row, 8, created_item)
            
            # Update pagination controls
            self.update_users_pagination_controls()
            
            logger.info(f"Users display updated: Page {self.users_current_page}, {len(paginated_users)} users shown")
            
        except Exception as e:
            logger.error(f"Error updating users display: {e}")
    
    async def load_leaderboard(self):
        """Load user leaderboard by playtime"""
        try:
            async with self.session.get(f'{self.server_url}/api/admin/leaderboard') as response:
                if response.status == 200:
                    data = await response.json()
                    leaderboard = data.get('leaderboard', [])
                    self.leaderboard_card.update_leaderboard(leaderboard)
                    logger.debug(f"Leaderboard loaded: {len(leaderboard)} players")
                else:
                    logger.error(f"Failed to load leaderboard: HTTP {response.status}")
                    self.leaderboard_card.update_leaderboard([])
                    
        except Exception as e:
            logger.error(f"Error loading leaderboard: {e}")
            self.leaderboard_card.update_leaderboard([])
    
    def manual_refresh_leaderboard(self):
        """Manually refresh leaderboard immediately"""
        logger.info("Manual leaderboard refresh triggered")
        asyncio.create_task(self.load_leaderboard())
        # Also refresh stats since session might have ended
        asyncio.create_task(self.load_stats())
        # Add activity log
        self.add_activity("Leaderboard manually refreshed")
    
    def show_create_user_dialog(self):
        """Show create user dialog"""
        dialog = CreateUserDialog(self)
        if dialog.exec():
            user_data = dialog.get_user_data()
            if user_data['username'] and user_data['password']:
                asyncio.create_task(self.create_user(user_data))
            else:
                QMessageBox.warning(self, 'Error', 'Username and password are required!')
    
    def show_add_time_dialog(self):
        """Show add time dialog"""
        # Get current users for dropdown
        users = []
        for row in range(self.users_table.rowCount()):
            username = self.users_table.item(row, 0).text()
            users.append({'username': username})
        
        if not users:
            QMessageBox.warning(self, 'No Users', 'No users available. Create users first.')
            return
        
        dialog = AddTimeDialog(users, self)
        if dialog.exec():
            data = dialog.get_data()
            asyncio.create_task(self.add_time(data))
    
    def schedule_async_task(self, coro):
        """Schedule an async task from synchronous context"""
        try:
            task = asyncio.create_task(coro)
            return task
        except Exception as e:
            print(f"Error scheduling async task: {e}")
            return None
    
    def show_edit_user_dialog(self):
        """Show edit user dialog"""
        current_row = self.users_table.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, 'No Selection', 'Please select a user to edit.')
            return
        
        # Get user data from table
        user_data = self.users_table.item(current_row, 0).data(Qt.UserRole)
        if not user_data:
            QMessageBox.warning(self, 'Error', 'User data not available. Please refresh the users list.')
            return
        
        dialog = EditUserDialog(user_data, self)
        if dialog.exec():
            action_type = dialog.get_action_type()
            
            if action_type == 'delete':
                # Handle user deletion
                delete_data = {'user_id': user_data['id'], 'username': user_data['username']}
                self.schedule_async_task(self.delete_user(delete_data))
            elif action_type == 'save':
                # Handle user update (save)
                updated_data = dialog.get_user_data()
                self.schedule_async_task(self.update_user(updated_data))
            # If action_type is 'cancel', do nothing
    
    async def create_user(self, user_data):
        """Create new user"""
        try:
            async with self.session.post(f'{self.server_url}/api/admin/create_user', json=user_data) as response:
                if response.status == 200:
                    QMessageBox.information(self, 'Success', f'User {user_data["username"]} created successfully!')
                    await self.load_users()
                    
                    # Add to activity log
                    self.add_activity(f"Created user: {user_data['username']}")
                else:
                    error_data = await response.json()
                    QMessageBox.critical(self, 'Error', f'Failed to create user: {error_data.get("message", "Unknown error")}')
                    
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to create user: {str(e)}')
    
    async def add_time(self, data):
        """Add time to user"""
        try:
            async with self.session.post(f'{self.server_url}/api/admin/add_time', json=data) as response:
                if response.status == 200:
                    minute_type = data.get('minute_type', 'basic').capitalize()
                    QMessageBox.information(self, 'Success', f'Added {data["minutes"]} {minute_type} minutes to {data["username"]}!')
                    await self.load_users()
                    
                    # Add to activity log
                    self.add_activity(f"Added {data['minutes']} {minute_type} minutes to {data['username']} (Paid: {data['amount']:.2f} BGN)")
                else:
                    error_data = await response.json()
                    QMessageBox.critical(self, 'Error', f'Failed to add time: {error_data.get("message", "Unknown error")}')
                    
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to add time: {str(e)}')
    
    async def update_user(self, user_data):
        """Update user information"""
        try:
            async with self.session.put(f'{self.server_url}/api/admin/update_user', json=user_data) as response:
                if response.status == 200:
                    QMessageBox.information(self, 'Success', f'User {user_data["username"]} updated successfully!')
                    await self.load_users()
                    
                    # Add to activity log
                    changes = []
                    if user_data.get('password'):
                        changes.append("password changed")
                    if user_data.get('is_admin') is not None:
                        changes.append(f"admin: {user_data['is_admin']}")
                    if user_data.get('is_active') is not None:
                        changes.append(f"active: {user_data['is_active']}")
                    if user_data.get('minutes') is not None:
                        changes.append(f"minutes: {user_data['minutes']}")
                    
                    change_desc = ", ".join(changes) if changes else "profile updated"
                    self.add_activity(f"Updated user {user_data['username']}: {change_desc}")
                else:
                    error_data = await response.json()
                    QMessageBox.critical(self, 'Error', f'Failed to update user: {error_data.get("message", "Unknown error")}')
                    
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to update user: {str(e)}')
    
    async def delete_user(self, delete_data):
        """Delete user permanently"""
        async with self._async_lock:
            try:
                print(f"🗑️ DEBUG: Starting delete for user {delete_data['username']} (ID: {delete_data['user_id']})")
                async with self.session.delete(f'{self.server_url}/api/admin/delete_user', json=delete_data) as response:
                    print(f"🗑️ DEBUG: Delete API response: {response.status}")
                    if response.status == 200:
                        response_data = await response.json()
                        print(f"🗑️ DEBUG: Delete API response data: {response_data}")
                        
                        QMessageBox.information(
                            self, 
                            'Success', 
                            f'User "{delete_data["username"]}" has been permanently deleted!'
                        )
                        
                        # Force clear cache and reload users
                        print("🗑️ DEBUG: Clearing user cache and reloading...")
                        self.all_users_data = []
                        self.users_current_page = 1
                        await self.load_users()
                        
                        # Force refresh display
                        print("🗑️ DEBUG: Force refreshing display...")
                        self.update_users_display()
                        
                        # Add to activity log
                        self.add_activity(f"🗑️ DELETED user: {delete_data['username']} (ID: {delete_data['user_id']})")
                        print(f"🗑️ DEBUG: Delete completed successfully for user {delete_data['username']}")
                    else:
                        response_text = await response.text()
                        print(f"🗑️ DEBUG: Delete failed with response: {response_text}")
                        QMessageBox.critical(
                            self, 
                            'Error', 
                            f'Failed to delete user: {response_text}'
                        )
            except Exception as e:
                print(f"🗑️ DEBUG: Exception in delete_user: {e}")
                QMessageBox.critical(self, 'Error', f'Failed to delete user: {str(e)}')
    
    def show_user_context_menu(self, position):
        """Show context menu for users table"""
        if self.users_table.itemAt(position) is None:
            return
        
        menu = QMenu(self)
        menu.setStyleSheet('''
            QMenu {
                background-color: #1a1a2e;
                color: white;
                border: 2px solid #00A19C;
                border-radius: 8px;
                padding: 5px;
            }
            QMenu::item {
                padding: 8px 20px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #00A19C;
                color: black;
            }
        ''')
        
        edit_action = QAction('✏️ Edit User', self)
        edit_action.triggered.connect(self.show_edit_user_dialog)
        menu.addAction(edit_action)
        
        view_action = QAction('👁️ View Details', self)
        view_action.triggered.connect(self.show_user_details)
        menu.addAction(view_action)
        
        menu.addSeparator()
        
        add_time_action = QAction('💰 Add Time', self)
        add_time_action.triggered.connect(self.show_add_time_dialog)
        menu.addAction(add_time_action)
        
        menu.exec(self.users_table.mapToGlobal(position))
    
    def show_computer_context_menu(self, position):
        """Show context menu for computers table"""
        if self.computers_table.itemAt(position) is None:
            return
        
        menu = QMenu(self)
        menu.setStyleSheet('''
            QMenu {
                background-color: #1a1a2e;
                color: white;
                border: 2px solid #00A19C;
                border-radius: 8px;
                padding: 5px;
            }
            QMenu::item {
                padding: 8px 20px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #00A19C;
                color: black;
            }
        ''')
        
        # Get selected computer info
        current_row = self.computers_table.currentRow()
        if current_row >= 0:
            computer_id = self.computers_table.item(current_row, 0).text()
            status = self.computers_table.item(current_row, 3).text()
            
            # Check if computer has active session
            has_active_session = '🟢 Online' in status
            
            view_action = QAction('👁️ View Details', self)
            view_action.triggered.connect(self.show_computer_details)
            menu.addAction(view_action)
            
            menu.addSeparator()
            
            # Only allow delete if computer is offline
            if not has_active_session:
                delete_action = QAction('🗑️ Delete Computer', self)
                delete_action.triggered.connect(self.delete_computer)
                menu.addAction(delete_action)
            else:
                disabled_action = QAction('🗑️ Delete Computer (Active Session)', self)
                disabled_action.setEnabled(False)
                menu.addAction(disabled_action)
        
        menu.exec(self.computers_table.mapToGlobal(position))
    
    def show_user_details(self):
        """Show detailed user information"""
        current_row = self.users_table.currentRow()
        if current_row < 0:
            return
        
        user_data = self.users_table.item(current_row, 0).data(Qt.UserRole)
        if not user_data:
            return
        
        # Create details dialog
        dialog = QDialog(self)
        dialog.setWindowTitle(f'👤 User Details: {user_data["username"]}')
        dialog.setFixedSize(500, 400)
        dialog.setStyleSheet('''
            QDialog {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #1a1a2e, stop:1 #16213e);
                color: white;
            }
            QLabel { color: white; margin: 5px; }
            QPushButton {
                background: #00A19C;
                color: black;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
                font-weight: bold;
            }
        ''')
        
        layout = QVBoxLayout(dialog)
        
        # User information
        info_text = f"""
🆔 <b>User ID:</b> {user_data['id']}
👤 <b>Username:</b> {user_data['username']}
⏰ <b>Available Time:</b> {user_data['minutes']} minutes
🛡️ <b>Admin:</b> {'Yes' if user_data['is_admin'] else 'No'}
✅ <b>Active:</b> {'Yes' if user_data['is_active'] else 'No'}
💰 <b>Total Spent:</b> {user_data['total_spent']:.2f} BGN
📅 <b>Created:</b> {user_data.get('created_at', 'N/A')}
🕐 <b>Last Login:</b> {user_data.get('last_login', 'Never')}
        """
        
        info_label = QLabel(info_text)
        info_label.setWordWrap(True)
        info_label.setStyleSheet('font-size: 14px; background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px;')
        layout.addWidget(info_label)
        
        # Close button
        close_btn = QPushButton('✅ Close')
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)
        
        dialog.exec()
    
    def end_selected_session(self):
        """End selected session"""
        current_row = self.sessions_table.currentRow()
        if current_row >= 0:
            session_id = self.sessions_table.item(current_row, 0).data(Qt.UserRole)
            username = self.sessions_table.item(current_row, 1).text()
            
            reply = QMessageBox.question(
                self, 'End Session', 
                f'Are you sure you want to end the session for {username}?',
                QMessageBox.Yes | QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                asyncio.create_task(self.end_session(session_id, username))
        else:
            QMessageBox.warning(self, 'No Selection', 'Please select a session to end.')
    
    async def end_session(self, session_id, username):
        """End user session"""
        try:
            data = {'session_id': session_id}
            async with self.session.post(f'{self.server_url}/api/admin/end_session', json=data) as response:
                if response.status == 200:
                    QMessageBox.information(self, 'Success', f'Session for {username} ended successfully!')
                    await self.load_sessions()
                    
                    # Add to activity log
                    self.add_activity(f"Force ended session for {username}")
                else:
                    error_data = await response.json()
                    QMessageBox.critical(self, 'Error', f'Failed to end session: {error_data.get("message", "Unknown error")}')
                    
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to end session: {str(e)}')
    
    def show_computer_details(self):
        """Show detailed computer information"""
        current_row = self.computers_table.currentRow()
        if current_row < 0:
            return
        
        computer_id = self.computers_table.item(current_row, 0).text()
        name = self.computers_table.item(current_row, 1).text()
        ip_address = self.computers_table.item(current_row, 2).text()
        status = self.computers_table.item(current_row, 3).text()
        last_seen = self.computers_table.item(current_row, 4).text()
        
        details = f"""
🖥️ Computer Details

Computer ID: {computer_id}
Name: {name}
IP Address: {ip_address}
Status: {status}
Last Seen: {last_seen}

This computer is {'currently active' if '🟢 Online' in status else 'offline'}.
        """
        
        QMessageBox.information(self, f'Computer Details - {computer_id}', details.strip())
    
    def delete_computer(self):
        """Delete selected computer with confirmation"""
        current_row = self.computers_table.currentRow()
        if current_row < 0:
            return
        
        computer_id = self.computers_table.item(current_row, 0).text()
        name = self.computers_table.item(current_row, 1).text()
        
        # Double confirmation for safety
        reply = QMessageBox.question(
            self,
            '🗑️ Delete Computer',
            f'Are you sure you want to permanently delete computer "{name}" ({computer_id})?\n\n'
            f'This action will:\n'
            f'• Remove the computer from the system\n'
            f'• Delete all associated session history\n'
            f'• Remove simulator type assignments\n\n'
            f'This action cannot be undone!',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            # Additional confirmation with computer ID
            from PySide6.QtWidgets import QInputDialog
            confirmation, ok = QInputDialog.getText(
                self, 
                'Confirm Deletion', 
                f'Type "{computer_id}" to confirm deletion:',
                echo=QLineEdit.Normal
            )
            
            if ok and confirmation.strip() == computer_id:
                asyncio.create_task(self.perform_computer_deletion(computer_id, name))
            elif ok:
                QMessageBox.warning(self, 'Invalid Confirmation', 'Computer ID did not match. Deletion cancelled.')
    
    async def perform_computer_deletion(self, computer_id, name):
        """Perform the actual computer deletion"""
        try:
            delete_data = {
                'computer_id': computer_id
            }
            
            async with self.session.delete(f'{self.server_url}/api/admin/delete_computer', json=delete_data) as response:
                if response.status == 200:
                    QMessageBox.information(self, 'Success', f'Computer "{name}" deleted successfully!')
                    await self.load_computers()  # Refresh the computers list
                    self.add_activity(f"Deleted computer: {name} ({computer_id})")
                else:
                    error_data = await response.json()
                    QMessageBox.critical(self, 'Error', f'Failed to delete computer: {error_data.get("message", "Unknown error")}')
                    
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to delete computer: {str(e)}')

    def add_activity(self, message):
        """Add message to activity log"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        activity_msg = f"[{timestamp}] {message}\n"
        self.activity_text.append(activity_msg)
        
        # Auto-scroll to bottom
        cursor = self.activity_text.textCursor()
        cursor.movePosition(QTextCursor.End)  # Fixed: Use QTextCursor.End
        self.activity_text.setTextCursor(cursor)
    
    def cleanup_old_sessions(self):
        """Clean up old/orphaned sessions from development"""
        reply = QMessageBox.question(
            self, 'Clean Old Sessions', 
            'This will remove all sessions that are marked as active but may be orphaned from development.\n'
            'This cannot be undone. Are you sure?',
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            asyncio.create_task(self.perform_session_cleanup())
    
    async def perform_session_cleanup(self):
        """Perform the actual session cleanup"""
        try:
            async with self.session.post(f'{self.server_url}/api/admin/cleanup_sessions') as response:
                if response.status == 200:
                    data = await response.json()
                    cleaned_count = data.get('cleaned_sessions', 0)
                    QMessageBox.information(
                        self, 'Cleanup Complete', 
                        f'Successfully cleaned up {cleaned_count} old sessions!'
                    )
                    await self.load_sessions()
                    self.add_activity(f"Cleaned up {cleaned_count} old sessions")
                else:
                    error_data = await response.json()
                    QMessageBox.critical(
                        self, 'Cleanup Failed', 
                        f'Failed to clean sessions: {error_data.get("message", "Unknown error")}'
                    )
                    
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to clean sessions: {str(e)}')
    
    def clear_logs(self):
        """Clear logs display"""
        self.logs_text.clear()
    
    def create_simulators_tab(self):
        """Create simulators management tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        
        # Header
        header_layout = QHBoxLayout()
        
        title = QLabel("🏎️ Simulator Types & Configuration")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setStyleSheet("color: #00A19C; padding: 10px;")
        header_layout.addWidget(title)
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setStyleSheet('''
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #00A19C, stop:1 #008F8A);
                color: black;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #008F8A, stop:1 #00A19C);
            }
        ''')
        refresh_btn.clicked.connect(self.refresh_simulators)
        header_layout.addWidget(refresh_btn)
        
        layout.addLayout(header_layout)
        
        # Main content in splitter
        splitter = QSplitter(Qt.Vertical)
        
        # Simulator Types Section
        types_group = QGroupBox("Simulator Types & Rates")
        types_group.setStyleSheet('''
            QGroupBox {
                font-size: 14px;
                font-weight: bold;
                border: 2px solid rgba(0, 161, 156, 0.3);
                border-radius: 8px;
                margin: 10px 0px;
                padding-top: 10px;
                background: rgba(0, 0, 0, 0.1);
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 10px 0 10px;
                color: #00A19C;
            }
        ''')
        types_layout = QVBoxLayout(types_group)
        
        # Types table
        self.simulator_types_table = QTableWidget()
        self.simulator_types_table.setColumnCount(7)
        self.simulator_types_table.setHorizontalHeaderLabels([
            'Icon', 'Type', 'XP/min', 'Tokens/min', 'Color', 'Description', 'Actions'
        ])
        
        # Modern table styling
        self.simulator_types_table.setStyleSheet('''
            QTableWidget {
                background-color: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(0, 161, 156, 0.3);
                border-radius: 8px;
                gridline-color: rgba(0, 161, 156, 0.2);
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid rgba(0, 161, 156, 0.1);
            }
            QTableWidget::item:selected {
                background-color: rgba(0, 161, 156, 0.3);
            }
            QHeaderView::section {
                background-color: rgba(0, 161, 156, 0.2);
                padding: 8px;
                border: none;
                font-weight: bold;
                color: white;
            }
        ''')
        
        # Auto-resize columns
        header = self.simulator_types_table.horizontalHeader()
        header.setStretchLastSection(True)
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)  # Icon
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)  # Type
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)  # XP/min
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)  # Tokens/min
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)  # Color
        
        types_layout.addWidget(self.simulator_types_table)
        splitter.addWidget(types_group)
        
        # Computer Assignments Section
        configs_group = QGroupBox("Computer Assignments")
        configs_group.setStyleSheet('''
            QGroupBox {
                font-size: 14px;
                font-weight: bold;
                border: 2px solid rgba(0, 161, 156, 0.3);
                border-radius: 8px;
                margin: 10px 0px;
                padding-top: 10px;
                background: rgba(0, 0, 0, 0.1);
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 10px 0 10px;
                color: #00A19C;
            }
        ''')
        configs_layout = QVBoxLayout(configs_group)
        
        # Assignment controls
        assign_layout = QHBoxLayout()
        
        self.computer_combo = QComboBox()
        self.computer_combo.setStyleSheet('''
            QComboBox {
                background: rgba(255,255,255,0.1);
                border: 2px solid rgba(0, 161, 156,0.3);
                border-radius: 8px;
                padding: 8px;
                color: white;
                font-size: 14px;
                min-width: 150px;
            }
            QComboBox:focus {
                border: 2px solid #00A19C;
            }
            QComboBox::drop-down {
                border: none;
            }
            QComboBox::down-arrow {
                color: #00A19C;
            }
        ''')
        
        self.type_combo = QComboBox()
        self.type_combo.setStyleSheet('''
            QComboBox {
                background: rgba(255,255,255,0.1);
                border: 2px solid rgba(0, 161, 156,0.3);
                border-radius: 8px;
                padding: 8px;
                color: white;
                font-size: 14px;
                min-width: 150px;
            }
            QComboBox:focus {
                border: 2px solid #00A19C;
            }
        ''')
        
        assign_btn = QPushButton("⚡ Assign Type")
        assign_btn.setStyleSheet('''
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #FFD700, stop:1 #FFA500);
                color: black;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #FFA500, stop:1 #FFD700);
            }
        ''')
        assign_btn.clicked.connect(self.assign_simulator_type)
        
        assign_layout.addWidget(QLabel("Computer:"))
        assign_layout.addWidget(self.computer_combo)
        assign_layout.addWidget(QLabel("Type:"))
        assign_layout.addWidget(self.type_combo)
        assign_layout.addWidget(assign_btn)
        assign_layout.addStretch()
        
        configs_layout.addLayout(assign_layout)
        
        # Configs table
        self.simulator_configs_table = QTableWidget()
        self.simulator_configs_table.setColumnCount(6)
        self.simulator_configs_table.setHorizontalHeaderLabels([
            'Computer', 'IP Address', 'Type', 'Rates (XP/Tokens)', 'Status', 'Last Updated'
        ])
        
        self.simulator_configs_table.setStyleSheet('''
            QTableWidget {
                background-color: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(0, 161, 156, 0.3);
                border-radius: 8px;
                gridline-color: rgba(0, 161, 156, 0.2);
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid rgba(0, 161, 156, 0.1);
            }
            QTableWidget::item:selected {
                background-color: rgba(0, 161, 156, 0.3);
            }
            QHeaderView::section {
                background-color: rgba(0, 161, 156, 0.2);
                padding: 8px;
                border: none;
                font-weight: bold;
                color: white;
            }
        ''')
        
        # Auto-resize columns
        header2 = self.simulator_configs_table.horizontalHeader()
        header2.setStretchLastSection(True)
        header2.setSectionResizeMode(0, QHeaderView.ResizeToContents)  # Computer
        header2.setSectionResizeMode(1, QHeaderView.ResizeToContents)  # IP
        header2.setSectionResizeMode(2, QHeaderView.ResizeToContents)  # Type
        header2.setSectionResizeMode(3, QHeaderView.ResizeToContents)  # Rates
        header2.setSectionResizeMode(4, QHeaderView.ResizeToContents)  # Status
        
        configs_layout.addWidget(self.simulator_configs_table)
        splitter.addWidget(configs_group)
        
        layout.addWidget(splitter)
        
        # Load initial data
        self.refresh_simulators()
        
        return widget
    
    def refresh_simulators(self):
        """Refresh simulator data"""
        try:
            print("🔄 DEBUG: Starting refresh_simulators()")
            from database import NetCafeDatabase
            db = NetCafeDatabase()
            
            # Load simulator types
            print("🔄 DEBUG: Loading simulator types...")
            types = db.get_simulator_types()
            print(f"🔄 DEBUG: Found {len(types)} simulator types")
            
            if not types:
                print("❌ DEBUG: No simulator types found!")
                return
                
            self.simulator_types_table.setRowCount(len(types))
            
            for row, type_data in enumerate(types):
                print(f"🔄 DEBUG: Processing type {row}: {type_data['display_name']}")
                
                # Icon
                icon_item = QTableWidgetItem(type_data['icon'])
                icon_item.setTextAlignment(Qt.AlignCenter)
                self.simulator_types_table.setItem(row, 0, icon_item)
                
                # Type name
                self.simulator_types_table.setItem(row, 1, QTableWidgetItem(type_data['display_name']))
                
                # XP per minute
                xp_item = QTableWidgetItem(str(type_data['xp_per_minute']))
                xp_item.setTextAlignment(Qt.AlignCenter)
                self.simulator_types_table.setItem(row, 2, xp_item)
                
                # Tokens per minute
                tokens_item = QTableWidgetItem(str(type_data['tokens_per_minute']))
                tokens_item.setTextAlignment(Qt.AlignCenter)
                self.simulator_types_table.setItem(row, 3, tokens_item)
                
                # Color indicator
                color_item = QTableWidgetItem("●")
                color_item.setForeground(QColor(type_data['color']))
                color_item.setTextAlignment(Qt.AlignCenter)
                self.simulator_types_table.setItem(row, 4, color_item)
                
                # Description
                self.simulator_types_table.setItem(row, 5, QTableWidgetItem(type_data['description']))
                
                # Actions (Edit button)
                edit_btn = QPushButton("✏️ Edit")
                edit_btn.setStyleSheet('''
                    QPushButton {
                        background: rgba(0, 161, 156, 0.8);
                        color: white;
                        border: none;
                        border-radius: 4px;
                        padding: 4px 8px;
                    }
                    QPushButton:hover {
                        background: rgba(0, 161, 156, 1.0);
                    }
                ''')
                self.simulator_types_table.setCellWidget(row, 6, edit_btn)
            
            # Load simulator configs
            print("🔄 DEBUG: Loading simulator configs...")
            configs = db.get_simulator_configs()
            print(f"🔄 DEBUG: Found {len(configs)} simulator configs")
            self.simulator_configs_table.setRowCount(len(configs))
            
            for row, config in enumerate(configs):
                # Computer
                computer_name = config['computer_name'] or config['computer_id']
                self.simulator_configs_table.setItem(row, 0, QTableWidgetItem(computer_name))
                
                # IP Address
                ip = config['ip_address'] or 'Unknown'
                self.simulator_configs_table.setItem(row, 1, QTableWidgetItem(ip))
                
                # Type with icon
                type_text = f"{config['icon']} {config['type_display_name']}"
                type_item = QTableWidgetItem(type_text)
                type_item.setForeground(QColor(config['color']))
                self.simulator_configs_table.setItem(row, 2, type_item)
                
                # Rates
                rates_text = f"{config['xp_per_minute']} XP / {config['tokens_per_minute']} Tokens"
                self.simulator_configs_table.setItem(row, 3, QTableWidgetItem(rates_text))
                
                # Status
                status = config['computer_status'] or 'offline'
                status_item = QTableWidgetItem(status.upper())
                if status == 'online':
                    status_item.setForeground(QColor('#4CAF50'))
                else:
                    status_item.setForeground(QColor('#F44336'))
                self.simulator_configs_table.setItem(row, 4, status_item)
                
                # Last updated
                updated = config['last_updated'] or 'Never'
                self.simulator_configs_table.setItem(row, 5, QTableWidgetItem(updated))
            
            # Load computers for combo box
            print("🔄 DEBUG: Loading computers for combo box...")
            computers = db.get_active_computers()
            print(f"🔄 DEBUG: Found {len(computers)} active computers")
            
            self.computer_combo.clear()
            for i, computer in enumerate(computers):
                # computer is tuple: (computer_id, name, ip_address, status, last_seen)
                computer_id = computer[0]
                name = computer[1] or computer[0]  # Use computer_id if no name
                display_name = f"🖥️ {name}"
                print(f"🔄 DEBUG: Adding computer {i}: {display_name} (ID: {computer_id})")
                self.computer_combo.addItem(display_name, computer_id)
            
            print(f"🔄 DEBUG: Computer combo now has {self.computer_combo.count()} items")
            
            # Load types for combo box
            print("🔄 DEBUG: Loading types for combo box...")
            self.type_combo.clear()
            for i, type_data in enumerate(types):
                display_text = f"{type_data['icon']} {type_data['display_name']} ({type_data['xp_per_minute']}XP/{type_data['tokens_per_minute']}T)"
                print(f"🔄 DEBUG: Adding type {i}: {display_text} (ID: {type_data['id']})")
                self.type_combo.addItem(display_text, type_data['id'])
            
            print(f"🔄 DEBUG: Type combo now has {self.type_combo.count()} items")
            print("✅ DEBUG: refresh_simulators() completed successfully")
            
        except Exception as e:
            print(f"❌ DEBUG: Error refreshing simulators: {e}")
            import traceback
            traceback.print_exc()
    
    def assign_simulator_type(self):
        """Assign simulator type to selected computer"""
        try:
            computer_id = self.computer_combo.currentData()
            type_id = self.type_combo.currentData()
            
            print(f"🔧 DEBUG: computer_id = {computer_id}, type_id = {type_id}")
            print(f"🔧 DEBUG: computer_combo has {self.computer_combo.count()} items")
            print(f"🔧 DEBUG: type_combo has {self.type_combo.count()} items")
            
            if not computer_id or not type_id:
                error_msg = f"Please select both computer and type!\nComputer: {computer_id}\nType: {type_id}"
                print(f"❌ DEBUG: {error_msg}")
                QMessageBox.warning(self, "Warning", error_msg)
                return
            
            from database import NetCafeDatabase
            db = NetCafeDatabase()
            
            print(f"🔧 DEBUG: Attempting to assign {computer_id} to type {type_id}")
            success = db.assign_simulator_type(computer_id, type_id)
            print(f"🔧 DEBUG: Assignment result = {success}")
            
            if success:
                QMessageBox.information(self, "Success", f"Simulator type assigned successfully!")
                self.refresh_simulators()
            else:
                QMessageBox.critical(self, "Error", "Failed to assign simulator type!")
                
        except Exception as e:
            error_msg = f"Error assigning simulator type: {e}"
            print(f"❌ DEBUG: {error_msg}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Error", error_msg)
    
    def closeEvent(self, event):
        """Handle window close"""
        if self.session:
            asyncio.create_task(self.session.close())
        event.accept()

def main():
    app = QApplication(sys.argv)
    
    # Set up async event loop
    loop = qasync.QEventLoop(app)
    asyncio.set_event_loop(loop)
    
    # Create and show main window
    window = SimRacingAcademyAdminGUI()
    window.show()
    
    # Start async updates using the loop instance
    loop.create_task(window.start_updates())
    
    # Run the application
    with loop:
        loop.run_forever()

if __name__ == '__main__':
    main()