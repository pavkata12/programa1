#!/usr/bin/env python3
"""
NetCafe Pro 2.0 - Main Server
"""

import asyncio
import logging
from server_api import NetCafeServer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('netcafe_main')

def main():
    """Main server entry point"""
    try:
        logger.info("Starting NetCafe Pro 2.0 Server on 0.0.0.0:8080")
        
        # Create server instance
        server = NetCafeServer()
        
        # Run server
        server.run(host='0.0.0.0', port=8080)
        
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}")

if __name__ == '__main__':
    main() 