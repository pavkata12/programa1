# 🏎️ Sim Racing Academy - Server

## 🚀 Quick Installation

### Windows - Automated Installer (RECOMMENDED)
```bash
1. Right-click "INSTALL_SERVER.bat" → "Run as administrator"
2. Follow the installation wizard
3. Server will be available at: http://your-ip:8080
4. Admin panel: http://your-ip:8080/admin
5. Done! 🎉
```

### Linux - Automated Installer (RECOMMENDED)
```bash
1. sudo ./install_server.sh
2. Follow the installation wizard
3. Server starts automatically as systemd service
4. Done! 🎉
```

### Manual Installation
```bash
1. Install Node.js 18+ (with NPM)
2. npm install
3. node server.js
4. Configure firewall for port 8080
```

## 📋 Quick Start

### First-Time Setup:
1. **Run installer as Administrator/Root**
2. **Test server:** Open http://localhost:8080/api/status
3. **Access admin panel:** http://localhost:8080/admin
4. **Change admin password:** Login with admin/admin123

### Daily Usage:
- **Start server:** `node server.js` or systemctl start (Linux)
- **Stop server:** Ctrl+C or systemctl stop (Linux)
- **View logs:** Check server.log file
- **Monitor:** Admin panel → Stats & Sessions

## 🔐 Default Admin Account
- **Username:** `admin`
- **Password:** `admin123`
- **⚠️ CHANGE IMMEDIATELY AFTER INSTALLATION!**

## 🌐 Server URLs
- **API Status:** `http://your-ip:8080/api/status`
- **Admin Panel:** `http://your-ip:8080/admin`
- **WebSocket:** `ws://your-ip:8080/ws`
- **Health Check:** `http://your-ip:8080/api/health`

## 📁 Files Overview:
- `INSTALL_SERVER.bat` - **Windows automated installer**
- `install_server.sh` - **Linux automated installer**
- `server.js` - Main server application
- `database.py` - Database operations
- `server_api.py` - API endpoints
- `package.json` - Node.js dependencies
- `SERVER_INSTALLATION_GUIDE.md` - Detailed setup guide

## 🔧 Configuration:

### Database:
- **Type:** SQLite3
- **File:** `netcafe.db`
- **Auto-created** on first run

### Network:
- **Port:** 8080 (configurable in server.js)
- **Protocol:** HTTP + WebSocket
- **CORS:** Enabled for all origins

### Security:
- **JWT Authentication** for API access
- **Admin role** for management functions
- **Session management** with timeouts

## ⚠️ System Requirements:
- **OS:** Windows 10/11 or Linux Ubuntu 20.04+
- **Node.js:** 18.0+ with NPM
- **RAM:** Minimum 4GB
- **Storage:** 1GB free space
- **Network:** Static IP recommended

## 🧪 Testing:

### Test server startup:
```bash
node server.js
# Should show: "✅ Server running on port 8080"
```

### Test API endpoints:
```bash
curl http://localhost:8080/api/status
# Should return: {"success": true, "status": "running"}
```

### Test admin login:
```bash
curl -X POST http://localhost:8080/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123","computer_id":"test"}'
```

## 🔄 Service Management

### Windows (Task Scheduler):
- **Start:** Task Scheduler → "Sim Racing Academy Server" → Run
- **Stop:** Task Manager → End "node.exe" process
- **Auto-start:** Configured during installation

### Linux (Systemd):
```bash
# Start server:
sudo systemctl start simracing-academy

# Stop server:
sudo systemctl stop simracing-academy

# Restart server:
sudo systemctl restart simracing-academy

# Check status:
sudo systemctl status simracing-academy

# View logs:
sudo journalctl -u simracing-academy -f
```

## 📊 Monitoring & Logs

### Log Files:
- **Server logs:** `server.log`
- **Database logs:** Built into server.log
- **System logs:** Windows Event Viewer / journalctl (Linux)

### Admin Panel Monitoring:
- **Active Sessions** - Real-time session tracking
- **User Management** - Add/edit users and time
- **Statistics** - Revenue, usage stats
- **Computer Status** - Online/offline clients

### Performance Metrics:
- **Memory usage:** Check with Task Manager / top
- **Database size:** Check netcafe.db file size
- **Network connections:** netstat -an | grep 8080

## 📞 Troubleshooting

### Common Issues:

**Port 8080 already in use:**
```bash
# Windows: netstat -ano | findstr 8080
# Linux: lsof -i :8080
# Kill the process or change port in server.js
```

**Database locked error:**
```bash
# Stop all node processes
# Restart server
# Check for zombie processes
```

**Cannot connect from clients:**
```bash
# Check firewall settings
# Verify server IP address
# Test with curl from client machine
```

**Admin login fails:**
```bash
# Check database for admin user:
# sqlite3 netcafe.db "SELECT * FROM users WHERE is_admin = 1;"
# Reset admin password if needed
```

## 🔐 Security Best Practices

### Production Deployment:
1. **Change admin password** immediately
2. **Set JWT secret** environment variable
3. **Configure firewall** properly
4. **Enable HTTPS** with reverse proxy
5. **Regular backups** of database
6. **Monitor logs** for suspicious activity

### Network Security:
- Use **VPN** for remote administration
- **Whitelist** client IP addresses if possible
- **Monitor** unusual connection patterns
- **Update** Node.js and dependencies regularly

## 📈 Scaling & Performance

### For High Load:
- **Database:** Consider PostgreSQL for 100+ concurrent users
- **Caching:** Add Redis for session storage
- **Load Balancer:** nginx for multiple server instances
- **Monitoring:** Add Prometheus + Grafana

### Backup Strategy:
```bash
# Daily backup:
cp netcafe.db "backups/netcafe_$(date +%Y%m%d).db"

# Weekly cleanup:
find backups/ -name "*.db" -mtime +30 -delete
```

---

## 🎉 Ready to Go!

Your Sim Racing Academy server is now ready to handle client connections!

**Next Steps:**
1. Configure client machines with your server IP
2. Create user accounts via admin panel
3. Start gaming sessions! 🏎️

**Happy Gaming! 🚀**
