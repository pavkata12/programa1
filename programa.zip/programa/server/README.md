# 🖥️ Sim Racing Academy - Server

## 🚀 Quick Start

### Автоматична Инсталация (ПРЕПОРЪЧИТЕЛНО):
```bash
# Windows (като Administrator):
INSTALL_SERVER.bat

# Linux:
sudo ./install_server.sh
```

### Ръчно Стартиране:
```bash
# Инсталиране на dependencies:
pip install -r requirements.txt

# Стартиране на сървъра:
python server.py
```

## 📋 Файлове

- **`server.py`** - Главен сървър (HTTP + WebSocket API)
- **`database.py`** - Database управление (SQLite)
- **`server_api.py`** - API endpoints и бизнес логика
- **`admin_gui.py`** - Desktop admin interface
- **`production_bridge.py`** - Bridge към NetCafe система
- **`INSTALL_SERVER.bat`** - Автоматичен инсталатор
- **`SERVER_INSTALLATION_GUIDE.md`** - Детайлно ръководство

## 🌐 Достъп

След стартиране сървърът е достъпен на:
- **Admin Panel:** `http://localhost:8080/admin`
- **API Status:** `http://localhost:8080/api/status`
- **WebSocket:** `ws://localhost:8080/ws`

## 🔐 Default Login

```
Username: admin
Password: admin123
```

**⚠️ СМЕНЕТЕ ПАРОЛАТА ВЕДНАГА СЛЕД ИНСТАЛАЦИЯТА!**

## 🔧 Конфигуриране на Clients

В `client/config.json` на всяка client машина:
```json
{
    "server": {
        "host": "192.168.1.100",  // IP на сървъра
        "port": 8080
    }
}
```

## 📊 Мониторинг

- **Логове:** `server.log`, `production_bridge.log`
- **Database:** `netcafe.db` (SQLite)
- **Admin GUI:** `python admin_gui.py`

## ⚠️ Изисквания

- **Python 3.8+**
- **Windows 10/11** или **Linux**
- **Administrator права**
- **Port 8080 свободен**

## 🛠️ Troubleshooting

### Сървърът не стартира:
```bash
# Проверете дали port 8080 е свободен:
netstat -ano | findstr :8080    # Windows
lsof -i :8080                   # Linux
```

### Database грешки:
```bash
# Тест на database:
python -c "from database import NetCafeDatabase; db = NetCafeDatabase(); print('OK')"
```

### Connection проблеми:
- Проверете firewall настройките
- Проверете IP адреса на сървъра
- Тествайте с `curl http://SERVER_IP:8080/api/status`

За детайлно ръководство вижте: **`SERVER_INSTALLATION_GUIDE.md`**
