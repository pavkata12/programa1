#!/bin/bash

# Sim Racing Academy - Server Installer (Linux)
# Run with: sudo ./install_server.sh

set -e  # Exit on any error

echo "=========================================="
echo "🏎️  Sim Racing Academy - Server Installer"
echo "=========================================="
echo

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ This installer requires root privileges!"
    echo
    echo "🛡️  This installer needs root privileges to:"
    echo "   • Install system packages"
    echo "   • Configure firewall rules"
    echo "   • Set up system services"
    echo
    echo "Please run: sudo ./install_server.sh"
    exit 1
fi

echo "✅ Root privileges detected"
echo

echo "🔍 Checking system requirements..."

# Detect Linux distribution
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
    VER=$VERSION_ID
    echo "✅ Operating System: $OS $VER"
else
    echo "❌ Cannot detect Linux distribution"
    exit 1
fi

# Check Python installation
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
    echo "✅ Python is installed: $PYTHON_VERSION"
    
    # Check if pip is available
    if command -v pip3 &> /dev/null; then
        echo "✅ pip3 is available"
    else
        echo "⚠️  pip3 not found, installing..."
        
        # Install pip based on distribution
        if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
            apt update
            apt install -y python3-pip python3-venv
        elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
            yum install -y python3-pip
        elif [[ "$OS" == *"Fedora"* ]]; then
            dnf install -y python3-pip
        else
            echo "❌ Unsupported Linux distribution for automatic pip installation"
            echo "Please install python3-pip manually and run this script again"
            exit 1
        fi
        
        echo "✅ pip3 installed successfully"
    fi
else
    echo "❌ Python 3 is NOT installed!"
    echo
    echo "📥 Installing Python 3..."
    
    # Install Python based on distribution
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        apt update
        apt install -y python3 python3-pip python3-venv
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        yum install -y python3 python3-pip
    elif [[ "$OS" == *"Fedora"* ]]; then
        dnf install -y python3 python3-pip
    else
        echo "❌ Unsupported Linux distribution"
        echo "Please install Python 3.8+ manually and run this script again"
        exit 1
    fi
    
    echo "✅ Python 3 installed successfully"
fi

echo

echo "📦 Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate
echo "✅ Virtual environment created and activated"

echo

echo "📦 Installing Python dependencies..."
echo "🔄 Upgrading pip first..."
pip install --upgrade pip

echo "📦 Installing server dependencies..."

# Try minimal installation first (core server functionality)
echo "🔧 Installing core server components..."
pip install -r requirements-minimal.txt

if [ $? -eq 0 ]; then
    echo "✅ Core server dependencies installed successfully"
    
    # Ask if user wants GUI components
    read -p "Install Admin GUI components (PySide6, qasync)? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "📦 Installing Admin GUI dependencies..."
        pip install -r requirements-gui.txt
        
        if [ $? -eq 0 ]; then
            echo "✅ Admin GUI dependencies installed successfully"
            echo "ℹ️  You can now run: python admin_gui.py"
        else
            echo "⚠️  Failed to install GUI dependencies, but core server will work"
            echo "ℹ️  Admin GUI (admin_gui.py) will not be available"
        fi
    else
        echo "ℹ️  Skipping Admin GUI installation"
        echo "ℹ️  Admin GUI (admin_gui.py) will not be available"
    fi
    
    echo "✅ Server installation completed successfully"
    
else
    echo "❌ Failed to install core dependencies"
    echo "🔄 Trying direct installation..."
    pip install "aiohttp>=3.8.0" "aiohttp-cors>=0.7.0" "PyJWT>=2.8.0"
    
    if [ $? -eq 0 ]; then
        echo "✅ Core dependencies installed via direct method"
    else
        echo "❌ Failed to install dependencies"
        echo "Please check your internet connection and Python installation"
        exit 1
    fi
fi

echo

echo "🗄️  Initializing database..."
python -c "from database import NetCafeDatabase; db = NetCafeDatabase(); print('✅ Database initialized')" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✅ Database created successfully"
    echo "✅ Default admin user: admin/admin123"
else
    echo "❌ Database initialization failed"
    echo "🔄 Trying alternative method..."
    python -c "import database; print('Database module loaded')" >/dev/null 2>&1
    
    if [ $? -eq 0 ]; then
        echo "✅ Database initialized successfully"
    else
        echo "❌ Database initialization failed"
        echo "Please check database.py file"
        exit 1
    fi
fi

echo

echo "🌐 Getting server IP address..."
SERVER_IP=$(hostname -I | awk '{print $1}')
echo "✅ Server IP detected: $SERVER_IP"

echo

echo "🔥 Configuring firewall..."

# Configure firewall based on system
if command -v ufw &> /dev/null; then
    # Ubuntu/Debian with ufw
    ufw allow 8080/tcp >/dev/null 2>&1
    echo "✅ UFW firewall rule added for port 8080"
elif command -v firewall-cmd &> /dev/null; then
    # CentOS/RHEL/Fedora with firewalld
    firewall-cmd --permanent --add-port=8080/tcp >/dev/null 2>&1
    firewall-cmd --reload >/dev/null 2>&1
    echo "✅ Firewalld rule added for port 8080"
elif command -v iptables &> /dev/null; then
    # Generic iptables
    iptables -A INPUT -p tcp --dport 8080 -j ACCEPT >/dev/null 2>&1
    echo "✅ iptables rule added for port 8080"
else
    echo "⚠️  Could not configure firewall automatically"
    echo "📝 Please allow port 8080 manually in your firewall"
fi

echo

echo "🧪 Testing server startup..."
echo "Starting server test (will run for 10 seconds)..."
timeout 10s python server.py &
SERVER_PID=$!
sleep 5

# Test if server is responding
if curl -s http://localhost:8080/api/status >/dev/null 2>&1; then
    echo "✅ Server startup test successful"
else
    echo "⚠️  Server test inconclusive"
    echo "🔧 Please test manually: python server.py"
fi

# Stop test server
kill $SERVER_PID >/dev/null 2>&1

echo

echo "🔄 Setting up auto-start service..."
read -p "Setup server to start automatically with system boot? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo
    echo "📝 Creating systemd service..."
    
    # Get current directory
    CURRENT_DIR=$(pwd)
    
    # Create systemd service file
    cat > /etc/systemd/system/simracing-server.service << EOF
[Unit]
Description=Sim Racing Academy Server
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=$CURRENT_DIR
Environment=PATH=$CURRENT_DIR/venv/bin
ExecStart=$CURRENT_DIR/venv/bin/python server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    # Create www-data user if it doesn't exist
    if ! id "www-data" &>/dev/null; then
        useradd -r -s /bin/false www-data
    fi
    
    # Set proper permissions
    chown -R www-data:www-data $CURRENT_DIR
    
    # Enable and start service
    systemctl daemon-reload
    systemctl enable simracing-server
    
    echo "✅ Auto-start service created"
    echo "ℹ️  Server will start automatically on boot"
    echo "🔧 Service commands:"
    echo "   Start:   systemctl start simracing-server"
    echo "   Stop:    systemctl stop simracing-server"
    echo "   Status:  systemctl status simracing-server"
    echo "   Logs:    journalctl -u simracing-server -f"
else
    echo "ℹ️  Auto-start skipped"
fi

echo

echo "🎉 SERVER INSTALLATION COMPLETE!"
echo "========================================"
echo
echo "📋 Server Information:"
echo "   Server IP: $SERVER_IP"
echo "   Server Port: 8080"
echo "   Server URL: http://$SERVER_IP:8080"
echo "   Admin Panel: http://$SERVER_IP:8080/admin"
echo "   API Status: http://$SERVER_IP:8080/api/status"
echo
echo "🔐 Default Admin Account:"
echo "   Username: admin"
echo "   Password: admin123"
echo "   ⚠️  CHANGE THIS PASSWORD IMMEDIATELY!"
echo
echo "📋 Next Steps:"
echo "1. Test the server: python server.py"
echo "2. Open admin panel in browser"
echo "3. Change admin password"
echo "4. Configure client machines with server IP: $SERVER_IP"
echo

# Ask to start server now
read -p "Start the server now? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo
    echo "🚀 Starting Sim Racing Academy Server..."
    echo
    echo "🌐 Server will be available at:"
    echo "   http://$SERVER_IP:8080"
    echo "   http://localhost:8080"
    echo
    echo "📱 Press Ctrl+C to stop the server"
    echo "=========================================="
    echo
    
    # Activate virtual environment and start server
    source venv/bin/activate
    python server.py
else
    echo
    echo "👋 Installation completed successfully!"
    echo
    echo "🔧 To start the server manually:"
    echo "   cd $(pwd)"
    echo "   source venv/bin/activate"
    echo "   python server.py"
    echo
    echo "📊 To view logs: tail -f server.log"
    echo "🌐 Admin panel: http://$SERVER_IP:8080/admin"
    echo
    echo "📞 Support: Check server.log for any issues"
    echo
fi
