#!/bin/bash

# Sim Racing Academy - Server Installer for Linux
# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}"
echo "=========================================="
echo "  🏎️ Sim Racing Academy - Server Installer"
echo "=========================================="
echo -e "${NC}"

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo -e "${GREEN}✅ Root privileges detected${NC}"
else
   echo -e "${RED}❌ Root privileges required!${NC}"
   echo ""
   echo -e "${YELLOW}🛡️  This installer requires root privileges to:${NC}"
   echo "   • Install system packages"
   echo "   • Configure firewall rules"
   echo "   • Set up system services"
   echo "   • Create directories with proper permissions"
   echo ""
   echo -e "${CYAN}Please run with sudo: sudo ./install_server.sh${NC}"
   exit 1
fi

echo ""
echo -e "${BLUE}🔍 Checking system requirements...${NC}"

# Check if Node.js is installed
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    NPM_VERSION=$(npm --version)
    echo -e "${GREEN}✅ Node.js is installed: $NODE_VERSION${NC}"
    echo -e "${GREEN}✅ NPM is installed: $NPM_VERSION${NC}"
    
    # Check if version is 18+
    NODE_MAJOR=$(node --version | cut -d'.' -f1 | sed 's/v//')
    if [ "$NODE_MAJOR" -lt 18 ]; then
        echo -e "${YELLOW}⚠️  Node.js version is too old (need 18+)${NC}"
        echo -e "${CYAN}Installing newer version...${NC}"
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt-get install -y nodejs
    fi
else
    echo -e "${RED}❌ Node.js is NOT installed!${NC}"
    echo ""
    echo -e "${CYAN}📥 Installing Node.js 20.x...${NC}"
    
    # Update package list
    apt update
    
    # Install Node.js 20.x
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    apt-get install -y nodejs
    
    if command -v node &> /dev/null; then
        echo -e "${GREEN}✅ Node.js installed successfully: $(node --version)${NC}"
    else
        echo -e "${RED}❌ Failed to install Node.js${NC}"
        exit 1
    fi
fi

# Install additional system dependencies
echo ""
echo -e "${BLUE}📦 Installing system dependencies...${NC}"
apt update
apt install -y sqlite3 curl wget ufw

echo ""
echo -e "${BLUE}📁 Setting up server directory...${NC}"

# Create server directory
SERVER_DIR="/opt/simracing-academy/server"
mkdir -p "$SERVER_DIR"

# Copy files to server directory if not already there
if [ "$(pwd)" != "$SERVER_DIR" ]; then
    echo -e "${CYAN}📋 Copying server files to $SERVER_DIR...${NC}"
    cp -r . "$SERVER_DIR/"
    cd "$SERVER_DIR"
fi

# Set proper ownership
chown -R $SUDO_USER:$SUDO_USER "$SERVER_DIR"

echo ""
echo -e "${BLUE}📦 Installing Node.js dependencies...${NC}"
sudo -u $SUDO_USER npm install

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Dependencies installed successfully${NC}"
else
    echo -e "${RED}❌ Failed to install dependencies${NC}"
    echo -e "${CYAN}🔄 Trying to fix package-lock.json...${NC}"
    rm -f package-lock.json
    sudo -u $SUDO_USER npm install
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Dependencies installed successfully (after cleanup)${NC}"
    else
        echo -e "${RED}❌ Failed to install dependencies${NC}"
        echo "Please check your internet connection and try again"
        exit 1
    fi
fi

echo ""
echo -e "${BLUE}🗄️  Initializing database...${NC}"
sudo -u $SUDO_USER node -e "const db = require('./database'); console.log('✅ Database initialized');" 2>/dev/null

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Database created successfully${NC}"
    echo -e "${GREEN}✅ Default admin user: admin/admin123${NC}"
else
    echo -e "${RED}❌ Database initialization failed${NC}"
    echo -e "${CYAN}🔄 Trying alternative method...${NC}"
    sudo -u $SUDO_USER node -p "require('./database.js')" >/dev/null 2>&1
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Database initialized successfully${NC}"
    else
        echo -e "${RED}❌ Database initialization failed${NC}"
        echo "Please check database.js file"
        exit 1
    fi
fi

echo ""
echo -e "${BLUE}🌐 Getting server IP address...${NC}"
SERVER_IP=$(ip route get 8.8.8.8 | awk -F"src " 'NR==1{split($2,a," ");print a[1]}')
if [ -z "$SERVER_IP" ]; then
    SERVER_IP=$(hostname -I | awk '{print $1}')
fi
echo -e "${GREEN}✅ Server IP detected: $SERVER_IP${NC}"

echo ""
echo -e "${BLUE}🔥 Configuring UFW firewall...${NC}"
ufw --force enable
ufw allow 8080/tcp
ufw allow ssh

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Firewall configured for port 8080${NC}"
else
    echo -e "${YELLOW}⚠️  Could not configure firewall automatically${NC}"
    echo "📝 Please configure manually: sudo ufw allow 8080/tcp"
fi

echo ""
echo -e "${BLUE}🧪 Testing server startup...${NC}"
echo "Starting server test (will run for 10 seconds)..."

# Start server in background
sudo -u $SUDO_USER node server.js &
SERVER_PID=$!
sleep 5

# Test if server is responding
curl -s http://localhost:8080/api/status >/dev/null 2>&1
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Server startup test successful${NC}"
else
    echo -e "${YELLOW}⚠️  Server test inconclusive${NC}"
    echo -e "${CYAN}🔧 Please test manually: node server.js${NC}"
fi

# Stop test server
kill $SERVER_PID 2>/dev/null
sleep 2

echo ""
echo -e "${BLUE}🔄 Setting up systemd service...${NC}"
read -p "Setup server to start automatically with system? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo -e "${CYAN}📝 Creating systemd service...${NC}"
    
    # Create systemd service file
    cat > /etc/systemd/system/simracing-academy.service << EOF
[Unit]
Description=Sim Racing Academy Server
After=network.target

[Service]
Type=simple
User=$SUDO_USER
WorkingDirectory=$SERVER_DIR
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

    # Enable and start service
    systemctl daemon-reload
    systemctl enable simracing-academy
    
    echo -e "${GREEN}✅ Auto-start service created${NC}"
    echo -e "${CYAN}ℹ️  Server will start automatically on boot${NC}"
    echo -e "${CYAN}ℹ️  Control with: sudo systemctl start/stop/restart simracing-academy${NC}"
else
    echo -e "${CYAN}ℹ️  Auto-start skipped${NC}"
fi

echo ""
echo -e "${GREEN}🎉 SERVER INSTALLATION COMPLETE!${NC}"
echo "========================================"
echo ""
echo -e "${CYAN}📋 Server Information:${NC}"
echo "   Server IP: $SERVER_IP"
echo "   Server Port: 8080"
echo "   Server URL: http://$SERVER_IP:8080"
echo "   Admin Panel: http://$SERVER_IP:8080/admin"
echo "   API Status: http://$SERVER_IP:8080/api/status"
echo ""
echo -e "${YELLOW}🔐 Default Admin Account:${NC}"
echo "   Username: admin"
echo "   Password: admin123"
echo -e "${RED}   ⚠️  CHANGE THIS PASSWORD IMMEDIATELY!${NC}"
echo ""
echo -e "${CYAN}📋 Next Steps:${NC}"
echo "1. Test the server: sudo systemctl start simracing-academy"
echo "2. Check status: sudo systemctl status simracing-academy"
echo "3. View logs: sudo journalctl -u simracing-academy -f"
echo "4. Open admin panel in browser"
echo "5. Change admin password"
echo "6. Configure client machines with server IP: $SERVER_IP"
echo ""

# Ask to start server now
read -p "Start the server now? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo -e "${CYAN}🚀 Starting Sim Racing Academy Server...${NC}"
    echo ""
    echo -e "${CYAN}🌐 Server will be available at:${NC}"
    echo "   http://$SERVER_IP:8080"
    echo "   http://localhost:8080"
    echo ""
    echo -e "${CYAN}📱 Press Ctrl+C to stop the server${NC}"
    echo "========================================"
    echo ""
    
    # Change to server user and start
    cd "$SERVER_DIR"
    sudo -u $SUDO_USER node server.js
else
    echo ""
    echo -e "${GREEN}👋 Installation completed successfully!${NC}"
    echo ""
    echo -e "${CYAN}🔧 To start the server: sudo systemctl start simracing-academy${NC}"
    echo -e "${CYAN}📊 To view logs: sudo journalctl -u simracing-academy -f${NC}"
    echo -e "${CYAN}🌐 Admin panel: http://$SERVER_IP:8080/admin${NC}"
    echo ""
    echo -e "${CYAN}📞 Support: Check server logs for any issues${NC}"
    echo ""
fi
