# 🌐 Production Bridge - Usage Guide

## 🎯 **What Changed**

Production Bridge now runs with **visible console window** instead of hidden process. This makes it easier to monitor sync activity and debug issues.

## 🚀 **How to Use**

### **Method 1: Admin Panel (Recommended)**
1. Open Admin Panel: `python admin_gui.py`
2. Go to "🌐 Production Bridge" tab
3. Click "▶️ Start Bridge"
4. New console window will open showing sync activity
5. Monitor status in Admin Panel

### **Method 2: Manual Start**
```bash
cd server
python production_bridge.py
```

## 📊 **What You'll See**

### **Console Window Output:**
```
2025-07-14 22:45:07,920 - INFO - Starting Production Bridge...
2025-07-14 22:45:07,920 - INFO - Connection to website established
2025-07-14 22:45:07,920 - INFO - Website status: Sim Racing Academy API is running
2025-07-14 22:45:07,924 - INFO - Users synced: 1
2025-07-14 22:45:07,924 - INFO - Sessions synced: 1 entries
2025-07-14 22:45:07,924 - INFO - Leaderboard synced: 1 entries
2025-07-14 22:45:07,924 - INFO - All data synced successfully
```

### **Admin Panel Shows:**
- **Status**: 🟢 Running
- **Last Sync**: 2025-07-14 22:45:07
- **Users Synced**: 1
- **Sessions Synced**: 1
- **Leaderboard Synced**: 1

## 💡 **Benefits**

✅ **Real-time Monitoring**: See sync activity as it happens  
✅ **Easy Debugging**: Console shows errors and warnings  
✅ **Status Tracking**: Admin panel shows comprehensive stats  
✅ **Quick Control**: Start/Stop from Admin Panel  
✅ **Process Management**: Proper process handling  

## 🔧 **Controls**

- **▶️ Start Bridge**: Starts with visible console window
- **⏹️ Stop Bridge**: Closes console window and stops sync
- **🔄 Refresh Status**: Updates status and statistics
- **🗑️ Clear Logs**: Clears bridge log file

## 🚨 **Important Notes**

1. **Console Window**: Don't close the console window manually - use Admin Panel
2. **Multiple Instances**: Admin Panel prevents multiple bridge instances
3. **Sync Interval**: Bridge syncs every 30 seconds automatically
4. **Log Files**: All activity is logged to `production_bridge.log`

## 📱 **Status Bar Indicator**

Bottom of Admin Panel shows:
- **🟢 Bridge: On** - Running and syncing
- **🔴 Bridge: Off** - Not running
- **🟡 Bridge: Starting...** - Starting up

## 🛠️ **Configuration**

Edit `production_bridge.py` to change:
```python
WEBSITE_API_URL = "https://simracingacademy.eu/api"
API_KEY = "netcafe-bridge-2024-secure-key"
SYNC_INTERVAL = 30  # seconds
```

## 📞 **Support**

If you have issues:
1. Check console window for errors
2. Review `production_bridge.log` file
3. Verify internet connection
4. Check website URL and API key

---

**🌐 Production Bridge - Now with visible sync monitoring!** 