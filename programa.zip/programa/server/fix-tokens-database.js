#!/usr/bin/env node

/**
 * DATABASE TOKEN CLEANUP & RECALCULATION SCRIPT
 * 
 * Този скрипт:
 * 1. Backup-ва текущата база данни
 * 2. Почиства дублираните/грешните токени
 * 3. Recalculate-ва всички токени и XP с новата унифицирана логика
 * 4. Проверява резултатите
 */

const sqlite3 = require('sqlite3').verbose()
const path = require('path')
const fs = require('fs')
const { TOKEN_CONFIG, calculateTokensAndXP, getTierByXP } = require('./token-config.js')

const DB_PATH = path.join(__dirname, 'netcafe.db')
const BACKUP_PATH = path.join(__dirname, `netcafe_backup_${Date.now()}.db`)

console.log('🔧 Starting Database Token Cleanup & Recalculation...')
console.log('=' .repeat(60))

async function main() {
  try {
    // Step 1: Create backup
    console.log('📦 Creating database backup...')
    await createBackup()
    
    // Step 2: Analyze current state
    console.log('\n📊 Analyzing current database state...')
    await analyzeCurrentState()
    
    // Step 3: Clean and recalculate
    console.log('\n🧹 Cleaning and recalculating tokens...')
    await cleanAndRecalculate()
    
    // Step 4: Verify results
    console.log('\n✅ Verifying results...')
    await verifyResults()
    
    console.log('\n🎉 Database cleanup completed successfully!')
    console.log(`📦 Backup saved at: ${BACKUP_PATH}`)
    
  } catch (error) {
    console.error('❌ Error during cleanup:', error)
    console.log('\n🔄 Restoring from backup...')
    await restoreBackup()
  }
}

async function createBackup() {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(DB_PATH)) {
      console.log('⚠️  Database file not found, skipping backup')
      return resolve()
    }
    
    fs.copyFile(DB_PATH, BACKUP_PATH, (err) => {
      if (err) {
        reject(err)
      } else {
        console.log(`✅ Backup created: ${BACKUP_PATH}`)
        resolve()
      }
    })
  })
}

async function analyzeCurrentState() {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(DB_PATH)
    
    db.serialize(() => {
      // Count total users
      db.get('SELECT COUNT(*) as count FROM users', (err, result) => {
        if (err) return reject(err)
        console.log(`👥 Total users: ${result.count}`)
      })
      
      // Count users with tokens
      db.get('SELECT COUNT(*) as count FROM user_tokens', (err, result) => {
        if (err) return reject(err)
        console.log(`💰 Users with tokens: ${result.count}`)
      })
      
      // Sum total tokens
      db.get('SELECT SUM(tokens) as total, SUM(total_earned) as earned FROM user_tokens', (err, result) => {
        if (err) return reject(err)
        console.log(`🪙 Total tokens in system: ${result.total || 0}`)
        console.log(`📈 Total tokens earned: ${result.earned || 0}`)
      })
      
      // Check for inconsistencies
      db.all(`
        SELECT u.username, u.minutes, ut.tokens, ut.xp, ut.minutes_played
        FROM users u 
        LEFT JOIN user_tokens ut ON u.id = ut.user_id
        WHERE ut.tokens IS NOT NULL
        ORDER BY ut.tokens DESC
        LIMIT 10
      `, (err, rows) => {
        if (err) return reject(err)
        
        console.log('\n🔍 Top 10 users by tokens:')
        console.log('Username'.padEnd(15), 'Minutes'.padEnd(10), 'Tokens'.padEnd(10), 'XP'.padEnd(10), 'MinPlayed'.padEnd(10))
        console.log('-'.repeat(60))
        
        rows.forEach(row => {
          console.log(
            (row.username || 'N/A').padEnd(15),
            (row.minutes || 0).toString().padEnd(10),
            (row.tokens || 0).toString().padEnd(10),
            (row.xp || 0).toString().padEnd(10),
            (row.minutes_played || 0).toString().padEnd(10)
          )
        })
        
        resolve()
      })
    })
  })
}

async function cleanAndRecalculate() {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(DB_PATH)
    
    db.serialize(() => {
      console.log('🧹 Clearing existing token data...')
      
      // Clear all token data (but preserve manually added tokens if any)
      db.run('DELETE FROM token_transactions', (err) => {
        if (err && !err.message.includes('no such table')) {
          console.log('⚠️  No token_transactions table found, skipping')
        }
      })
      
      // Reset user_tokens but preserve structure
      db.run(`
        UPDATE user_tokens SET 
          tokens = 0, 
          total_earned = 0, 
          xp = 0, 
          minutes_played = 0,
          updated_at = CURRENT_TIMESTAMP
      `, (err) => {
        if (err) return reject(err)
        console.log('✅ Token data cleared')
        
        // Now recalculate for all users
        recalculateAllUsers(db, resolve, reject)
      })
    })
  })
}

function recalculateAllUsers(db, resolve, reject) {
  console.log('🔄 Recalculating tokens for all users...')
  
  // Get all users with their total gaming time
  db.all(`
    SELECT 
      u.id, u.username,
      COALESCE(SUM(s.duration_minutes), 0) as total_minutes_played
    FROM users u 
    LEFT JOIN sessions s ON u.id = s.user_id AND s.is_active = 0
    GROUP BY u.id, u.username
  `, (err, users) => {
    if (err) return reject(err)
    
    console.log(`🔄 Processing ${users.length} users...`)
    
    let processed = 0
    let totalTokensAwarded = 0
    let totalXPAwarded = 0
    
    users.forEach(user => {
      const totalMinutes = user.total_minutes_played || 0
      
      if (totalMinutes > 0) {
        // Calculate rewards using unified system
        const rewards = calculateTokensAndXP(totalMinutes, 0, 'BASIC') // Start with 0 XP for tier calculation
        
        // Insert or update user_tokens
        db.run(`
          INSERT OR REPLACE INTO user_tokens 
          (user_id, tokens, total_earned, xp, minutes_played, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `, [user.id, rewards.tokens, rewards.tokens, rewards.xp, totalMinutes], (err) => {
          if (err) {
            console.error(`❌ Error updating user ${user.username}:`, err)
          } else {
            console.log(`✅ ${user.username}: ${totalMinutes}min → ${rewards.tokens} tokens, ${rewards.xp} XP (tier: ${rewards.currentTier.name})`)
            totalTokensAwarded += rewards.tokens
            totalXPAwarded += rewards.xp
          }
          
          processed++
          if (processed === users.length) {
            console.log(`\n🎉 Recalculation complete!`)
            console.log(`📊 Total tokens awarded: ${totalTokensAwarded}`)
            console.log(`📊 Total XP awarded: ${totalXPAwarded}`)
            resolve()
          }
        })
      } else {
        // User with no gaming time
        console.log(`⚪ ${user.username}: No gaming time, skipping`)
        processed++
        if (processed === users.length) {
          console.log(`\n🎉 Recalculation complete!`)
          console.log(`📊 Total tokens awarded: ${totalTokensAwarded}`)
          console.log(`📊 Total XP awarded: ${totalXPAwarded}`)
          resolve()
        }
      }
    })
    
    if (users.length === 0) {
      console.log('⚪ No users found to process')
      resolve()
    }
  })
}

async function verifyResults() {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(DB_PATH)
    
    db.serialize(() => {
      // Check totals after cleanup
      db.get('SELECT SUM(tokens) as total, SUM(xp) as total_xp, COUNT(*) as users FROM user_tokens', (err, result) => {
        if (err) return reject(err)
        
        console.log(`✅ Verification Results:`)
        console.log(`   Users with tokens: ${result.users}`)
        console.log(`   Total tokens: ${result.total || 0}`)
        console.log(`   Total XP: ${result.total_xp || 0}`)
        
        // Show top users after cleanup
        db.all(`
          SELECT u.username, ut.tokens, ut.xp, ut.minutes_played
          FROM user_tokens ut
          JOIN users u ON ut.user_id = u.id
          WHERE ut.tokens > 0
          ORDER BY ut.tokens DESC
          LIMIT 5
        `, (err, rows) => {
          if (err) return reject(err)
          
          if (rows.length > 0) {
            console.log('\n🏆 Top 5 users after cleanup:')
            rows.forEach((row, i) => {
              const tier = getTierByXP(row.xp)
              console.log(`   ${i+1}. ${row.username}: ${row.tokens} tokens, ${row.xp} XP (${tier.name}), ${row.minutes_played}min`)
            })
          }
          
          resolve()
        })
      })
    })
  })
}

async function restoreBackup() {
  if (fs.existsSync(BACKUP_PATH)) {
    fs.copyFileSync(BACKUP_PATH, DB_PATH)
    console.log('✅ Database restored from backup')
  }
}

// Run the script
if (require.main === module) {
  main().then(() => {
    process.exit(0)
  }).catch(err => {
    console.error('❌ Script failed:', err)
    process.exit(1)
  })
}

module.exports = { main }
