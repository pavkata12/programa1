#!/usr/bin/env python3
"""
Simple API test for new PC setup
"""
import os
import asyncio
import aiohttp

async def test_api():
    """Test API connection"""
    print("🔍 Testing NetCafe API Connection...")
    print("-" * 40)
    
    # Get environment variables
    API_KEY = os.environ.get("EXTERNAL_API_KEY")
    HMAC_SECRET = os.environ.get("SYNC_HMAC_SECRET") 
    URL = os.environ.get("WEBSITE_API_URL", "https://simracingacademy.eu/api")
    
    print(f"🔑 API Key: {API_KEY[:20] + '...' if API_KEY else 'NOT SET'}")
    print(f"🔐 HMAC Secret: {'SET' if HMAC_SECRET else 'NOT SET'}")
    print(f"🌐 URL: {URL}")
    print("-" * 40)
    
    if not API_KEY:
        print("❌ EXTERNAL_API_KEY not set!")
        print("Run: setx EXTERNAL_API_KEY \"netcafe-bridge-2025-9f3b7e2a1c64f0d8\"")
        return False
        
    if not HMAC_SECRET:
        print("❌ SYNC_HMAC_SECRET not set!")
        print("Run: setx SYNC_HMAC_SECRET \"p6mA5Q517oV8rN2c4bQ2yVrJ6k1k8CwU2kB3ZQy0mH8vF1+eKspmOw==\"")
        return False
    
    try:
        # Test connection with SSL bypass
        connector = aiohttp.TCPConnector(ssl=False)
        timeout = aiohttp.ClientTimeout(total=10)
        
        async with aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers={'x-api-key': API_KEY}
        ) as session:
            
            print("🏥 Testing health endpoint...")
            async with session.get(f"{URL}/health") as resp:
                print(f"Status: {resp.status}")
                if resp.status == 200:
                    data = await resp.json()
                    print(f"✅ Health OK: {data.get('message', 'Unknown')}")
                else:
                    print(f"❌ Health failed: {resp.status}")
                    return False
            
            print("🔄 Testing sync endpoint...")
            test_data = {'users': [], 'timestamp': '2025-01-01T00:00:00'}
            async with session.post(f"{URL}/sync/users", json=test_data) as resp:
                print(f"Status: {resp.status}")
                if resp.status == 200:
                    data = await resp.json()
                    print(f"✅ Sync OK: {data.get('message', 'Unknown')}")
                    return True
                else:
                    print(f"❌ Sync failed: {resp.status}")
                    text = await resp.text()
                    print(f"Error: {text[:100]}")
                    return False
                    
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return False

if __name__ == "__main__":
    print("🚀 NetCafe API Test")
    print("=" * 40)
    success = asyncio.run(test_api())
    print("=" * 40)
    if success:
        print("✅ All tests passed! Production bridge should work.")
    else:
        print("❌ Tests failed. Check setup steps above.")
    print("\nPress Enter to exit...")
    input()
