/**
 * UNIFIED TOKEN & XP CONFIGURATION
 * 
 * Това е ЕДИНСТВЕНАТА истина за token/XP изчисления в цялата система.
 * Всички други файлове трябва да използват тези константи.
 * 
 * ВАЖНО: Не променяйте тези стойности без да обновите всички файлове!
 */

const TOKEN_CONFIG = {
  // Основни rates (2 tokens/XP per minute = 120 per hour)
  TOKENS_PER_MINUTE: 2,
  XP_PER_MINUTE: 2,
  
  // Bonus система
  BONUS_TOKENS_THRESHOLD: 60,  // Bonus на всеки час (60 минути)
  BONUS_TOKENS_AMOUNT: 50,     // 50 bonus tokens на час
  
  // Tier system базиран на XP (НЕ на tokens!)
  TIERS: {
    BEGINNER: { 
      name: 'Beginner', 
      xp: 0, 
      multiplier: 1.0,
      color: '#9CA3AF'
    },
    NOVICE: { 
      name: 'Novice', 
      xp: 600, 
      multiplier: 1.2,
      color: '#10B981'
    },
    INTERMEDIATE: { 
      name: 'Intermediate', 
      xp: 1800, 
      multiplier: 1.4,
      color: '#3B82F6'
    },
    PRO: { 
      name: 'Pro', 
      xp: 5400, 
      multiplier: 1.6,
      color: '#8B5CF6'
    },
    ELITE: { 
      name: 'Elite', 
      xp: 12000, 
      multiplier: 1.8,
      color: '#F59E0B'
    },
    UNREAL: { 
      name: 'Unreal', 
      xp: 19200, 
      multiplier: 2.0,
      color: '#EF4444'
    }
  },
  
  // Simulator types (различни rates за различни симулатори)
  SIMULATOR_TYPES: {
    BASIC: { 
      name: 'Basic',
      tokens_per_minute: 2, 
      xp_per_minute: 2,
      color: '#6B7280',
      icon: '🚗'
    },
    STANDARD: { 
      name: 'Standard',
      tokens_per_minute: 3, 
      xp_per_minute: 3,
      color: '#059669',
      icon: '🏎️'
    },
    PREMIUM: { 
      name: 'Premium',
      tokens_per_minute: 4, 
      xp_per_minute: 4,
      color: '#DC2626',
      icon: '🏁'
    }
  }
}

/**
 * Получава tier информация базирана на XP
 * @param {number} xp - Текущо XP на потребителя
 * @returns {object} Tier информация
 */
function getTierByXP(xp) {
  const tiers = Object.values(TOKEN_CONFIG.TIERS).reverse() // Започваме от най-високия
  
  for (const tier of tiers) {
    if (xp >= tier.xp) {
      return tier
    }
  }
  
  return TOKEN_CONFIG.TIERS.BEGINNER // Fallback
}

/**
 * Изчислява tier multiplier базиран на XP
 * @param {number} xp - Текущо XP на потребителя
 * @returns {number} Tier multiplier
 */
function getTierMultiplier(xp) {
  return getTierByXP(xp).multiplier
}

/**
 * ГЛАВНА ФУНКЦИЯ ЗА ИЗЧИСЛЯВАНЕ НА TOKENS И XP
 * 
 * Тази функция трябва да се използва НАВСЯКЪДЕ в системата!
 * 
 * @param {number} minutes - Минути игрално време
 * @param {number} currentXP - Текущо XP на потребителя (за tier multiplier)
 * @param {string} simulatorType - Тип симулатор (BASIC, STANDARD, PREMIUM)
 * @returns {object} Резултат с tokens, xp, multiplier, etc.
 */
function calculateTokensAndXP(minutes, currentXP = 0, simulatorType = 'BASIC') {
  // Валидация
  if (minutes < 0) minutes = 0
  if (currentXP < 0) currentXP = 0
  
  // Получаваме конфигурацията за симулатора
  const simConfig = TOKEN_CONFIG.SIMULATOR_TYPES[simulatorType] || TOKEN_CONFIG.SIMULATOR_TYPES.BASIC
  
  // Base calculation
  const baseTokens = Math.floor(minutes * simConfig.tokens_per_minute)
  const xp = Math.floor(minutes * simConfig.xp_per_minute)
  
  // Tier multiplier (базиран на ТЕКУЩО XP, не на новото!)
  const tierMultiplier = getTierMultiplier(currentXP)
  const tokensWithMultiplier = Math.floor(baseTokens * tierMultiplier)
  
  // Bonus tokens (на всеки час)
  let bonusTokens = 0
  if (minutes >= TOKEN_CONFIG.BONUS_TOKENS_THRESHOLD) {
    bonusTokens = Math.floor(minutes / TOKEN_CONFIG.BONUS_TOKENS_THRESHOLD) * TOKEN_CONFIG.BONUS_TOKENS_AMOUNT
  }
  
  // Финални резултати
  const finalTokens = tokensWithMultiplier + bonusTokens
  
  return {
    // Основни резултати
    tokens: finalTokens,
    xp: xp,
    
    // Детайли за debugging
    baseTokens: baseTokens,
    tokensWithMultiplier: tokensWithMultiplier,
    bonusTokens: bonusTokens,
    tierMultiplier: tierMultiplier,
    simulatorType: simulatorType,
    
    // Tier информация
    currentTier: getTierByXP(currentXP),
    newTier: getTierByXP(currentXP + xp),
    
    // Rates използвани
    tokensPerMinute: simConfig.tokens_per_minute,
    xpPerMinute: simConfig.xp_per_minute
  }
}

/**
 * Изчислява само tokens (за backward compatibility)
 * @param {number} minutes 
 * @param {number} currentXP 
 * @param {string} simulatorType 
 * @returns {number} Tokens
 */
function calculateTokens(minutes, currentXP = 0, simulatorType = 'BASIC') {
  return calculateTokensAndXP(minutes, currentXP, simulatorType).tokens
}

/**
 * Изчислява само XP (за backward compatibility)
 * @param {number} minutes 
 * @param {string} simulatorType 
 * @returns {number} XP
 */
function calculateXP(minutes, simulatorType = 'BASIC') {
  return calculateTokensAndXP(minutes, 0, simulatorType).xp
}

// Export всичко
module.exports = {
  TOKEN_CONFIG,
  getTierByXP,
  getTierMultiplier,
  calculateTokensAndXP,
  calculateTokens,
  calculateXP
}
